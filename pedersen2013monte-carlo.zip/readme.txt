Monte Carlo Simulation in Financial Valuation
Source-Code for R
Copyright 2013 Magnus Erik Hvass Pedersen
www.Hvass-Labs.org


Please ensure you have downloaded the latest version from:

www.hvass-labs.org/people/magnus/publications/pedersen2013monte-carlo.zip

This implements the Monte Carlo simulations described in
the paper of the same title and available for download:

www.hvass-labs.org/people/magnus/publications/pedersen2013monte-carlo.pdf


Installation:

1. Unpack the archive to a convenient location.
2. Edit the setwd command in the source-code
   to reflect the installation location.
3. Start the R console.
4. Copy and paste text from the source-code file
   to the R console to execute the source-code.


Requirements:

The source-code was developed in R version 2.15.2
i386 for MS Windows. The required packages are
listed at the top of the source-code file.


Data sources (detailed in the paper):
- S&P 500 ROA, ROE, Retain, Equity/Assets from Compustat:
  http://www.compustat.com/

- S&P 500 P/Book from Compustat and FRED:
  http://www.compustat.com/
  http://research.stlouisfed.org/fred2/series/SP500/

- USA Gov. Bond Yields 1962-2013 (daily) from Federal Reserve:
  http://www.federalreserve.gov/releases/h15/data.htm

- USA Gov. Bond Yields 1953-2013 (monthly) from Federal Reserve:
  http://www.federalreserve.gov/releases/h15/data.htm

- USA Gov. Bond Yields 1798-2012 (yearly) from:
  Homer & Sylla, A History of Interest Rates, 2005.
  Tables 38, 46, 48, 51, 87.
  2006-2012 data is from Federal Reserve (see above).


Update History:

Version 2.2 (2014, February 21):
- Swapped axes on some scatter-plots.

Version 2.1 (2013, October 2):
- Added curve fittings for equity, earnings, dividends per share.

Version 2 (2013, September 28):
- Added more financial data for S&P 500 and Coca-Cola.
- Added valuation of share buyback and issuance.
- Added various functions and plots.
- Changed indexing of equity-array from simulateEquity().
- Fixed some minor bugs.

Version 1.2 (2013, July 20):
- Fixed plot range for:
  "Coca-Cola PV-Book CDF (DJVC Compounded).emf"
  "Coca-Cola PV-Book CDF (DJVC Annualized).emf"
- Added share buyback valuation plots for Coca-Cola.

Version 1.1 (2013, June 4):
- Added 3d plot for S&P 500 price.
- Added PV of Coke using as discount rate DJVC's annualized
  rate of return.
- Added Equity Risk Premium between S&P 500 returns and
  USA Gov. Bond yields.
- Minor cleanup.

Version 1.0 (2013, May 24):
- First release.
