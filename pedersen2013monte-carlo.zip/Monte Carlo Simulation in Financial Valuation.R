################################################
################################################
# 
# Monte Carlo Simulation in Financial Valuation
# Source-code for R
# 
# Copyright (C) 2013 Magnus Erik Hvass Pedersen
# www.hvass-labs.org
#
# See paper of same title for documentation.
# See license.txt for license details.
#
################################################
################################################
# Required packages.

require(MASS)
require(lattice)
require(foreach)
require(spatial)
require(DEoptim)
require(devEMF)

#install.packages("foreach")
#install.packages("DEoptim")
# win.metafile() causes problems with MS Word's PDF export, and devEMF works.
#install.packages("devEMF")

# Parallel execution of foreach loops doesn't seem to be faster.
#require(doParallel)
#registerDoParallel(cores=4)

################################################
# Calculate retain/earnings from dividend/earnings and netBuyback/earnings.
#
# Parameters:
# dividendOverEarnings		Historical dividend/earnings ratios.
# netBuybackOverEarnings	Historical netBuyback/earnings ratios.

retainOverEarnings = function(dividendOverEarnings, netBuybackOverEarnings)
{
	1 - dividendOverEarnings - netBuybackOverEarnings
}

################################################
# Mean growth rate and mean Payout*ROE.
#
# Parameters:
# ROE			Array of ROE.
# retainOverEarnings	Array of retain/earnings ratios.

# Mean growth rate.
meanGrowth = function(ROE, retainOverEarnings)
{
	mean(ROE*retainOverEarnings)
}

# Mean payout rate. Multiply this with equity
# to get mean payout.
meanPayoutROE = function(ROE, retainOverEarnings)
{
	mean(ROE*(1-retainOverEarnings))
}

################################################
# Convert number of years to number of trading days.

yearsToTradingDays = function(years)
{
	# In the period 1984-2011 each calendar year
	# consisted of 252.32 trading days on average.

	floor(years * 252.32)
}

# The inverse.
tradingDaysToYears = function(days)
{
	floor(days / 252.32)
}

################################################
# Convert number of months to number of trading days.

monthsToTradingDays = function(months)
{
	yearsToTradingDays(months/12)
}

################################################
# Load and prepare financial data.
# File must be tab-separated with a header, and
# each row having:
# Year	ROA	ROE	Dividend/Earnings	NetBuyback/Earnings	Equity/Assets
#
# Parameters:
# filename	Name of data-file to load.

loadFinancialData = function(filename)
{
	dat = list()

	# Load data.
	dat$data = read.table(filename, header=TRUE, sep="\t")

	# Assign data.
	dat$years = dat$data[[1]]
	dat$ROA = dat$data[[2]]
	dat$ROE = dat$data[[3]]
	dat$dividendOverEarnings = dat$data[[4]]
	dat$netBuybackOverEarnings = dat$data[[5]]
	dat$equityOverAssets = dat$data[[6]]

	# Calculations on data.
	dat$retainOverEarnings = retainOverEarnings(dat$dividendOverEarnings, dat$netBuybackOverEarnings)
	dat$meanROE = mean(dat$ROE)
	dat$meanRetainOverEarnings = mean(dat$retainOverEarnings)
	dat$meanGrowth = meanGrowth(dat$ROE, dat$retainOverEarnings)
	dat$meanPayoutROE = meanPayoutROE(dat$ROE, dat$retainOverEarnings)

	dat
}

################################################
# Load data.

# Change this to your installation directory.
setwd("E:/Finance/Publications/Monte Carlo Simulation in Financial Valuation/Data and Source Code/")

# Load Coca-Cola financial data.
coke = loadFinancialData("Coca-Cola Data (Financial).txt")

################################################
# Load and prepare data for S&P 500.

# Load S&P 500 financial data.
sp500 = loadFinancialData("S&P 500 Data (Financial).txt")

# Load S&P 500 monthly price data.
sp500$dataMonthly = read.table("S&P 500 Data (Price Monthly).txt", header=TRUE, sep="\t")
sp500$datesMonthly = as.Date(paste(sp500$dataMonthly[[1]], "-01", sep=""), "%Y-%m-%d")
sp500$datesYearly = sp500$datesMonthly[1:(length(sp500$datesMonthly)-12)]
sp500$datesDecade = sp500$datesMonthly[1:(length(sp500$datesMonthly)-120)]
sp500$pricesMonthly = sp500$dataMonthly[[2]]
sp500$priceChangesMonthly = sp500$pricesMonthly[2:length(sp500$pricesMonthly)] / sp500$pricesMonthly[1:(length(sp500$pricesMonthly)-1)] - 1
sp500$priceChangesYearly = sp500$pricesMonthly[13:length(sp500$pricesMonthly)] / sp500$pricesMonthly[1:(length(sp500$pricesMonthly)-12)] - 1
sp500$priceChangesDecade = sp500$pricesMonthly[121:length(sp500$pricesMonthly)] / sp500$pricesMonthly[1:(length(sp500$pricesMonthly)-120)] - 1
sp500$priceChangesDecadeAnnualized = (sp500$priceChangesDecade + 1)^(1/10) - 1

# Load S&P 500 P/Book data.
sp500$pbookdata = read.table("S&P 500 Data (PBook Daily Interpolated).txt", header=TRUE, sep="\t")
sp500$pbookdates = as.Date(sp500$pbookdata[[1]], "%d-%m-%Y")
# Prices
sp500$pricesAll = sp500$pbookdata[[2]]
# Prices that are not N/A
sp500$prices = sp500$pricesAll[!is.na(sp500$pricesAll)]
# Book-values that are not N/A
temp = sp500$pbookdata[[4]]
sp500$bookvalues = temp[!is.na(temp)]
# All P/Book ratios incl. N/A
sp500$pbooksAll = sp500$pbookdata[[5]]
# P/Book ratios that are not N/A
sp500$pbooks = sp500$pbooksAll[!is.na(sp500$pbooksAll)]

# Calculate S&P 500 daily price changes.
sp500$priceChangesDaily = sp500$prices[2:length(sp500$prices)] / sp500$prices[1:(length(sp500$prices)-1)]

# Calculate S&P 500 yearly price changes.
# This is not Total Return (reinvestment of dividends is not taken into account).
daysInYear = yearsToTradingDays(1)
sp500$priceChangesYearly2 = sp500$prices[(daysInYear+1):length(sp500$prices)] / sp500$prices[1:(length(sp500$prices)-daysInYear)]

# Calculate S&P 500 P/Book changes, daily.
sp500$pbookChangesDaily = sp500$pbooks[2:length(sp500$pbooks)] / sp500$pbooks[1:(length(sp500$pbooks)-1)]

# Calculate S&P 500 P/Book changes, monthly.
daysInMonth = monthsToTradingDays(1)
sp500$pbookChangesMonthly = sp500$pbooks[(daysInMonth+1):length(sp500$pbooks)] / sp500$pbooks[1:(length(sp500$pbooks)-daysInMonth)]

# Calculate S&P 500 P/Book changes, yearly.
sp500$pbookChangesYearly = sp500$pbooks[(daysInYear+1):length(sp500$pbooks)] / sp500$pbooks[1:(length(sp500$pbooks)-daysInYear)]

# Calculate S&P 500 P/Book Changes Bins for use in
# Monte Carlo simulation of future P/Book changes.
sp500$pbookHist = hist(sp500$pbooks, nclass=100, plot=FALSE)
bins = findInterval(sp500$pbooks, sp500$pbookHist$breaks)

# S&P 500 P/Book Changes Bins, daily.
sp500$pbookChangesDailyBins = vector(mode="list", length=length(sp500$pbookHist$breaks))
for (i in 1:length(sp500$pbookChangesDaily))
{
	bin = bins[i]
	sp500$pbookChangesDailyBins[[bin]] = c(sp500$pbookChangesDailyBins[[bin]], sp500$pbookChangesDaily[i])
}

# S&P 500 P/Book Changes Bins, monthly.
sp500$pbookChangesMonthlyBins = vector(mode="list", length=length(sp500$pbookHist$breaks))
for (i in 1:length(sp500$pbookChangesMonthly))
{
	bin = bins[i]
	sp500$pbookChangesMonthlyBins[[bin]] = c(sp500$pbookChangesMonthlyBins[[bin]], sp500$pbookChangesMonthly[i])
}

# S&P 500 P/Book Changes Bins, yearly.
sp500$pbookChangesYearlyBins = vector(mode="list", length=length(sp500$pbookHist$breaks))
for (i in 1:length(sp500$pbookChangesYearly))
{
	bin = bins[i]
	sp500$pbookChangesYearlyBins[[bin]] = c(sp500$pbookChangesYearlyBins[[bin]], sp500$pbookChangesYearly[i])
}

################################################
# Load and prepare data for USA government bonds.

# Load USA government bond yields for the period 1962-2013, daily averages.
usaBonds = list()
usaBonds$data = read.table("USA Government Bond Yields 10-Year Maturity (1962-2013 Daily).txt", header=TRUE, sep="\t")
usaBonds$dates = as.Date(usaBonds$data[[1]], "%Y-%m-%d")
# All bond yields incl. N/A
usaBonds$yieldsAll = usaBonds$data[[2]]
# Bond yields that are not N/A
usaBonds$yields = usaBonds$yieldsAll[!is.na(usaBonds$yieldsAll)]

# Load USA government bond yields, Monthly averages.
usaBonds$dataMonthly = read.table("USA Government Bond Yields 10-Year Maturity (1953-2013 Monthly).txt", header=TRUE, sep="\t")
usaBonds$datesMonthly = as.Date(paste(usaBonds$dataMonthly[[1]], "-01", sep=""), "%Y-%m-%d")
usaBonds$yieldsMonthly = usaBonds$dataMonthly[[2]]
usaBonds$yieldsMonthlized = (usaBonds$yieldsMonthly/100+1)^(1/12)-1

# Load USA government bond yields for the period 1798-2012, annual averages.
usaBondsHistory = list()
usaBondsHistory$data = read.table("USA Government Bond Yields Long Maturity (1798-2012).txt", header=TRUE, sep="\t")
usaBondsHistory$years = usaBondsHistory$data[[1]]
usaBondsHistory$yields = usaBondsHistory$data[[2]]

################################################
# Load and prepare data for S&P 500 options.

# Load option data for SPY (S&P 500 ETF).
calls = list()
calls$data = read.table("SPY Calls Expiring Dec 18, 2015 Quoted Mar 15, 2013 (S&P 500 ETF).txt", header=TRUE, sep="\t")
calls$exercisePrices = calls$data[[1]]
calls$optionPrices = calls$data[[2]]
puts = list()
puts$data = read.table("SPY Puts Expiring Dec 18, 2015 Quoted Mar 15, 2013 (S&P 500 ETF).txt", header=TRUE, sep="\t")
puts$exercisePrices = puts$data[[1]]
puts$optionPrices = puts$data[[2]]

################################################
# Load and prepare data for DJVC.

# Load data for Dow Jones Venture Capital index (DJVC).
djvc = list()
djvc$data = read.table("Dow Jones Venture Capital Index Data.txt", header=TRUE, sep="\t")
djvc$dates = as.Date(paste("01-", djvc$data[[1]], sep=""), "%d-%m-%Y")
djvc$datesMonthly = djvc$dates[1:(length(djvc$dates)-1)]
djvc$datesYearly = djvc$dates[1:(length(djvc$dates)-12)]
djvc$datesDecade = djvc$dates[1:(length(djvc$dates)-120)]
djvc$prices = djvc$data[[2]]
djvc$priceChangesMonthly = djvc$prices[2:length(djvc$prices)] / djvc$prices[1:(length(djvc$prices)-1)] - 1
djvc$priceChangesYearly = djvc$prices[13:length(djvc$prices)] / djvc$prices[1:(length(djvc$prices)-12)] - 1
djvc$priceChangesDecade = djvc$prices[121:length(djvc$prices)] / djvc$prices[1:(length(djvc$prices)-120)] - 1
djvc$priceChangesDecadeAnnualized = (djvc$priceChangesDecade + 1)^(1/10) - 1

################################################
# Geometric mean.
# Only for positive numbers.

geomean = function(x)
{
	# This overflows.
	# prod(x)^(1/length(x))

	exp(mean(log(x)))
}

################################################
# Harmonic mean.

harmean = function(x)
{
	1/mean(1/x)
}

################################################
# Calculate the number of simulation years required
# to achieve the given error in the terminal value.
# Assume payout grows for eternity.
#
# Parameters:
# retainOverEarnings	Array of retain/earnings ratios.
# ROE			Array of ROE.
# maxError		Max error in terminal value.

requiredYears = function(retainOverEarnings, ROE, maxError)
{
	# Payout growth rate each year for eternity.
	g = mean(ROE * retainOverEarnings)

	# Select discount rate slightly above growth rate and minimum 5%.
	d = max(g+.02, 0.05)

	# Minimum number of years to get below required error,
	# assuming constant ROE and Retain for eternity.
	# See paper for the derivation of this formula.
	minYears = log(maxError)/log((1+g)/(1+d))

	# Add a safety margin because ROE and Retain are not constant
	# and the discount rate is not known but estimated.
	years = 1.2 * minYears

	# Round up to nearest multiple of 10 for aesthetic reasons.
	ceiling(years/10)*10
}

################################################
# Discounted value.
#
# Parameters:
# d		Discount rate.
# value		Value to be discounted.
# years		Number of years from now.

discount = function(d, value, years)
{
	value/(1+d)^years
}

################################################
# Terminal value.
#
# Parameters:
# d		Discount rate.
# g		Growth rate.
# payout	Value to be discounted.
# years		Number of years from now.

# Payouts are assumed to be constant for eternity.
terminalValueConst = function(d, payout, years)
{
	discount(d, payout/d, years)
}

# Payouts are assumed to grow for eternity.
terminalValueGrowth = function(d, g, payout, years)
{
	discount(d, payout/(d-g), years)
}

################################################
# Interpolate yearly data.
#
# Parameters:
# dat		Data to be interpolated.
# startDat	Start value for data (e.g. 1 for equity).
# sims		Number of simulations.
# years		Number of years per simulation.
# k		Number of interpolation points.

yearlyInterpolation = function(dat, startDat, sims, years, k)
{
	# Allocate array.
	result = array(dim=c(years*k, sims))

	for (year in 1:years)
	{
		# Interpolation end-points.
		a = ifelse(year>1, dat[year-1,], startDat)
		b = dat[year,]

		# Interpolate data.
		interpolated = foreach(i=1:k/k, .combine='rbind') %do% t(i * (b-a) + a)

		# Index into monthly-array.
		start = (year-1)*k+1
		end = start+k-1

		# Assign interpolated data.
		result[start:end,] = interpolated
	}

	result
}

yearlyToMonthlyInterpolation = function(dat, startDat, sims, years)
{
	yearlyInterpolation (dat, startDat, sims, years, 12)
}

################################################
# Present value of a series of payouts.
#
# Parameters:
# d		Discount rate.
# payout	Array of payouts to discount.
# n		Number of payouts to discount.

presentValue = function(d, payout, n=length(payout))
{
	sum((payout[1:n]) / ((1+d)^(1:n)))
}

################################################
# Sample financial data from historical data
# and from the same year.
#
# Parameters:
# ROE			Historical data for ROE.
# retainOverEarnings	Historical data for retain/earnings ratios.
# dividendOverEarnings	Historical data for dividend/earnings ratios.
# netBuybackOverEarnings	Historical data for netBuyback/earnings ratios.
# sims			Number of simulations.
# years			Number of years.

sampleFinancials = function(ROE, retainOverEarnings, dividendOverEarnings,
                            netBuybackOverEarnings, sims, years)
{
	# Sample index.
	index = sample(length(retainOverEarnings), sims*years, replace=TRUE)

	# Sample ROE and retain according to index.
	sampledROE = ROE[index]
	sampledRetainOverEarnings = retainOverEarnings[index]
	sampledDividendOverEarnings = dividendOverEarnings[index]
	sampledNetBuybackOverEarnings = netBuybackOverEarnings[index]

	# Turn into matrices.
	dim(sampledROE) = c(years, sims)
	dim(sampledRetainOverEarnings) = c(years, sims)
	dim(sampledDividendOverEarnings) = c(years, sims)
	dim(sampledNetBuybackOverEarnings) = c(years, sims)

	list(retainOverEarnings=sampledRetainOverEarnings, ROE=sampledROE,
             dividendOverEarnings=sampledDividendOverEarnings,
             netBuybackOverEarnings=sampledNetBuybackOverEarnings)
}

################################################
# Sample historical P/Book of the S&P 500 index.
#
# Parameters:
# n		Number of samples.

sp500$sampleHistoricalPBook = function(sims, years)
{
	# Sample.
	s = sample(sp500$pbooks, sims*years, replace=T)

	# Change dimensions.
	dim(s) = c(years, sims)

	s
}

################################################
# Sample value yield of the S&P 500 index.
#
# Parameters:
# n		Number of samples.
# pbook		P/Book ratio for the S&P 500 index.

# Log-normal distributed.
sp500$sampleValueYield = function(n, pbook)
{
	mu = 1.507 / (pbook^0.411) - 3.537
	sigma = 0.021 / (pbook^0.825) + 0.0488

	rlnorm(n, meanlog=mu, sdlog=sigma)
}

# Normal distributed.
sp500$sampleValueYieldNormal = function(n, pbook)
{
	m = 0.091 / pbook + 0.044
	s = 0.007 / (pbook^1.34) + 0.002

	rnorm(n, mean=m, sd=s)
}

################################################
# Monte Carlo simulation of Equity Growth Model.
#
# Parameters:
# ROE				Historical ROE ratios from which to sample.
# retainOverEarnings		Historical retain/earnings ratios from which to sample.
# dividendOverEarnings		Historical dividend/earnings ratios from which to sample.
# netBuybackOverEarnings	Historical netBuyback/earnings ratios from which to sample.
# sims				Number of MC simulations to perform.
# years				Number of years for each MC simulation.
# scaleRetain			Scale applied to sampled Retain ratios.
# scaleROE			Scale applied to sampled ROE.

simulateEquity = function(ROE, retainOverEarnings, dividendOverEarnings,
                          netBuybackOverEarnings,
                          sims, years, scaleRetain=1, scaleROE=1)
{
	# Allocate arrays.
	equity = array(dim=c(years+1,sims))
	earnings = array(dim=c(years,sims))
	retain = array(dim=c(years,sims))
	payout = array(dim=c(years,sims))
	dividend = array(dim=c(years,sims))
	netBuyback = array(dim=c(years,sims))

	# Initialize first year's starting equity to one for all simulations.
	equity[1,] = 1

	# Sample financial data.
	s = sampleFinancials(ROE, retainOverEarnings, dividendOverEarnings, netBuybackOverEarnings, sims, years)

	# Calculate payout scale.
	# This must be calculated before s$retainOverEarnings is scaled.
	scalePayout = (1 - scaleRetain * s$retainOverEarnings) / (1 - s$retainOverEarnings)

	# Scale the sampled ROE and retain.
	s$ROE = s$ROE * scaleROE
	s$retainOverEarnings = s$retainOverEarnings * scaleRetain

	# Calculate earnings, payout and equity for each year.
	for (year in 1:years)
	{
		# Equity growth model.
		earnings[year,] = s$ROE[year,] * equity[year,]
		retain[year,] = earnings[year,] * s$retainOverEarnings[year,]
		payout[year,] = earnings[year,] * (1 - s$retainOverEarnings[year,]) # This is already scaled.
		dividend[year,] = earnings[year,] * s$dividendOverEarnings[year,] * scalePayout[year,]
		netBuyback[year,] = earnings[year,] * s$netBuybackOverEarnings[year,] * scalePayout[year,]
		equity[year+1,] = earnings[year,] * s$retainOverEarnings[year,] + equity[year,]
	}

	# Test ROE and retain scaling is correct.
	# Assert: earnings = retain + dividend + netBuyback
	# stopifnot(earnings-retain-dividend-netBuyback<1e-3)

	# Don't return the first year's equity which is normalized to 1.
	list(equity=equity[2:(years+1),], earnings=earnings, retain=retain, payout=payout,
             dividend=dividend, netBuyback=netBuyback)
}

# Call simulateEquity() with sp500 data.
sp500$simulateEquity = function(sims, years, scaleRetain=1, scaleROE=1)
{
	simulateEquity(sp500$ROE, sp500$retainOverEarnings,
                       sp500$dividendOverEarnings, sp500$netBuybackOverEarnings,
                       sims, years, scaleRetain, scaleROE)
}

# Call simulateEquity() with coke data.
coke$simulateEquity = function(sims, years, scaleRetain=1, scaleROE=1)
{
	simulateEquity(coke$ROE, coke$retainOverEarnings,
                       coke$dividendOverEarnings, coke$netBuybackOverEarnings,
                       sims, years, scaleRetain, scaleROE)
}

################################################
# Monte Carlo simulation of P/Book time-series.
#
# Parameters:
# startPBook		Starting P/Book ratio.
# sims			Number of simulations.
# days			Number of days in each simulation.
# years			Number of years in each simulation.
# pbookHist		Histogram of pbook ratios.
# pbookChangesBins	Histogram bins with pbook changes.

simulatePBook = function(pbookHist, pbookChangesBins, startPBook, sims, periods)
{
	# Allocate matrix.
	pbooks = array(dim=c(periods+1, sims))

	# Initialize pbook for first period.
	pbooks[1,] = startPBook
	
	for (t in 1:periods)
	{
		# Lookup number of the bin containing the current pbook.
		bin = findInterval(pbooks[t,], pbookHist$breaks, all.inside=TRUE)

		# Sample a change in pbook from the bin.
		# change = sapply(pbookChangesBins[bin], function(x) sample(x, 1)) # Doesn't work, see below.
		change = sapply(pbookChangesBins[bin], function(x) x[sample.int(length(x), 1)])

		# This sampling is clumsy because sample() does not work if the
		# vector has only one element, and pbookChangesBins[[bin]] doesn't
		# work because R interprets the bin-indexing as nested recursion.
		# These are bizarre and inconsistent side-effects of R's syntax.

		# Update pbook.
		pbooks[t+1,] = pbooks[t,] * change
	}

	# Don't return starting P/Book which is constant.
	pbooks[2:(periods+1),]
}

# Call simulatePBook() with sp500 data. (daily)
sp500$simulatePBookDaily = function(startPBook, sims, days)
{
	simulatePBook(sp500$pbookHist, sp500$pbookChangesDailyBins, startPBook, sims, days)
}

# Call simulatePBook() with sp500 data. (monthly)
sp500$simulatePBookMonthly = function(startPBook, sims, months)
{
	simulatePBook(sp500$pbookHist, sp500$pbookChangesMonthlyBins, startPBook, sims, months)
}

# Call simulatePBook() with sp500 data. (yearly)
sp500$simulatePBookYearly = function(startPBook, sims, years)
{
	simulatePBook(sp500$pbookHist, sp500$pbookChangesYearlyBins, startPBook, sims, years)
}

# Extract monthly P/Book ratios from daily simulations.
pbookDailyToMonthly = function(pbooks, months)
{
	pbooks[monthsToTradingDays(1:months),]
}

# Extract yearly P/Book ratios from daily simulations.
pbookDailyToYearly = function(pbooks, years)
{
	pbooks[yearsToTradingDays(1:years),]
}

# Extract yearly P/Book ratios from monthly simulations.
pbookMonthlyToYearly = function(pbooks, years)
{
	pbooks[1:years*12,]
}

################################################
# Simulate changes in number of shares from
# share buyback and issuance.
# Returns the normalized number of shares at the
# end of each simulation year.
# The starting number of shares is normalized to one
# but this is not included in the returned array.

# Parameters:
# equity		Simulated equity from simulateEquity()
# netBuyback		Simulated netBuyback from simulateEquity()
# pbooks		P/Book for future years.
# sims			Number of simulations.
# years			Number of years in each simulation.

simulateShareBuyback = function(equity, netBuyback, pbooks, sims, years)
{
	# Allocate array.
	shares = array(dim=c(years+1,sims))

	# Initialize first year's shares to one for all simulations.
	shares[1,] = 1

	# Calculate earnings, payout and equity for each year.
	for (year in 1:years)
	{
		shares[year+1,] = shares[year,] * (1 - netBuyback[year,]/(pbooks[year,] * equity[year,]))
	}

	# Don't return the first year's shares which are normalized to 1.
	shares[2:(years+1),]
}

################################################
# Simulate share-prices from equity, P/Book and
# changes in shares outstanding.

# Parameters:
# startPBook		Starting P/Book for S&P 500.
# sims			Number of simulations.
# years			Number of years in each simulation.

sp500$simulateSharePriceYearly = function(startPBook, sims, years)
{
	# Simulate equity, earnings, etc.
	simEquity = sp500$simulateEquity(sims, years)

	# Simulate P/Book ratios.
	simPBooks = sp500$simulatePBookYearly(startPBook, sims, years)

	# Simulate share buyback.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooks, sims, years)

	# Price per share.
	pricePerShare = simEquity$equity * simPBooks / shares

	pricePerShare
}

sp500$simulateSharePriceMonthly = function(startPBook, sims, years)
{
	# Simulate equity, earnings, etc., yearly.
	simEquity = sp500$simulateEquity(sims, years)

	# Simulate P/Book ratios, monthly.
	simPBooksMonthly = sp500$simulatePBookMonthly(startPBook, sims, years*12)

	# Extract yearly P/Book ratios.
	simPBooksYearly = pbookMonthlyToYearly(simPBooksMonthly, years)

	# Simulate share buyback, yearly.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooksYearly, sims, years)

	# Interpolate equity per share from yearly to monthly.
	equityPerShareMonthly = yearlyToMonthlyInterpolation(simEquity$equity/shares, 1, sims, years)

	# Price per share, monthly
	pricePerShareMonthly = equityPerShareMonthly * simPBooksMonthly

	pricePerShareMonthly
}

################################################
# Find the value yield, that is, find the discount
# rate d which makes the present value equal to
# the P/Book ratio.
#
# Parameters:
# pbook		Current P/Book ratio.
# sims		Number of simulations.
# pv		Present value function.

# Find one value yield.
valueYieldOne = function(pbook, pv)
{
	# Finding the value yield is an optimization problem.
	# We are seeking the discount rate d which causes
	# the present value to equal the given P/Book ratio.
	# The difference between the present value and the
	# P/Book ratio is squared so as to create a continuous
	# function to optimize.

	# Max error.
	maxError = 1e-4

	# Try local optimization.
	res = optimize(function(d) abs(pbook-pv(d)), maximum=FALSE, lower=-0.5, upper=10, tol=1e-5)

	# If local optimization fails then try global optimization.
	# This is much slower and can be disabled by adding FALSE to
	# the if-condition.
	if (FALSE & res$objective>maxError)
	{
		# Use Differential Evolution (DE) as global optimizer.
		res2 = DEoptim(function(d) abs(pbook-pv(d)), lower=-0.5, upper=10, control=list(NP=15, CR=0.7, F=0.9, trace=F, itermax=3000, VTR=maxError))

		# If result of DE is better then use it.
		if (res$objective > res2$optim$bestval)
		{
			res = list(minimum = res2$optim$bestmem[[1]], objective=res2$optim$bestval)
		}
	}

	res
}

# Find multiple value yields.
valueYieldMany = function(pbook, sims, pv)
{
	vys = foreach(sim=1:sims) %do% valueYieldOne(pbook, function (d) pv(d,sim))

	list(yields = as.numeric(lapply(vys, function(x) (x$minimum))),
	errors = as.numeric(lapply(vys, function(x) (x$objective))))
}

# Find value yields when the terminal values are constant payouts for
# eternity, calculated as the mean ROE multiplied by the last equity.
valueYieldConst = function(pbook, payout, equity, meanROE, sims, years)
{
	valueYieldMany(pbook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ terminalValueConst(d, equity[years,sim]*meanROE, years)))
}

# Find value yields when the payouts grow for eternity.
valueYieldGrowth = function(pbook, payout, equity, meanPayoutROE, meanGrowth, sims, years)
{
	valueYieldMany(pbook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ terminalValueGrowth(d, meanGrowth, equity[years,sim]*meanPayoutROE, years)))
}

# Find value yields when the terminal value is the price, calculated
# as the final equity multiplied by a P/Book ratio at that time.
valueYieldPBook = function(startPBook, endPBooks, payout, equity, sims, years)
{
	valueYieldMany(startPBook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ discount(d, endPBooks[sim]*equity[years,sim], years)))
}

# Remove value yield outliers which are likely caused by optimization error.
valueYieldRemoveOutliers = function(vys, sdFactor=3)
{
	m = mean(vys$yields)
	s = sd(vys$yields)

	idx = which(abs(vys$yields-m)<sdFactor*s)

	list(yields=vys$yields[idx], yieldsAll=vys$yields,
	     errors=vys$errors[idx], errorsAll=vys$errors, idx=idx)
}

################################################
# Option valuation.

# Parameters:
# call			Value call optins (TRUE), or put options (FALSE)
# exercisePrices	Array of exercise prices for the options.
# optionPrices		Array of option prices.
# sharePrices		Array of share prices at time of exercising.
# years			Number of years until exercising (decimal number is OK).

optionValuation = function(call, exercisePrices, optionPrices, sharePrices, years)
{
	# Number of options in chain.
	n = length(optionPrices)

	# Number of MC simulated share prices.
	sims = length(sharePrices)

	# Preallocate arrays.
	profitsAll = array(dim=c(n, sims))
	profitMeans = array(dim=n)
	profitSDs = array(dim=n)
	profitProbs = array(dim=n)
	vysAll = array(dim=c(n, sims))
	vyMeans = array(dim=n)
	vySDs = array(dim=n)

	# Loop over all options.
	for (i in 1:n)
	{
		# Convenience variables.
		exercisePrice = exercisePrices[i]
		optionPrice = optionPrices[i]

		# Exercise values of option.
		if (call)
		{
			# Call option.
			exerciseValues = pmax(sharePrices - exercisePrice, 0)
		}
		else
		{
			# Put option.
			exerciseValues = pmax(exercisePrice - sharePrices, 0)
		}

		# Profits from exercising call option.
		profits = exerciseValues - optionPrice
		profitsAll[i,] = profits

		# Profit mean and sd.
		profitMeans[i] = mean(profits)
		profitSDs[i] = sd(profits)

		# Probability of profit, Pr[profits>0]
		profitProbs[i] = length(profits[profits>0])/length(profits)

		# Value yield.
		vys = (exerciseValues / optionPrice)^(1/years) - 1
		vysAll[i,] = vys

		# Value yield mean and sd.
		vyMeans[i] = mean(vys)
		vySDs[i] = sd(vys)
	}

	list(exerciseValues=exerciseValues, profits=profitsAll, profitMeans=profitMeans, profitSDs=profitSDs, profitProbs=profitProbs, vys=vysAll, vyMeans=vyMeans, vySDs=vySDs)
}

################################################
# Linear regression of DJVC versus S&P 500.
# This is used below to simulate DJVC price
# from changes in S&P 500 price.

# Merge S&P 500 and DJVC data.
df1 = data.frame(date=djvc$datesMonthly, change=djvc$priceChangesMonthly)
df2 = data.frame(date=sp500$datesMonthly[1:(length(sp500$datesMonthly)-1)], change=sp500$priceChangesMonthly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
x = m$change.x[!is.na(m$change.x) & !is.na(m$change.y)]
y = m$change.y[!is.na(m$change.x) & !is.na(m$change.y)]

# Linear regression.
fit = lm(x~y)

# Linear regression parameters.
djvc$sp500alpha = fit$coefficients[[1]]
djvc$sp500beta = fit$coefficients[[2]]
djvc$sp500sigma = summary(fit)$sigma

################################################
# Linear model of DJVC monthly returns from
# S&P 500 monthly returns.

# Parameters:
# sp500changesMonthly	S&P 500 monthly changes.

djvc$sp500LinearModel = function(sp500changesMonthly)
{
	# Random error for use in linear model.
	err = rnorm(length(sp500changesMonthly), mean=0, sd=djvc$sp500sigma)
	dim(err) = dim(sp500changesMonthly)

	# Linear model of DJVC change from the change in share-price of S&P 500.
	djvcChanges = sp500changesMonthly * djvc$sp500beta + djvc$sp500alpha + err

	# Compounded returns.
	if (is.null(dim(sp500changesMonthly)))
	{
		# One-dimensional array.
		djvcCompounded = cumprod(djvcChanges+1)
	}
	else
	{
		# Two-dimensional array.
		djvcCompounded = apply(djvcChanges+1, 2, cumprod)
	}

	list(djvcChanges = djvcChanges, djvcCompounded = djvcCompounded)
}

################################################
# Simulate DJVC compounded returns by first
# simulating share-price of S&P 500 and then
# using linear regression model.

# Parameters:
# sp500startPBook	Starting P/Book for S&P 500.
# sims			Number of simulations.
# years			Number of years per simulation.

# Monthly.
djvc$simulateCompoundedReturnsMonthly = function(sp500startPBook, sims, years)
{
	months = 12 * years

	# Simulate monthly share-price for S&P 500.
	sp500sharePrice = sp500$simulateSharePriceMonthly(sp500startPBook, sims, years)

	# Share-price changes for S&P 500.
	sp500changes = sp500sharePrice / rbind(rep(sp500startPBook, sims), sp500sharePrice)[1:months,] - 1

	# Simulate DJCV from S&P 500 monthly price-changes.
	simDJVC = djvc$sp500LinearModel(sp500changes)

	list(sp500sharePrice = sp500sharePrice, sp500changes = sp500changes,
	     djvcChanges = simDJVC$djvcChanges, djvcCompounded = simDJVC$djvcCompounded)
}

# Yearly.
djvc$simulateCompoundedReturnsYearly = function(sp500startPBook, sims, years)
{
	# Perform monthly simulation.
	monthly = djvc$simulateCompoundedReturnsMonthly(sp500startPBook, sims, years*12)

	# Extract yearly results.
	monthly$djvcCompounded[1:years*12,]
}

################################################
# Sample historical returns of the DJVC index
# and compound them. This is a crude form of
# simulating future returns of the DJVC index.

# Parameters:
# sims			Number of simulations.
# months		Number of months to simulate
# years			Number of years to simulate.

djvc$sampleCompoundedReturnsMonthly = function(sims, months)
{
	x = sample(djvc$priceChangesMonthly+1, sims*months, replace=TRUE)
	dim(x) = c(sims, months)
	apply(x, 1, cumprod)
}

djvc$sampleCompoundedReturnsYearly = function(sims, years)
{
	x = djvc$sampleCompoundedReturnsMonthly(sims, years*12)
	x[(1:years)*12,]
}

################################################
################################################
# S&P 500 Monte Carlo simulations.

# Number of Monte Carlo simulations.
sims = 1000

# Number of years in each Monte Carlo simulation for S&P 500.
years = requiredYears(sp500$retainOverEarnings, sp500$ROE, 0.01)

# Monte Carlo simulations of S&P 500 equity, earnings, payout, dividend, net buyback.
simEquity = sp500$simulateEquity(sims, years)

################################################
# Histograms and QQ plots of Monte Carlo
# simulated earnings, payout and equity.

# Plot for selected years.
#someYears = 2:10
someYears = floor(seq(20, years, length.out=9))

for (year in someYears)
{
	# Earnings Histograms.
	#emf(paste("Histogram Earnings Year", year, "(S&P 500).emf"))
	hist(simEquity$earnings[year,], xlab="Earnings", main=paste("Year", year), probability=TRUE, nclass=50)
	#dev.off()

	# Earnings QQ plots.
	#emf(paste("QQ-Plot Earnings Year", year, "(S&P 500).emf"))
	qqnorm(log(simEquity$earnings[year,]), main=paste("Year", year))
	qqline(log(simEquity$earnings[year,]), col=2, lwd=2, lty=2)
	#dev.off()

	# Dividend QQ plots.
	#emf(paste("QQ-Plot Dividend Year", year, "(S&P 500).emf"))
	qqnorm(log(simEquity$dividend[year,]), main=paste("Year", year))
	qqline(log(simEquity$dividend[year,]), col=2, lwd=2, lty=2)
	#dev.off()

	# NetBuyback QQ plots.
	#emf(paste("QQ-Plot NetBuyback Year", year, "(S&P 500).emf"))
	qqnorm(log(simEquity$netBuyback[year,]), main=paste("Year", year))
	qqline(log(simEquity$netBuyback[year,]), col=2, lwd=2, lty=2)
	#dev.off()

	# Payout QQ plots.
	#emf(paste("QQ-Plot Payout Year", year, "(S&P 500).emf"))
	qqnorm(log(simEquity$payout[year,]), main=paste("Year", year))
	qqline(log(simEquity$payout[year,]), col=2, lwd=2, lty=2)
	#dev.off()

	# Equity QQ plots.
	#emf(paste("QQ-Plot Equity Year", year, "(S&P 500).emf"))
	qqnorm(log(simEquity$equity[year,]), main=paste("Year", year))
	qqline(log(simEquity$equity[year,]), col=2, lwd=2, lty=2)
	#dev.off()
}

################################################
# Payout Sum

# Cumulative sums of payouts.
payoutSums = apply(simEquity$payout, 2, cumsum)

# Mean and sd for each year.
means = apply(payoutSums, 1, mean)
sds = apply(payoutSums, 1, sd)

# Plot for these years.
someYears = c(2,5,10,15,20,30,50,75,100)

for (year in someYears)
{
	#emf(paste("PayoutSum Histogram Year", year,"(S&P 500).emf"))
	hist(payoutSums[year,], probability=TRUE, nclass=100, xlab="PayoutSum", main=paste("Year", year))
	fit = fitdistr(payoutSums[year,], "lognormal")
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()
}

# Curve fit mean.
dat = data.frame(x=1:years, y=means)
fit = nls(y~a*exp(b*x)+c, data=dat, start=list(a=2,b=0.05,c=-2), weights=x^(-2), trace=TRUE)
someYears = floor(seq(1, years, length.out=50))
#emf("PayoutSum Mean (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="PayoutSum Mean", main="PayoutSum Mean (S&P 500)")
lines(predict(fit))
#dev.off()

# Curve fit sd (this doesn't work very well).
dat = data.frame(x=1:years, y=sds)
#fit = nls(y~a*exp(b*x)+c, data=dat, start=list(a=2,b=0.05,c=-2), trace=TRUE)
fit = nls(log(y)~log(a*exp(b*x)-1)+c, data=dat, start=list(a=1,b=0.05,c=-1), trace=TRUE)
someYears = floor(seq(1, years, length.out=50))
#emf("PayoutSum Stdev (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="PayoutSum Stdev", main="PayoutSum Stdev (S&P 500)")
lines(predict(fit))
#dev.off()

# Find log-normal parameters for each year.
fits = apply(payoutSums, 1, function(x) fitdistr(x,"lognormal"))
meanlogs = as.numeric(lapply(fits, function(x) (x$estimate["meanlog"])))
sdlogs = as.numeric(lapply(fits, function(x) (x$estimate["sdlog"])))

# Curve fit meanlogs.
dat = data.frame(x=1:years, y=meanlogs)
fit = nls(y~log(exp(a*x)-1)+b, data=dat, start=list(a=0.05,b=0), trace=TRUE)
sub = floor(seq(1, years, length.out=50))	# Plot for these years
someYears = c(sub, 1:6, 8, 10, 12, 14)
#emf("PayoutSum Mu (S&P 500).emf")
plot(someYears, meanlogs[someYears], xlab="Year", ylab=expression(paste("PayoutSum  ", plain(mu))), main=expression(paste("PayoutSum ", plain(mu), " (S&P 500)")))
lines(predict(fit))
#dev.off()

# Curve fit sdlogs.
dat = data.frame(x=1:years, y=sdlogs)
fit = nls(y~a*x^b+c*x^d, data=dat, start=list(a=0.5,b=-0.5,c=0.02,d=0.5), trace=TRUE)
someYears = floor(seq(1, years, length.out=50))	# Plot for these years
someYears = c(sub, 1:8)
#emf("PayoutSum Sigma (S&P 500).emf")
plot(someYears, sdlogs[someYears], xlab="Year", ylab=expression(paste("PayoutSum  ", plain(sigma))), main=expression(paste("PayoutSum ", plain(sigma), " (S&P 500)")))
lines(predict(fit))
#dev.off()

################################################
# Earnings

# Means and SDs for each year's simulated earnings.
means = apply(simEquity$earnings, 1, mean)
sds = apply(simEquity$earnings, 1, sd)

# Plot for these years.
someYears = floor(seq(1, years, length.out=50))

# Curve fit means.
dat = data.frame(x=1:years, y=means)
fit = lm(log(y)~x, data=dat)
#emf("Earnings Mean (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="Earnings Mean", main="Earnings Mean (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

# Curve fit SD.
dat = data.frame(x=1:years, y=sds)
fit = lm(log(y)~x, data=dat)
#emf("Earnings Stdev (S&P 500).emf")
plot(someYears, sds[someYears], xlab="Year", ylab="Earnings Stdev", main="Earnings Stdev (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

################################################
# Dividends

# Means and SDs for each year's simulated dividends.
means = apply(simEquity$dividend, 1, mean)
sds = apply(simEquity$dividend, 1, sd)

# Plot for these years.
someYears = floor(seq(1, years, length.out=50))

# Curve fit means.
dat = data.frame(x=1:years, y=means)
fit = lm(log(y)~x, data=dat)
#emf("Dividend Mean (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="Dividend Mean", main="Dividend Mean (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

# Curve fit SD.
dat = data.frame(x=1:years, y=sds)
fit = lm(log(y)~x, data=dat)
#emf("Dividend Stdev (S&P 500).emf")
plot(someYears, sds[someYears], xlab="Year", ylab="Dividend Stdev", main="Dividend Stdev (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

################################################
# Share Buyback Net of Issuance

# Means and SDs for each year's simulated net buybacks.
means = apply(simEquity$netBuyback, 1, mean)
sds = apply(simEquity$netBuyback, 1, sd)

# Plot for these years.
someYears = floor(seq(1, years, length.out=50))

# Curve fit means.
dat = data.frame(x=1:years, y=means)
fit = lm(log(y)~x, data=dat)
#emf("NetBuyback Mean (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="Net Buyback Mean", main="Net Share Buyback Mean (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

# Curve fit SD.
dat = data.frame(x=1:years, y=sds)
fit = lm(log(y)~x, data=dat)
#emf("NetBuyback Stdev (S&P 500).emf")
plot(someYears, sds[someYears], xlab="Year", ylab="Net Buyback Stdev", main="Net Share Buyback Stdev (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

################################################
# Payout

# Means and SDs for each year's simulated payouts.
means = apply(simEquity$payout, 1, mean)
sds = apply(simEquity$payout, 1, sd)

# Subset of observations to plot.
someYears = floor(seq(1, years, length.out=50))

# Curve fit mean.
dat = data.frame(x=1:years, y=means)
fit = lm(log(y)~x, data=dat)
#emf("Payout Mean (S&P 500).emf")
plot(someYears, means[someYears], xlab="Year", ylab="Payout Mean", main="Payout Mean (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

# Curve fit SD.
dat = data.frame(x=1:years, y=sds)
fit = lm(log(y)~x, data=dat)
#emf("Payout Stdev (S&P 500).emf")
plot(someYears, sds[someYears], xlab="Year", ylab="Payout Stdev", main="Payout Stdev (S&P 500)", log="y")
lines(1:years, exp(predict(fit)))
#dev.off()

################################################
# Equity

# Means and SDs for each year's simulated equity.
means = apply(simEquity$equity, 1, mean)
sds = apply(simEquity$equity, 1, sd)

# Log-normal curve-fittings for each year's simulated equity.
fits = apply(simEquity$equity, 1, function(x) fitdistr(x,"lognormal"))
meanlogs = as.numeric(lapply(fits, function(x) (x$estimate["meanlog"])))
sdlogs = as.numeric(lapply(fits, function(x) (x$estimate["sdlog"])))

# Plot for these years.
someYears = floor(seq(1, years+1, length.out=50))

# Curve fit means.
dat = data.frame(x=1:years, y=means)
fit = lm(log(y)~x, data=dat)
plot(someYears, means[someYears], xlab="Year", ylab="Equity Mean", main="Equity Mean (S&P 500)")
lines(1:years, exp(predict(fit)))
#curve(exp(0.04366526*x-0.03324157), add=T)

# Curve fit means, no constant.
fit = nls(y~exp(a*x), data=dat, start=list(a=0.04), trace=TRUE)
plot(someYears, means[someYears], xlab="Year", ylab="Equity Mean", main="Equity Mean (S&P 500)")
lines(1:years, predict(fit))

# Curve fit sds
dat = data.frame(x=1:years, y=sds)
fit = lm(log(y)~x, data=dat)
plot(someYears, sds[someYears], xlab="Year", ylab="Equity Stdev", main="Equity Stdev (S&P 500)", log="y")
#lines(1:years, exp(predict(fit)))
curve(exp(0.04366526*x-0.03324157)*sqrt(exp(0.03255^2*x)-1), add=T)

# Curve fit meanlogs
dat = data.frame(x=1:years, y=meanlogs)
fit = nls(y~a*x, data=dat, start=list(a=0.04), trace=TRUE)
#fit = lm(y~x, data=dat)
#emf("Equity Mu (S&P 500).emf")
plot(someYears, meanlogs[someYears], xlab="Year", ylab=expression(paste("Equity  ", plain(mu))), main=expression(paste("Equity ", plain(mu), " (S&P 500)")))
lines(1:years, predict(fit))
#dev.off()

# Curve fit SDlogs
dat = data.frame(x=1:years, y=sdlogs)
fit = nls(y~a*sqrt(x), data=dat, start=list(a=1), trace=TRUE)
#emf("Equity Sigma (S&P 500).emf")
plot(someYears, sdlogs[someYears], xlab="Year", ylab=expression(paste("Equity  ", plain(sigma))), main=expression(paste("Equity ", plain(sigma), " (S&P 500)")))
lines(1:years, predict(fit))
#dev.off()

# Plot histogram for year 8
year=8
#emf(paste("Histogram Equity Year", year, "(S&P 500).emf"))
hist(simEquity$equity[year,], nclass=20, probability=TRUE, main="Equity after Year 8 (S&P 500)", xlab="Equity")
curve(dlnorm(x, meanlog=0.345, sdlog=0.092), add=TRUE)
#curve(dlnorm(x, meanlog=meanlogs[year], sdlog=sdlogs[year]), add=TRUE)
#dev.off()

################################################
# Future price estimated by sampling historical P/Book
# distribution and Monte Carlo simulating the equity.

# Number of samples.
numSamples = 1e6

# Plot for these years.
someYears = c(2,4,7,10,15,20,30,50,100)

for (year in someYears)
{
	# Price = Equity * P/Book
	s = sample(simEquity$equity[year,], numSamples, replace=T) * sample(sp500$pbooks, numSamples, replace=T)

	# Curve fit.
	fit = fitdistr(s, "lognormal")

	#emf(paste("Price Sampled Year", year, "(S&P 500).emf"))
	hist(s, probability=T, nclass=100, xlab="Price", main=paste("Year", year))
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()
}

################################################
# Shares after share buyback and issuance.

# Starting P/Book ratios.
startPBooks = c(1, 3, 5)

# Holding periods in years.
someYears = c(2,5,10)
maxYears = max(someYears)

for (startPBook in startPBooks)
{
	# Simulate equity, earnings, etc.
	simEquity = sp500$simulateEquity(sims, maxYears)

	# Simulate P/Book ratios.
	simPBooks = sp500$simulatePBookYearly(startPBook, sims, maxYears)

	# Simulate share buyback.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooks, sims, maxYears)

	for (year in someYears)
	{
		#emf(paste("Shares (S&P 500 PBook=", startPBook, ", Year ", year, ").emf", sep=""))
		hist(shares[year,], probability=T, nclass=50, xlab="Shares", main=paste("P/Book=", startPBook, ", Year ", year, sep=""))
		abline(v=mean(shares[year,]), lty=2, lw=2)
		#dev.off()
	}
}

################################################
# Shares after share buyback and issuance.
# Plot 3d surfaces of mean and stdev for per-share
# equity, earnings, dividends and future prices.
# P/Books are Monte Carlo simulated yearly.

# Starting P/Book ratios.
startPBooks = seq(1, 5, 0.25)

# Holding periods in years.
#maxYears = 300
#someYears = seq(1, maxYears, 20)
maxYears = 30
someYears = seq(1, maxYears, 1)

# Pre-allocate arrays.
dim = dim=c(length(someYears),length(startPBooks))
sharesMeans = array(dim=dim)
sharesSDs = array(dim=dim)
equityPerShareMeans = array(dim=dim)
equityPerShareSDs = array(dim=dim)
earningsPerShareMeans = array(dim=dim)
earningsPerShareSDs = array(dim=dim)
dividendPerShareMeans = array(dim=dim)
dividendPerShareSDs = array(dim=dim)
pricePerShareMeans = array(dim=dim)
pricePerShareSDs = array(dim=dim)

# This takes 30 seconds to execute on a PC from 2011 using a single core.
system.time(
for (j in 1:length(startPBooks))
{
	# Simulate equity, earnings, etc.
	simEquity = sp500$simulateEquity(sims, maxYears)

	# Simulate P/Book ratios.
	simPBooks = sp500$simulatePBookYearly(startPBooks[j], sims, maxYears)

	# Simulate share buyback.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooks, sims, maxYears)

	for (i in 1:length(someYears))
	{
		year = someYears[i]

		# Shares, Mean and SD.
		sharesMeans[i,j] = mean(shares[year,])
		sharesSDs[i,j] = sd(shares[year,])

		# Equity Per Share, Mean and SD.
		equityPerShareMeans[i,j] = mean(simEquity$equity[year,]/shares[year,])
		equityPerShareSDs[i,j] = sd(simEquity$equity[year,]/shares[year,])

		# Earnings Per Share, Mean and SD.
		earningsPerShareMeans[i,j] = mean(simEquity$earnings[year,]/shares[year,])
		earningsPerShareSDs[i,j] = sd(simEquity$earnings[year,]/shares[year,])

		# Dividends Per Share, Mean and SD.
		dividendPerShareMeans[i,j] = mean(simEquity$dividend[year,]/shares[year,])
		dividendPerShareSDs[i,j] = sd(simEquity$dividend[year,]/shares[year,])

		# Price Per Share, Mean and SD.
		pricePerShareMeans[i,j] = mean(simEquity$equity[year,]*simPBooks[year,]/shares[year,])
		pricePerShareSDs[i,j] = sd(simEquity$equity[year,]*simPBooks[year,]/shares[year,])
	}
})

# Grid for plotting.
g = expand.grid(x=someYears, y=startPBooks)

# Screen perspectives for 3d plots.
screen1 = list(z=-60, y=0, x=-75)
screen2 = list(z=60, y=0, x=-75)

# Plot grid with shares mean.
#emf(paste("Shares Mean (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(sharesMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Shares Mean", rot=90), scales=list(arrows=F), screen=screen1)
#dev.off()

# Plot grid with shares sd.
#emf(paste("Shares Stdev (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(sharesSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Shares Stdev", rot=90), scales=list(arrows=F), screen=screen1)
#dev.off()

# Write tables for price-per-share mean and sd.
#write.table(t(format((equityPerShareMeans), digits=3)), "Equity Per Share Mean (S&P 500).txt", sep="\t", col.names=F, row.names=F)
#write.table(t(format((equityPerShareSDs), digits=3)), "Equity Per Share Stdev (S&P 500).txt", sep="\t", col.names=F, row.names=F)

# Plot grid with equity-per-share mean.
#emf(paste("Equity Per Share Mean (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(equityPerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Equity Per Share Mean", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with equity-per-share sd.
#emf(paste("Equity Per Share Stdev (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(equityPerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Equity Per Share Stdev", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with earnings-per-share mean.
#emf(paste("Earnings Per Share Mean (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(earningsPerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Earnings Per Share Mean", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with earnings-per-share sd.
#emf(paste("Earnings Per Share Stdev (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(earningsPerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Earnings Per Share Stdev", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with dividend-per-share mean.
#emf(paste("Dividend Per Share Mean (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(dividendPerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Dividend Per Share Mean", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with dividend-per-share sd.
#emf(paste("Dividend Per Share Stdev (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(dividendPerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Dividend Per Share Stdev", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Write tables for price-per-share mean and sd.
#write.table(t(format((pricePerShareMeans), digits=3)), "Price Per Share Mean (S&P 500).txt", sep="\t", col.names=F, row.names=F)
#write.table(t(format((pricePerShareSDs), digits=3)), "Price Per Share Stdev (S&P 500).txt", sep="\t", col.names=F, row.names=F)

# Plot grid with price-per-share mean.
#emf(paste("Price Per Share Mean (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(pricePerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Price Per Share Mean", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Plot grid with price-per-share sd.
#emf(paste("Price Per Share Stdev (S&P 500, ", maxYears, " Years).emf", sep=""))
g$z = as.vector(pricePerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Price Per Share Stdev", rot=90), scales=list(arrows=F), screen=screen2)
#dev.off()

# Equity per share mean, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=equityPerShareMeans[,i]))
equityPerShareMeanGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
equityPerShareMeanOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(equityPerShareMeanGrowth)
summary(equityPerShareMeanOffset)

# Equity per share stdev, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=equityPerShareSDs[,i]))
equityPerShareSDGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
equityPerShareSDOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(equityPerShareSDGrowth)
summary(equityPerShareSDOffset)

# Equity per share stdev, check fits.
for (i in 1:length(startPBooks))
{
	plot(equityPerShareSDs[,i])
	#lines(exp(predict(fits[[i]])))
	lines((1 + equityPerShareSDGrowth[i])^(1:maxYears) * equityPerShareSDOffset[i])
	Sys.sleep(1)
}

# Earnings per share mean, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=earningsPerShareMeans[,i]))
earningsPerShareMeanGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
earningsPerShareMeanOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(earningsPerShareMeanGrowth)
summary(earningsPerShareMeanOffset)

# Earnings per share stdev, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=earningsPerShareSDs[,i]))
earningsPerShareSDGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
earningsPerShareSDOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(earningsPerShareSDGrowth)
summary(earningsPerShareSDOffset)

# Earnings per share stdev, check fits.
for (i in 1:length(startPBooks))
{
	plot(earningsPerShareSDs[,i])
	#lines(exp(predict(fits[[i]])))
	lines((1 + earningsPerShareSDGrowth[i])^(1:maxYears) * earningsPerShareSDOffset[i])
	Sys.sleep(1)
}

# Dividend per share mean, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=dividendPerShareMeans[,i]))
dividendPerShareMeanGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
dividendPerShareMeanOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(dividendPerShareMeanGrowth)
summary(dividendPerShareMeanOffset)

# Dividend per share stdev, growth rates.
fits = foreach(i=1:length(startPBooks)) %do% lm(log(y)~x, data=data.frame(x=someYears, y=dividendPerShareSDs[,i]))
dividendPerShareSDGrowth = exp(as.numeric(sapply(fits, function (x) (x$coefficients[2]))))-1
dividendPerShareSDOffset = exp(as.numeric(sapply(fits, function (x) (x$coefficients[1]))))
summary(dividendPerShareSDGrowth)
summary(dividendPerShareSDOffset)

# Dividend per share stdev, check fits.
for (i in 1:length(startPBooks))
{
	plot(dividendPerShareSDs[,i])
	#lines(exp(predict(fits[[i]])))
	lines((1 + dividendPerShareSDGrowth[i])^(1:maxYears) * dividendPerShareSDOffset[i])
	Sys.sleep(1)
}

################################################
# Per-share equity, earnings, dividends and price.

# Start equity and price per share.
startEquityPerShare = 666.97
startPricePerShare = 1426.19
startPBook = startPricePerShare / startEquityPerShare
startYear = 2012 # 2012-12-31

# Simulate equity, earnings, etc.
simEquity = sp500$simulateEquity(sims, years)

# Simulate P/Book ratios.
simPBooks = sp500$simulatePBookYearly(startPBook, sims, years)

# Simulate share buybacks.
shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooks, sims, years)

# Equity, earnings, dividends and price per share.
equityPerShare = simEquity$equity/shares
earningsPerShare = simEquity$earnings/shares
dividendPerShare = simEquity$dividend/shares
pricePerShare = equityPerShare*simPBooks

# Means and SDs for each year.
equityMeans = apply(equityPerShare, 1, mean)
equitySDs = apply(equityPerShare, 1, sd)
earningsMeans = apply(earningsPerShare, 1, mean)
earningsSDs = apply(earningsPerShare, 1, sd)
dividendMeans = apply(dividendPerShare, 1, mean)
dividendSDs = apply(dividendPerShare, 1, sd)
priceMeans = apply(pricePerShare, 1, mean)
priceSDs = apply(pricePerShare, 1, sd)

# Plot for these years.
someYears = 1:30

# Filename.
dateStr = paste(min(startYear+someYears), max(startYear+someYears), sep="-")

# Plot equity means.
#emf(paste("Equity Per Share Mean (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=equityMeans[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Equity Per Share, Mean", main="Equity Per Share, Mean (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot equity sd.
#emf(paste("Equity Per Share Stdev (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=equitySDs[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Equity Per Share, Stdev", main="Equity Per Share, Stdev (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot earnings means.
#emf(paste("Earnings Per Share Mean (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=earningsMeans[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Earnings Per Share, Mean", main="Earnings Per Share, Mean (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot earnings sd.
#emf(paste("Earnings Per Share Stdev (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=earningsSDs[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Earnings Per Share, Stdev", main="Earnings Per Share, Stdev (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot dividend means.
#emf(paste("Dividend Per Share Mean (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=dividendMeans[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Dividend Per Share, Mean", main="Dividend Per Share, Mean (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot dividend sd.
#emf(paste("Dividend Per Share Stdev (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=dividendSDs[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Dividend Per Share, Stdev", main="Dividend Per Share, Stdev (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot price means.
#emf(paste("Price Per Share Mean (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=priceMeans[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Price Per Share, Mean", main="Price Per Share, Mean (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

# Plot price sd.
#emf(paste("Price Per Share Stdev (S&P 500, ", dateStr,").emf", sep=""))
dat = data.frame(x=startYear+someYears, y=priceSDs[someYears]*startEquityPerShare)
fit = lm(log(y)~x, data=dat)
plot(dat, xlab="Year", ylab="Price Per Share, Stdev", main="Price Per Share, Stdev (S&P 500)", panel.first=grid())
lines(dat$x, exp(predict(fit)))
#dev.off()

################################################
# Value yield distribution plots.

# Plot for these P/Book ratios.
startPBooks = seq(1, 5, length.out=9)

for (pbook in startPBooks)
{
	# Monte Carlo simulations of equity, earnings, payout.
	simEquity = sp500$simulateEquity(sims, years)

	# Simulate P/Book ratios.
	simPBooks = sp500$simulatePBookYearly(pbook, sims, years)

	# Simulate share buybacks.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooks, sims, years)

	# Dividend per share.
	dividendPerShare = simEquity$dividend/shares

	# Find value yields.
	vysPayout = valueYieldGrowth(pbook, simEquity$payout, simEquity$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, years)
	vysDividendPerShare = valueYieldGrowth(pbook, dividendPerShare, simEquity$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, years)
	vys = valueYieldConst(pbook, simEquity$payout, simEquity$equity, sp500$meanROE, sims, years)

	# Difference, no outliers.
	vysPayout2 = valueYieldRemoveOutliers(vysPayout)
	dif = vysPayout2$yields - vysDividendPerShare$yields[vysPayout2$idx]

	# Check that value yields are found, that is,
	# optimization errors should approach zero.
	summary(vysPayout$errors)
	summary(vysDividendPerShare$errors)

	# Print statistics.
	summary(vysPayout$yields)
	sd(vysPayout$yields)
	summary(vysDividendPerShare$yields)
	sd(vysDividendPerShare$yields)

	# Plot value yield histogram, Payout
	#emf(paste("Histogram, Value Yield, Without Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	hist(vysPayout$yields, nclass=50, probability=TRUE, main=paste("P/Book=", pbook, " (S&P 500)", sep=""), xlab="Value Yield (Without Share Buyback)")
	# Only fit positive value yields to log-normal PDF.
	fit = fitdistr(vysPayout$yields[vysPayout$yields>0], "lognormal")
	fit
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()

	# Plot value yield histogram, Dividend Per Share
	#emf(paste("Histogram, Value Yield, With Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	hist(vysDividendPerShare$yields, nclass=50, probability=TRUE, main=paste("P/Book=", pbook, " (S&P 500)", sep=""), xlab="Value Yield (With Share Buyback)")
	# Only fit positive value yields to log-normal PDF.
	fit = fitdistr(vysDividendPerShare$yields[vysDividendPerShare$yields>0], "lognormal")
	fit
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()

	# Plot value yield difference histogram.
	#emf(paste("Histogram, Value Yield, Difference (S&P 500 PBook=", pbook, ").emf", sep=""))
	hist(dif, nclass=50, probability=TRUE, main=paste("P/Book=", pbook, " (S&P 500)", sep=""), xlab="Value Yield Difference (Without - With Share Buyback)")
	abline(v=mean(dif), lty=2, lw=2)
	#dev.off()

	# QQ-Plot log-normal, value yield, Payout
	#emf(paste("QQ-Plot Log-Normal, Value Yield, Without Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	qqnorm(log(vysPayout$yields), main=paste("P/Book=", pbook, " (S&P 500)", sep=""))
	qqline(log(vysPayout$yields), col = 2, lwd=2, lty=2)
	#dev.off()

	# QQ-Plot log-normal, value yield, Dividend Per Share
	#emf(paste("QQ-Plot Log-Normal, Value Yield, With Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	qqnorm(log(vysDividendPerShare$yields), main=paste("P/Book=", pbook, " (S&P 500)", sep=""))
	qqline(log(vysDividendPerShare$yields), col = 2, lwd=2, lty=2)
	#dev.off()

	# QQ-Plot normal, value yield, Payout
	#emf(paste("QQ-Plot Normal, Value Yield, Without Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	qqnorm(vysPayout$yields, main=paste("P/Book=", pbook, " (S&P 500)", sep=""))
	qqline(vysPayout$yields, col = 2, lwd=2, lty=2)
	#dev.off()

	# QQ-Plot normal, value yield, Dividend Per Share
	#emf(paste("QQ-Plot Normal, Value Yield, With Share Buyback (S&P 500 PBook=", pbook, ").emf", sep=""))
	qqnorm(vysDividendPerShare$yields, main=paste("P/Book=", pbook, " (S&P 500)", sep=""))
	qqline(vysDividendPerShare$yields, col = 2, lwd=2, lty=2)
	#dev.off()
}

################################################
# Value yield distribution fits and parameters.
# Terminal value is calculated as mean
# historical ROE multiplied by the last
# equity from Monte Carlo simulation.

# P/Book ratios.
startPBooks = seq(0.2, 10, 0.1)

# Preallocate arrays.
means = array(dim=length(startPBooks))
sds = array(dim=length(startPBooks))
meanlogs = array(dim=length(startPBooks))
sdlogs = array(dim=length(startPBooks))

# This may take up to 5 minutes to execute on a PC from 2011 using a single core.
# Using the slow version of valueYieldGrowth() takes 30 minutes.
system.time(
for (i in 1:length(startPBooks))
{
	# Monte Carlo simulations of equity, earnings, payout.
	simEquity = sp500$simulateEquity(sims, years)

	# Find value yields.
#	vys = valueYieldConst(startPBooks[i], simEquity$payout, simEquity$equity, sp500$meanROE, sims, years)
	vys = valueYieldGrowth(startPBooks[i], simEquity$payout, simEquity$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, years)

	# Remove outliers as they are likely caused by optimization errors.
	vys = valueYieldRemoveOutliers(vys)

	# Mean and SD.
	means[i] = mean(vys$yields)
	sds[i] = sd(vys$yields)

	# Meanlog and SDlog, only use positive value yields.
	fit = fitdistr(vys$yields[vys$yields>0], "lognormal")
	meanlogs[i] = fit$estimate["meanlog"]
	sdlogs[i] = fit$estimate["sdlog"]
})

# Curve fit mean
dat = data.frame(x=startPBooks, y=means)
fit = nls(y~a/x+b, data=dat, start=list(a=1,b=0), trace=TRUE)
#emf("Value Yield Mean (S&P 500).emf")
plot(dat, xlab="P/Book", ylab="Value Yield Mean", main="Value Yield Mean (S&P 500)")
lines(startPBooks, predict(fit))
#dev.off()

# Curve fit meanlog
dat = data.frame(x=startPBooks, y=meanlogs)
fit = nls(y~a*x^b+c, data=dat, start=list(a=1,b=-1,c=0), trace=TRUE)
#emf("Value Yield Mu (S&P 500).emf")
plot(dat, xlab="P/Book", ylab=expression(paste("Value Yield  ", plain(mu))), main=expression(paste("Value Yield ", plain(mu), " (S&P 500)")))
lines(startPBooks, predict(fit))
#dev.off()

# Curve fit sd
dat = data.frame(x=startPBooks, y=sds)
fit = nls(y~a*x^b+c, data=dat, start=list(a=1,b=-1,c=0), trace=TRUE)
#emf("Value Yield Stdev (S&P 500).emf")
plot(dat, xlab="P/Book", ylab="Value Yield Stdev", main="Value Yield Stdev (S&P 500)")
lines(startPBooks, predict(fit))
#dev.off()

# Curve fit sdlog
dat = data.frame(x=startPBooks, y=sdlogs)
fit = nls(y~a*x^b+c, data=dat, start=list(a=1,b=-1,c=0), trace=TRUE)
#emf("Value Yield Sigma (S&P 500).emf")
plot(dat, xlab="P/Book", ylab=expression(paste("Value Yield  ", plain(sigma))), main=expression(paste("Value Yield ", plain(sigma), " (S&P 500)")))
lines(startPBooks, predict(fit))
#dev.off()

################################################
# Value yield when the terminal value is the
# price resulting from sampling historical
# P/Book distribution and Monte Carlo simulation
# of equity.

# Starting P/Book ratios.
startPBooks = c(1, 3, 5)

# Holding periods in years.
someYears = c(2,5,10)
maxYears = max(someYears)

for (startPBook in startPBooks)
{
	# Monte Carlo simulations of equity, earnings, payout.
	simEquity = sp500$simulateEquity(sims, maxYears)

	for (year in someYears)
	{
		# Sample P/Book ratios from historical distribution.
		endPBooks = sample(sp500$pbooks, sims, replace=T)

		vys = valueYieldPBook(startPBook, endPBooks, simEquity$payout, simEquity$equity, sims, year)

		#emf(paste("Value Yield Sampled PBook (S&P 500 PBook=", startPBook, ", Year ", year, ").emf", sep=""))
		hist (vys$yields, probability=T, nclass=50, xlab="Value Yield", main=paste("P/Book=", startPBook, ", Year ", year, sep=""))
		curve(dnorm(x, mean=mean(vys$yields), sd=sd(vys$yields)), add=TRUE)
		#dev.off()
	}
}

################################################
# Value yield when the terminal value is the
# price resulting from Monte Carlo simulation
# of P/Book and equity.

# Starting P/Book ratios.
startPBooks = c(1, 3, 5)

# Holding periods in years.
someYears = c(2,5,10)
maxYears = max(someYears)

for (startPBook in startPBooks)
{
	# Simulate equity, earnings, etc.
	simEquity = sp500$simulateEquity(sims, maxYears)

	# Monte Carlo simulations of P/Book ratios.
	simPBooks = sp500$simulatePBookYearly(startPBook, sims, maxYears)

	for (year in someYears)
	{
		# Find value yields.
		vys = valueYieldPBook(startPBook, simPBooks[year,], simEquity$payout, simEquity$equity, sims, year)

		# Plot histogram and fitted curve.
		#emf(paste("Value Yield Simulated PBook (S&P 500 PBook=", startPBook, ", Year ", year, ").emf", sep=""))
		hist(vys$yields, probability=T, nclass=50, xlab="Value Yield", main=paste("P/Book=", startPBook, ", Year ", year, sep=""))
		curve(dnorm(x, mean=mean(vys$yields), sd=sd(vys$yields)), add=TRUE)
		#dev.off()
	}
}

################################################
# Plot 3d surfaces for value yield mean and sd,
# when the terminal value is the price resulting
# from Monte Carlo simulation of P/Book and equity.

# Starting P/Book ratios.
startPBooks = seq(1, 5, 0.25)

# Holding periods in years.
maxYears = 30
maxDays = yearsToTradingDays(maxYears)
someYears = seq(1, maxYears, 1)

# Pre-allocate arrays.
dim = dim=c(length(someYears),length(startPBooks))
vyPayoutMeans = array(dim=dim)
vyPayoutSDs = array(dim=dim)
vyDividendPerShareMeans = array(dim=dim)
vyDividendPerShareSDs = array(dim=dim)
vyDifMeans = array(dim=dim)
vyDifSDs = array(dim=dim)
priceMeans = array(dim=dim)
priceSDs = array(dim=dim)

# This may take 30 minutes to execute on a PC from 2011 using a single core.
system.time(
for (j in 1:length(startPBooks))
{
	startPBook = startPBooks[j]

	# Simulate equity, earnings, etc.
	simEquity = sp500$simulateEquity(sims, maxYears)

	# Monte Carlo simulations of P/Book ratios.
	# It is necessary to use daily simulation of P/Book ratios
	# because the yearly simulation is too coarse for this,
	# especially for the first year of simulation.
	simPBooks = sp500$simulatePBookDaily(startPBook, sims, maxDays)
	simPBooksYearly = pbookDailyToYearly(simPBooks, maxYears)

	# Simulate share buybacks.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooksYearly, sims, maxYears)

	for (i in 1:length(someYears))
	{
		year = someYears[i]

		# Find value yields, payouts.
		vyPayout = valueYieldPBook(startPBook, simPBooksYearly[year,], simEquity$payout, simEquity$equity, sims, year)

		# Find value yields, dividend per share.
		vyDividendPerShare = valueYieldPBook(startPBook, simPBooksYearly[year,], simEquity$dividend/shares, simEquity$equity/shares, sims, year)

		# Value yield difference.
		vyDif = vyPayout$yields - vyDividendPerShare$yields

		# Value yield, mean and SD, payout.
		vyPayoutMeans[i,j] = mean(vyPayout$yields)
		vyPayoutSDs[i,j] = sd(vyPayout$yields)

		# Value yield, mean and SD, dividend per share.
		vyDividendPerShareMeans[i,j] = mean(vyDividendPerShare$yields)
		vyDividendPerShareSDs[i,j] = sd(vyDividendPerShare$yields)

		# Value yield difference, mean and SD.
		vyDifMeans[i,j] = mean(vyDif)
		vyDifSDs[i,j] = sd(vyDif)

		# Price = simulated P/Book * simulated equity
		prices = simPBooks[year,] * simEquity$equity[year,]

		# Price, mean and SD.
		priceMeans[i,j] = mean(prices)
		priceSDs[i,j] = sd(prices)
	}
})

# Grid for plotting.
g = expand.grid(x=someYears, y=startPBooks)

# Plot grid with value yield mean, payout.
#emf("Value Yield Mean, Without Share Buyback (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyPayoutMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean (Without Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot polynomial surface fit.
fit1 = surf.ls(6, g)
gp1 = expand.grid(x=someYears, y=startPBooks)
gp1$z = as.vector(predict(fit1, gp1$x, gp1$y))
wireframe(z~x*y, data=gp1, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))

# Plot LOESS surface fit.
fit2 = loess(z~x*y, data=g, degree=2, span=0.05)
gp2 = expand.grid(x=someYears, y=startPBooks)
gp2$z = as.vector(predict(fit2, data=gp2))
wireframe(z~x*y, data=gp2, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))

# Plot grid with value yield sd, payout.
#emf("Value Yield Stdev, Without Share Buyback (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyPayoutSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Stdev (Without Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield mean, dividend per share.
#emf("Value Yield Mean, With Share Buyback (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyDividendPerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean (With Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield sd, dividend per share.
#emf("Value Yield Stdev, With Share Buyback (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyDividendPerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Stdev (With Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield difference mean.
#emf("Value Yield Difference Mean (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyDifMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Difference, Mean", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield difference sd.
#emf("Value Yield Difference Stdev (S&P 500, Simulated PBook).emf")
g$z = as.vector(vyDifSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Difference, Stdev", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with price mean.
#emf("Price-Sim Mean (S&P 500, Simulated PBook).emf")
g$z = as.vector(priceMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Price Mean", rot=90), scales=list(arrows=F), screen=list(z=60, y=0, x=-75))
#dev.off()

# Plot grid with price sd.
#emf("Price-Sim Stdev (S&P 500, Simulated PBook).emf")
g$z = as.vector(priceSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Price Stdev", rot=90), scales=list(arrows=F), screen=list(z=60, y=0, x=-75))
#dev.off()

# Write tables for value yield mean and sd.
#write.table(format((vyPayoutMeans), digits=1), "Value Yield Mean, Without Share Buyback (S&P 500, Simulated PBook).txt", sep="\t", col.names=F, row.names=F)
#write.table(format((vyPayoutSDs), digits=1), "Value Yield Stdev, Without Share Buyback (S&P 500, Simulated PBook).txt", sep="\t", col.names=F, row.names=F)
#write.table(format((vyDividendPerShareMeans), digits=2), "Value Yield Mean, With Share Buyback (S&P 500, Simulated PBook).txt", sep="\t", col.names=F, row.names=F)
#write.table(format((vyDividendPerShareSDs), digits=1), "Value Yield Stdev, With Share Buyback (S&P 500, Simulated PBook).txt", sep="\t", col.names=F, row.names=F)

# Write tables for price mean and sd.
#write.table(format(t(priceMeans), digits=3), "Price-Sim Mean (S&P 500).txt", sep="\t", col.names=F, row.names=F)
#write.table(format((priceSDs), digits=3), "Price-Sim Stdev (S&P 500).txt", sep="\t", col.names=F, row.names=F)

# Plot with rotation.
require(TeachingDemos)
g$z = as.vector(priceMeans)
rotate.wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Price Mean", rot=90), scales=list(arrows=F), screen=list(z=60, y=0, x=-75))

################################################
# Plot 3d surfaces for value yield mean and sd,
# when the terminal value is the price resulting
# from sampling historical P/Book distribution
# and Monte Carlo simulation of equity.

# Starting P/Book ratios.
startPBooks = seq(1, 5, 0.25)

# Holding periods in years.
someYears = 1:30
maxYears = max(someYears)

# Preallocate arrays.
dim = dim=c(length(someYears),length(startPBooks))
vyPayoutMeans = array(dim=dim)
vyPayoutSDs = array(dim=dim)
vyDividendPerShareMeans = array(dim=dim)
vyDividendPerShareSDs = array(dim=dim)
vyDifMeans = array(dim=dim)
vyDifSDs = array(dim=dim)

# This may take 15 minutes to execute on a PC from 2011 using a single core.
system.time(
for (j in 1:length(startPBooks))
{
	startPBook = startPBooks[j]

	# Monte Carlo simulations of equity, earnings, payout.
	simEquity = sp500$simulateEquity(sims, maxYears)

	# Sample historical P/Book ratios.
	pbooks = sp500$sampleHistoricalPBook(sims, maxYears)

	# Simulate share buybacks.
	shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, pbooks, sims, maxYears)

	# Dividend per share.
	dividendPerShare = simEquity$dividend / shares

	for (i in 1:length(someYears))
	{
		year = someYears[i]

		# Value yield, payout.
		vyPayout = valueYieldPBook(startPBook, pbooks[year,], simEquity$payout, simEquity$equity, sims, year)

		# Value yield, dividend per share.
		vyDividendPerShare = valueYieldPBook(startPBook, pbooks[year,], dividendPerShare, simEquity$equity/shares, sims, year)

		# Value Yield difference.
		vyDif = vyPayout$yields - vyDividendPerShare$yields

		# Value yield, mean and SD, payout.
		vyPayoutMeans[i,j] = mean(vyPayout$yields)
		vyPayoutSDs[i,j] = sd(vyPayout$yields)

		# Value yield, mean and SD, dividend per share.
		vyDividendPerShareMeans[i,j] = mean(vyDividendPerShare$yields)
		vyDividendPerShareSDs[i,j] = sd(vyDividendPerShare$yields)

		# Value yield difference, mean and SD.
		vyDifMeans[i,j] = mean(vyDif)
		vyDifSDs[i,j] = sd(vyDif)
	}
})

# Grid for plotting.
g = expand.grid(x=someYears, y=startPBooks)

# Plot grid with value yield mean, payout.
#emf("Value Yield Mean, Without Share Buyback (S&P 500, Historical PBook).emf")
g$z = as.vector(vyPayoutMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean (Without Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield sd, payout.
#emf("Value Yield Stdev, Without Share Buyback (S&P 500, Historical PBook).emf")
g$z = as.vector(vyPayoutSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Stdev (Without Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield mean, dividend per share.
#emf("Value Yield Mean, With Share Buyback (S&P 500, Historical PBook).emf")
g$z = as.vector(vyDividendPerShareMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Mean (With Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield sd, dividend per share.
#emf("Value Yield Stdev, With Share Buyback (S&P 500, Historical PBook).emf")
g$z = as.vector(vyDividendPerShareSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Stdev (With Share Buyback)", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield difference mean.
#emf("Value Yield Difference Mean (S&P 500, Historical PBook).emf")
g$z = as.vector(vyDifMeans)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Difference Mean", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

# Plot grid with value yield difference sd.
#emf("Value Yield Difference Stdev (S&P 500, Historical PBook).emf")
g$z = as.vector(vyDifSDs)
wireframe(z~x*y, data=g, xlab="Year", ylab="P/Book", zlab=list(label="Value Yield Difference Stdev", rot=90), scales=list(arrows=F), screen=list(z=-145, y=0, x=-75))
#dev.off()

################################################
# Monte Carlo simulation of P/Book ratios.

# Starting P/Book ratio.
startPBook = 2.3

# Number of years and trading days to simulate.
years = 30
days = yearsToTradingDays(years)

# Monte Carlo simulations of S&P 500 equity, earnings, payout.
simEquity = sp500$simulateEquity(sims, years)

# Monte Carlo simulation of P/Book ratios.
simPBooks = sp500$simulatePBookDaily(startPBook, sims, days)

# Plot simulated P/Book time-series and autocorrelation.
for (sim in 1:9)
{
	# Plot P/Book time-series.
	#emf(paste("PBook Simulated No", sim, "(S&P 500).emf"))
	plot(simPBooks[,sim], type="l", xlab="Days", ylab="P/Book", main=paste("P/Book Simulated", sim, "(S&P 500)"))
	#dev.off()

	# Plot P/Book autocorrelation.
	#emf(paste("PBook Simulated Autocorrelation No", sim, "(S&P 500).emf"))
	l=acf(simPBooks[,sim], lag.max=length(simPBooks[,sim]), plot=FALSE)
	idx = floor(seq(1, length(l[[1]]), length.out=200))
	plot(l[idx], xlab="Lag/Days", ylab="Autocorrelation", main=paste("P/Book ACF", sim, "(S&P 500)"))
	#dev.off()
}

# Plot simulated P/Book distributions for selected years.
someYears = c(2,3,5,7,10,15,20,25,30)
for (year in someYears)
{
	# Number of trading days.
	day = yearsToTradingDays(year)

	# Histogram.
	#emf(paste("PBook Simulated Histogram Year", year, "(S&P 500).emf"))
	hist(simPBooks[day,], probability=T, nclass=100, xlab="P/Book", main=paste("Simulated P/Book Year", year, "(S&P 500)"))
	fit = fitdistr(simPBooks[day,], "lognormal")
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()

	# CDF.
	#emf(paste("PBook Simulated CDF Year", year, "(S&P 500).emf"))
	plot(ecdf(simPBooks[day,]), verticals=TRUE, xlab="P/Book", ylab="F(x)", panel.first=grid(), main=paste("Simulated P/Book CDF Year", year, "(S&P 500)"))
	#dev.off()

	# QQ-plot historical and simulated P/Book ratios.
	#emf(paste("PBook Simulated QQ-Plot Year", year, "(S&P 500).emf"))
	qqplot(sp500$pbooks, simPBooks[day,], xlab="Historical P/Book", ylab="Simulated P/Book", main=paste("Year", year))
	#dev.off()

	# Histogram for price calculated from P/Book and MC simulated equity.
	numSamples = 1e6
	a = sample(simPBooks[day,], numSamples, replace=T) * sample(simEquity$equity[year,], numSamples, replace=T)
	#emf(paste("Price Simulated Year", year, "(S&P 500).emf"))
	hist(a, probability=T, nclass=100, xlab="Price", main=paste("Year", year, "(S&P 500)"))
	fit = fitdistr(a, "lognormal")
	curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
	#dev.off()

	# CDF for price.
	numSamples = 2e3
	a = sample(simPBooks[day,], numSamples, replace=T) * sample(simEquity$equity[year,], numSamples, replace=T)
	#emf(paste("Price Simulated CDF Year", year, "(S&P 500).emf"))
	plot(ecdf(a), verticals=TRUE, xlab="Price", ylab="F(x)", panel.first=grid(), main=paste("Year", year, "(S&P 500)"))
	#dev.off()
}

################################################
# Option valuation for SPY (S&P 500 ETF) with
# expiration date December 18, 2015 as quoted
# on March 15, 2013.

# Last known equity on September 28, 2012.
# SPY's equity is 1/10 of the S&P 500.
lastKnownEquity = 661.93/10

# Equity for S&P 500 per share on March 14, 2013.
# The mean equity per share growth rate is about 5.6% per year
# and March 14, 2013 is about 6 months later than Sep 28, 2012,
# so the equity is expected to be around 2.8% higher.
startEquity = 680.46/10

# Price per share on March 14, 2013.
# Share price of SPY is 1/10 of S&P 500.
startPrice = 1563.23/10

# Starting P/Book ratio on March 14, 2013.
startPBook = startPrice / startEquity

# Number of years for equity simulation.
# Date of last known equity was Sep 28, 2012
# and option expiration date is Dec 18, 2015,
# the difference is about 3 years and 3 months.
# The MC simulated equity after 3 years has index 3. 
equityYears = 3

# Expected equity growth between Sep. 28 2015 and Dec. 18 2015.
# ISOdate(2015, 12, 18) - ISOdate(2015, 9, 28) # 81 days
# The mean equity per share growth rate is about 5.6% per year.
# The equity at Dec. 18 2015 is calculated from the MC simulated
# equity for Sep. 28 2015 and adjusted by this factor.
adjustEquity = 1.056^(81/365)

# Number of trading days for P/Book simulation
# between March 14, 2013 and December 18, 2015.
# ISOdate(2015, 12, 18) - ISOdate(2013, 3, 14) # 1009 days ~ 2.76 years
pbookYears = 2.76
days = yearsToTradingDays(pbookYears)
maxYears = ceiling(pbookYears)
maxDays = yearsToTradingDays(maxYears)

# Simulate P/Book ratios.
simPBooksDaily = sp500$simulatePBookDaily(startPBook, sims, maxDays)
simPBooksYearly = pbookDailyToYearly(simPBooksDaily, maxYears)

# Simulate equity, earnings, etc.
simEquity = sp500$simulateEquity(sims, maxYears)

# Simulate share buyback.
shares = simulateShareBuyback(simEquity$equity, simEquity$netBuyback, simPBooksYearly, sims, maxYears)

# Simulated share prices in the future.
# Calculated from the simulated P/Book ratios, simulated equity,
# adjustment to equity because the simulation and exercise dates are different,
# the starting equity per share, and the number of shares which changes
# because of share buyback and issuance.
sharePrices = simPBooksDaily[days,] * simEquity$equity[equityYears,] * adjustEquity * lastKnownEquity / shares[maxYears,]

# Option values, calls.
callValues = optionValuation(TRUE, calls$exercisePrices, calls$optionPrices, sharePrices, pbookYears)

# Option values, puts.
putValues = optionValuation(FALSE, puts$exercisePrices, puts$optionPrices, sharePrices, pbookYears)

########
# Plots of simulated share price.

# Histogram of simulated share price.
#emf("SPY MC Simulated Share Price Histogram.emf")
hist(sharePrices, xlab="Share Price", main="MC Simulated Share Price (SPY ETF, S&P 500)", probability=TRUE, nclass=50)
fit = fitdistr(sharePrices, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
abline(v=startPrice, lty=2, lw=2)
#dev.off()

# CDF of simulated share price.
#emf("SPY MC Simulated Share Price CDF.emf")
plot(ecdf(sharePrices), verticals=TRUE, xlab="Share Price", ylab="F(x)", main="MC Simulated Share Price (SPY ETF, S&P 500)", panel.first=grid())
abline(v=startPrice, lty=2, lw=2)
#dev.off()

########
# CDF plots of profits and value yields.

# Plot for these option prices and indices.
# Assume the call and put option chains have the same prices.
somePrices = c(80, 100, 120, 140, 160, 180, 200, 220, 240)
idx = which(calls$exercisePrices %in% somePrices)

for (j in 1:length(idx))
{
	# Index into option chains.
	i = idx[j]

	# Convenience variable.
	exercisePrice = calls$exercisePrices[i]

	# CDF for Profit, calls.
	#emf(paste("CDF Call Option Profit (SPY Strike ", exercisePrice, ").emf", sep=""))
	plot(ecdf(callValues$profits[i,]), verticals=TRUE, do.points=FALSE, main=paste("Exercise Price", exercisePrice, "(SPY, S&P 500)"), xlab="Profit", ylab="F(x)", panel.first=grid())
	#dev.off()

	# CDF for Value Yield, calls.
	#emf(paste("CDF Call Option Value Yield (SPY Strike ", exercisePrice, ").emf", sep=""))
	plot(ecdf(callValues$vys[i,]), verticals=TRUE, do.points=FALSE, main=paste("Exercise Price", exercisePrice, "(SPY, S&P 500)"), xlab="Value Yield", ylab="F(x)", panel.first=grid())
	#dev.off()

	# CDF for Profit, puts.
	#emf(paste("CDF Put Option Profit (SPY Strike ", exercisePrice, ").emf", sep=""))
	plot(ecdf(putValues$profits[i,]), verticals=TRUE, do.points=FALSE, main=paste("Exercise Price", exercisePrice, "(SPY, S&P 500)"), xlab="Profit", ylab="F(x)", panel.first=grid())
	#dev.off()

	# CDF for Value Yield, puts.
	#emf(paste("CDF Put Option Value Yield (SPY Strike ", exercisePrice, ").emf", sep=""))
	plot(ecdf(putValues$vys[i,]), verticals=TRUE, do.points=FALSE, main=paste("Exercise Price", exercisePrice, "(SPY, S&P 500)"), xlab="Value Yield", ylab="F(x)", panel.first=grid())
	#dev.off()
}

########
# Plots for call options.

# Exercise Price vs. Option Price, calls.
#emf("SPY Call Option Price (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, calls$optionPrices, panel.first=grid(), xlab="Exercise Price", ylab="Option Price (Bid Ask Avg.)", main="Call Option Price (SPY ETF, S&P 500)", cex=1.5)
lines(calls$exercisePrices, calls$optionPrices)
abline(v=startPrice, lty=2)
lines(x=c(calls$exercisePrices[1], startPrice, calls$exercisePrices[length(calls$exercisePrices)]), y=c(startPrice-calls$exercisePrices[1], 0, 0), lw=3)
#dev.off()

# Profit Means, calls.
#emf("SPY Call Profit Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, callValues$profitMeans, panel.first=grid(), xlab="Exercise Price", ylab="Profit Mean", main="Call Option Profit Mean (SPY ETF, S&P 500)")
lines(calls$exercisePrices, callValues$profitMeans)
abline(v=startPrice, lty=2)
#dev.off()

# Profit SDs, calls.
#emf("SPY Call Profit Stdev (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, callValues$profitSDs, panel.first=grid(), xlab="Exercise Price", ylab="Profit Stdev", main="Call Option Profit Stdev (SPY ETF, S&P 500)")
lines(calls$exercisePrices, callValues$profitSDs)
abline(v=startPrice, lty=2)
#dev.off()

# Profit probability, calls.
#emf("SPY Call Profit Probability (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, callValues$profitProbs, panel.first=grid(), xlab="Exercise Price", ylab="Profit Probability", main="Call Option Profit Probability (SPY ETF, S&P 500)")
lines(calls$exercisePrices, callValues$profitProbs)
abline(v=startPrice, lty=2)
#dev.off()

# Value yield means, calls.
#emf("SPY Call Value Yield Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, callValues$vyMeans, panel.first=grid(), xlab="Exercise Price", ylab="Value Yield Mean", main="Call Option, Value Yield Mean (SPY ETF, S&P 500)")
lines(calls$exercisePrices, callValues$vyMeans)
abline(v=startPrice, lty=2)
#dev.off()

# Value yield SDs, calls.
#emf("SPY Call Value Yield Stdev (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$exercisePrices, callValues$vySDs, panel.first=grid(), xlab="Exercise Price", ylab="Value Yield Stdev", main="Call Option, Value Yield Stdev (SPY ETF, S&P 500)")
lines(calls$exercisePrices, callValues$vySDs)
abline(v=startPrice, lty=2)
#dev.off()

# Option Price vs. Profit Mean, calls.
#emf("SPY Call Price vs Profit Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$optionPrices, callValues$profitMeans, xlab="Option Price (Minimize)", ylab="Profit Mean (Maximize)", main="Call Option Price vs. Profit Mean (SPY ETF, S&P 500)", panel.first=grid())
lines(calls$optionPrices, callValues$profitMeans)
#dev.off()

# Option Price vs. Profit Probability, calls.
#emf("SPY Call Price vs Profit Probability (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(calls$optionPrices, callValues$profitProbs, xlab="Option Price (Minimize)", ylab="Profit Probability (Maximize)", main="Call Option Price vs. Profit Probability (SPY ETF, S&P 500)", panel.first=grid())
lines(calls$optionPrices, callValues$profitProbs)
#dev.off()

########
# Plots for put options.

# Exercise Price vs. Option Price, puts.
#emf("SPY Put Option Price (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, puts$optionPrices, panel.first=grid(), xlab="Exercise Price", ylab="Option Price (Bid Ask Avg.)", main="Put Option Price (SPY ETF, S&P 500)", cex=1.5)
lines(puts$exercisePrices, puts$optionPrices)
abline(v=startPrice, lty=2)
lines(x=c(puts$exercisePrices[1], startPrice, puts$exercisePrices[length(puts$exercisePrices)]), y=c(0, 0, puts$exercisePrices[length(puts$exercisePrices)]-startPrice), lw=3)
#dev.off()

# Profit Means, puts.
#emf("SPY Put Profit Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, putValues$profitMeans, panel.first=grid(), xlab="Exercise Price", ylab="Profit Mean", main="Put Option Profit Mean (SPY ETF, S&P 500)")
lines(puts$exercisePrices, putValues$profitMeans)
abline(v=startPrice, lty=2)
#dev.off()

# Profit SDs, puts.
#emf("SPY Put Profit Stdev (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, putValues$profitSDs, panel.first=grid(), xlab="Exercise Price", ylab="Profit Stdev", main="Put Option Profit Stdev (SPY ETF, S&P 500)")
lines(puts$exercisePrices, putValues$profitSDs)
abline(v=startPrice, lty=2)
#dev.off()

# Profit probability, puts.
#emf("SPY Put Profit Probability (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, putValues$profitProbs, panel.first=grid(), xlab="Exercise Price", ylab="Profit Probability", main="Put Option Profit Probability (SPY ETF, S&P 500)")
lines(puts$exercisePrices, putValues$profitProbs)
abline(v=startPrice, lty=2)
#dev.off()

# Value yield means, puts.
#emf("SPY Put Value Yield Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, putValues$vyMeans, panel.first=grid(), xlab="Exercise Price", ylab="Value Yield Mean", main="Put Option, Value Yield Mean (SPY ETF, S&P 500)")
lines(puts$exercisePrices, putValues$vyMeans)
abline(v=startPrice, lty=2)
#dev.off()

# Value yield SDs, puts.
#emf("SPY Put Value Yield Stdev (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$exercisePrices, putValues$vySDs, panel.first=grid(), xlab="Exercise Price", ylab="Value Yield Stdev", main="Put Option, Value Yield Stdev (SPY ETF, S&P 500)")
lines(puts$exercisePrices, putValues$vySDs)
abline(v=startPrice, lty=2)
#dev.off()

# Option Price vs. Profit Mean, puts.
#emf("SPY Put Price vs Profit Mean (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$optionPrices, putValues$profitMeans, xlab="Option Price (Minimize)", ylab="Profit Mean (Maximize)", main="Put Option Price vs. Profit Mean (SPY ETF, S&P 500)", panel.first=grid())
lines(puts$optionPrices, putValues$profitMeans)
#dev.off()

# Option Price vs. Profit Probability, calls.
#emf("SPY Put Price vs Profit Probability (Expiring Dec 18, 2015, Quoted Mar 15, 2013).emf")
plot(puts$optionPrices, putValues$profitProbs, xlab="Option Price (Minimize)", ylab="Profit Probability (Maximize)", main="Put Option Price vs. Profit Probability (SPY ETF, S&P 500)", panel.first=grid())
lines(puts$optionPrices, putValues$profitProbs)
#dev.off()

################################################
################################################
# Coca-Cola Monte Carlo simulations.

# Number of Monte Carlo simulations.
sims = 1000

# Number of years in each Monte Carlo simulation for S&P 500.
years = requiredYears(coke$retainOverEarnings, coke$ROE, 0.01)

# Approximate P/Book for KO shares in March 2013.
pbook = 5.5

################################################
# (Coke) Value yield distribution plots.
# Terminal value is calculated as mean
# historical ROE multiplied by the last
# equity from Monte Carlo simulation.

# Perform Monte Carlo simulations of S&P 500 equity, earnings, payout.
simEquity = coke$simulateEquity(sims, years)

# Find value yields.
#vys = valueYieldConst(pbook, simEquity$payout, simEquity$equity, coke$meanROE, sims, years)
vys = valueYieldGrowth(pbook, simEquity$payout, simEquity$equity, coke$meanPayoutROE, coke$meanGrowth, sims, years)

# Remove outliers as they are likely caused by optimization errors.
vys = valueYieldRemoveOutliers(vys)

# Check that value yields are found, that is,
# optimization errors should approach zero.
summary(vys$errors)

# Print statistics.
summary(vys$yields)
sd(vys$yields)

# Plot value yield histogram
#emf("Histogram Value Yield (Coca-Cola, PBook=5.5).emf")
hist(vys$yields, nclass=100, probability=TRUE, main="Value Yield (Coca-Cola)", xlab="Value Yield")
fit = fitdistr(vys$yields, "lognormal")
fit
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# Plot value yield CDF.
#emf("CDF Value Yield (Coca-Cola, PBook=5.5).emf")
plot(ecdf(vys$yields), verticals=TRUE, do.points=FALSE, xlab="Value Yield", ylab="F(x)", panel.first=grid(), main="Value Yield (Coca-Cola)")
#dev.off()

################################################
# (Coke) Value yield distribution plots. Sampled ROE
# and Retain ratios are decreased exponentially.

# Sampled Retain ratio scale.
scaleRetainMin = 0.5
scaleRetain = (1-scaleRetainMin)*0.9^(1:years)+scaleRetainMin

# Samled ROE scale.
scaleROEMin = 0.67
scaleROE = (1-scaleROEMin)*0.95^(1:years)+scaleROEMin

# Total scale.
scaleTotal = scaleRetainMin * scaleROEMin

# Perform Monte Carlo simulations of S&P 500 equity, earnings, payout.
simEquity = coke$simulateEquity(sims, years, scaleRetain=scaleRetain, scaleROE=scaleROE)

# Find value yields.
# Note that mean ROE is scaled. This is used in
# estimating the terminal value.
#vys = valueYieldConst(pbook, simEquity$payout, simEquity$equity, coke$meanROE*scaleROEMin, sims, years)
vys = valueYieldGrowth(pbook, simEquity$payout, simEquity$equity, coke$meanPayoutROE*scaleROEMin, coke$meanGrowth*scaleTotal, sims, years)

# Remove outliers as they are likely caused by optimization errors.
vys = valueYieldRemoveOutliers(vys)

# Check that value yields are found, that is,
# optimization errors should approach zero.
summary(vys$errors)

# Print statistics.
summary(vys$yields)
sd(vys$yields)

# Plot value yield histogram
#emf("Histogram Value Yield (Coca-Cola, PBook=5.5, Scaled-MCS).emf")
hist(vys$yields, nclass=100, probability=TRUE, main="Value Yield, Scaled ROE and Retain/Earnings (Coca-Cola)", xlab="Value Yield")
fit = fitdistr(vys$yields, "lognormal")
fit
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# Plot value yield CDF.
#emf("CDF Value Yield (Coca-Cola, PBook=5.5, Scaled-MCS).emf")
plot(ecdf(vys$yields), verticals=TRUE, do.points=FALSE, xlab="Value Yield", ylab="F(x)", panel.first=grid(), main="Value Yield, Scaled ROE and Retain/Earnings (Coca-Cola)")
#dev.off()

##############
# (Coke) Present value when discount rate is S&P 500 value yield.

# Starting P/Book for S&P 500 index.
sp500pbook = 2.4

# Risk premium.
riskPremium = 0.02

# Discount rate is value yield for S&P 500 plus risk premium.
d = sp500$sampleValueYield(sims, sp500pbook) + riskPremium

# Present value using S&P 500 value yield plus risk premium as discount rate.
pv = foreach(i=1:sims, .combine='rbind') %do% presentValue(d[i], simEquity$payout[,i]) + terminalValueGrowth(d[i], coke$meanGrowth*scaleTotal, coke$meanPayoutROE*scaleROEMin*simEquity$equity[years,i], years)
pv = as.vector(pv)

# Histogram of Present Value / Equity.
#emf(paste("Coca-Cola PV-Book Histogram (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
hist(pv, nclass=100, probability=TRUE, xlab="Present Value / Equity", main=paste("Coca-Cola PV/Equity (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=pbook, lty=2, lw=2)
fit = fitdistr(pv, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# CDF of Present Value / Equity.
#emf(paste("Coca-Cola PV-Book CDF (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
plot(ecdf(pv), panel.first=grid(), verticals=TRUE, do.points=FALSE, xlab="Present Value / Equity", ylab="F(x)", main=paste("Coca-Cola PV/Equity (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=pbook, lty=2, lw=2)
#dev.off()

##############
# (Coke) Present value when discount rate is
# compounded return on DJVC index.

# Discount rate is the compounded return on DJVC index.
d2 = djvc$sampleCompoundedReturnsYearly(sims, years)

# Present value using DJVC compounded return as discount rate (no risk premium).
pv2 = foreach(i=1:sims, .combine='rbind') %do% sum(simEquity$payout[,i]/d2[,i]) + terminalValueGrowth(d2[years,i]^(1/years)-1, coke$meanGrowth, coke$meanPayoutROE*scaleROEMin*simEquity$equity[years,i], years)
pv2 = as.vector(pv2)

# Histogram of Present Value / Equity.
#emf("Coca-Cola PV-Book Histogram (DJVC Compounded).emf")
hist(pv2[pv2<50], nclass=100, probability=TRUE, xlab="Present Value", main="Coca-Cola PV/Book (DJVC Compounded)")
abline(v=pbook, lty=2, lw=2)
fit = fitdistr(pv2, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# CDF for Present Value / Equity.
#emf("Coca-Cola PV-Book CDF (DJVC Compounded).emf")
plot(ecdf(pv2), xlim=range(0,50), verticals=TRUE, do.points=FALSE, panel.first=grid(), xlab="Present Value / Equity", ylab="F(x)", main="Coca-Cola PV/Equity (DJVC Compounded)")
abline(v=pbook, lty=2, lw=2)
#dev.off()

##############
# (Coke) Present value when discount rate is
# annualized rate of return on DJVC index.

# Discount rate is the annualized rate of return on DJVC index,
# which is calculated from the compounded return at the last year.
d3 = d2[years,]^(1/years)

# Present value using DJVC annualized return as discount rate (no risk premium).
pv3 = foreach(i=1:sims, .combine='rbind') %do% sum(simEquity$payout[,i]/(d3[i]^(1:years))) + terminalValueGrowth(d3[i]-1, coke$meanGrowth, coke$meanPayoutROE*scaleROEMin*simEquity$equity[years,i], years)
pv3 = as.vector(pv3)

# Histogram of Present Value / Equity.
#emf("Coca-Cola PV-Book Histogram (DJVC Annualized).emf")
hist(pv3[pv3<50], nclass=100, probability=TRUE, xlab="Present Value", main="Coca-Cola PV/Book (DJVC Annualized)")
abline(v=pbook, lty=2, lw=2)
fit = fitdistr(pv3, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# CDF for Present Value / Equity.
#emf("Coca-Cola PV-Book CDF (DJVC Annualized).emf")
plot(ecdf(pv3), xlim=range(0,25), verticals=TRUE, do.points=FALSE, panel.first=grid(), xlab="Present Value / Equity", ylab="F(x)", main="Coca-Cola PV/Equity (DJVC Annualized)")
abline(v=pbook, lty=2, lw=2)
#dev.off()

# QQ-plot of present values when discount rate is compounded and annualized rates of return.
#emf("Coca-Cola PV QQ-Plot (DJVC Compounded vs Annualized).emf")
qqplot(pv2, pv3, xlab="Compounded", ylab="Annualized", main="Coca-Cola PV (DJVC Compounded vs. Annualized)")
#dev.off()

# Plot example of compounded vs annualized growth.
#emf("Compounded vs Annualized Growth (DJVC).emf")
plot(d2[,2], type="l", log="y", xlab="Year", ylab="Index", main="Compounded vs. Annualized Growth (DJVC)")
g = d2[years,2]^(1/years)
lines(g^(1:years))
#dev.off()

################################################
# (Coke) Present value and Jensen's inequality.

# Discount rate is mean S&P 500 value yield.
dmean = mean(d)
sd(d)

# Discount rate is mean DJVC annualized return.
d2annualized = d2[years,]^(1/years)-1
d2mean = mean(d2annualized)
sd(d2annualized)

# Present value using mean S&P 500 value yield plus risk premium as discount rate.
pvm = foreach(i=1:sims, .combine='rbind') %do% presentValue(dmean, simEquity$payout[,i]) + terminalValueGrowth(dmean, coke$meanGrowth*scaleTotal, coke$meanPayoutROE*scaleROEMin*simEquity$equity[years,i], years)
pvm = as.vector(pvm)

# Present value using mean DJVC annualized return as discount rate (no risk premium).
pv2m = foreach(i=1:sims, .combine='rbind') %do% presentValue(d2mean, simEquity$payout[,i]) + terminalValueGrowth(d2mean, coke$meanGrowth, coke$meanPayoutROE*scaleROEMin*simEquity$equity[years,i], years)
pv2m = as.vector(pv2m)

# Because of Jensen's inequality mean(pv)>=mean(pvm)
mean(pv)
mean(pvm)

# Because of Jensen's inequality mean(pv2)>=mean(pv2m)
mean(pv2)
mean(pv2m)

# Plot histogram of present value difference.
#emf("Histogram Coca-Cola PV Difference (S&P 500).emf")
hist(pv-pvm, nclass=100, probability=TRUE, xlab="Present Value Difference", main="Coca-Cola Present Value Difference (S&P 500)")
#dev.off()

# Plot histogram of present value difference.
#emf("Histogram Coca-Cola PV Difference (DJVC).emf")
dif = pv2-pv2m
hist(dif[dif<50], nclass=100, probability=TRUE, xlab="Present Value Difference", main="Coca-Cola Present Value Difference (DJVC)")
#dev.off()

##############
# Comparison of compounded returns for DJVC and S&P 500.

# Comparison of minimum compounded returns for DJVC and S&P 500.
#emf("Minimum Returns (DJVC vs S&P 500).emf")
plot(d2[,which(pv2==max(pv2))], type="l", log="y", xlab="Year", ylab="Compounded Return", main="Minimum Compounded Returns (DJVC vs. S&P 500)")
lines((1+min(d))^(1:years), lw=2)
#dev.off()

# Comparison of maximum compounded returns for DJVC and S&P 500.
#emf("Maximum Returns (DJVC vs S&P 500).emf")
plot(d2[,which(pv2==min(pv2))], type="l", log="y", xlab="Year", ylab="Compounded Return", main="Maximum Compounded Returns (DJVC vs. S&P 500)")
lines((1+max(d))^(1:years), lw=2)
#dev.off()

################################################
# (Coke) Probability of value yield greater than S&P 500.
# Using difference of Monte Carlo simulated value yields
# to calculate the probability. This method would also
# work if Coke and S&P 500 were modelled with dependencies,
# in which case the dependent value yields should be used.

# Number of years in each Monte Carlo simulation for S&P 500.
sp500years = requiredYears(sp500$retainOverEarnings, sp500$ROE, 0.01)

# Perform Monte Carlo simulations of S&P 500 equity, earnings, payout.
sp500simEquity = sp500$simulateEquity(sims, sp500years)

# Find value yields.
#sp500vys = valueYieldConst(sp500pbook, sp500simEquity$payout, sp500simEquity$equity, sp500$meanROE, sims, sp500years)
sp500vys = valueYieldGrowth(sp500pbook, sp500simEquity$payout, sp500simEquity$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, sp500years)

# Remove outliers as they are likely caused by optimization errors.
sp500vys = valueYieldRemoveOutliers(sp500vys)

# Check that value yields are found, that is,
# optimization errors should approach zero.
summary(sp500vys$errors)

# Print statistics.
summary(sp500vys$yields)
sd(sp500vys$yields)

# Probability of Coke's value yield greater than S&P 500.
riskPremium = 0.05
length(which(vys$yields-sp500vys$yields-riskPremium>0))/sims

# Plot histogram of value yield difference.
#emf(paste("Histogram Coca-Cola VY (PBook=", pbook, ") Minus S&P 500 VY (PBook=", sp500pbook, ").emf", sep=""))
idx = intersect(sp500vys$idx, vys$idx)
dif = vys$yieldsAll[idx]-sp500vys$yieldsAll[idx]
mean(dif)
sd(dif)
hist(dif, nclass=100, probability=TRUE, xlab="Coca-Cola VY - S&P 500 VY", main=paste("Coca-Cola P/Book=", pbook, ", S&P 500 P/Book=", sp500pbook, sep=""))
curve(dnorm(x, mean=mean(dif), sd=sd(dif)), add=T)
#dev.off()

# Histogram with more samples.
hist(sample(vys$yields,1e6,replace=T)-sample(sp500vys$yields,1e6,replace=T)-riskPremium, nclass=100, probability=TRUE, xlab="Value Yield Difference")
curve(dnorm(x, mean=mean(dif)-riskPremium, sd=sd(dif)), add=T)

# Plot probability for varying risk premiums.
#emf(paste("Probability Coca-Cola VY (PBook=", pbook, ") vs S&P 500 VY (PBook=", sp500pbook, ").emf", sep=""))
#riskPremiums = seq(0,0.2,0.005)
riskPremiums = seq(-0.05,0.15,0.005)
numSamples = sims*10
probs = foreach (riskPremium=riskPremiums, .combine='rbind') %do% length(which(sample(vys$yields, sims*10, replace=T)-sample(sp500vys$yields, numSamples, replace=T)-riskPremium>0))/numSamples
plot(riskPremiums, probs, panel.first=grid(), type="l", xlab="Risk Premium", ylab="Probability", main=paste("Coca-Cola P/Book=", pbook, ", S&P 500 P/Book=", sp500pbook, sep=""))
#dev.off()

################################################
# (Coke) Probability of value yield greater than S&P 500.
# Using ECDF to calculate probability.
# This is more complicated than the above method and
# requires for the value yields to be independent, if
# they are dependent then this is even more complicated.

# ECDF for S&P 500 value yields. This is used for
# calculating Pr[Value Yield of Coke < VY of S&P 500]
sp500ecdf = ecdf(sp500vys$yields)

# Probability of Coke's value yield greater than S&P 500.
riskPremium = 0.05
sum(sp500ecdf(vys$yields-riskPremium))/sims

# Plot probability for varying risk premiums.
riskPremiums = seq(-0.05,0.15,0.005)
probs = foreach (riskPremium=riskPremiums, .combine='rbind') %do% sum(sp500ecdf(vys$yields-riskPremium))/sims
plot(riskPremiums, probs, panel.first=grid(), type="l", xlab="Risk Premium", ylab="Probability", main=paste("Coca-Cola P/Book=", pbook, ", S&P 500 P/Book=", sp500pbook, sep=""))

################################################
# (Coke) Value with Share Buyback.
# Discount rate is S&P 500 value yield.
# Used in the paper 'The Value of Share Buybacks'.

# Start equity, on March 29, 2013 it was USD 32.5b
startEquity = 32.5

# Market-cap, in early July 2013 it was USD 180b
marketcap = 180

# Amount used for share buyback, e.g. USD 3b
buyback = 3

# Value to eternal shareholders without share buyback.
# Use pv, pv2 or pv3 calculated above.
v = pv * startEquity

# Value with share buyback.
w = (v-buyback) / (1-buyback/marketcap)

# Relative value of share buyback.
wv = (1-buyback/v) / (1-buyback/marketcap)

# Standard deviation.
sd(v)

# Mean equilibrium.
mean(v)

# Relative equilibrium.
harmean(v)

# Minimum value.
min(v)

# Probability of marketcap being less than value without share buyback.
# Pr[MarketCap<V]
ecdf(v)(marketcap)

# Histogram of value without share buyback.
#emf(paste("Coca-Cola Histogram V (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
hist(v, nclass=100, probability=TRUE, xlab="Value without Share Buyback (USD billion)", main=paste("Coca-Cola V (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=marketcap, lty=2, lw=2)
fit = fitdistr(v, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# CDF of value without share buyback.
#emf(paste("Coca-Cola CDF V (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
plot(ecdf(v), panel.first=grid(), verticals=TRUE, do.points=FALSE, xlab="Value without Share Buyback (USD billion)", ylab="F(v)", main=paste("Coca-Cola V (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=marketcap, lty=2, lw=2)
#dev.off()

# Histogram of relative value of share buyback.
#emf(paste("Coca-Cola Histogram WV (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
hist(wv, nclass=100, probability=TRUE, xlab="Relative Value of Share Buyback", main=paste("Coca-Cola W/V (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=1, lty=2, lw=2)
#dev.off()

# CDF of relative value of share buyback.
#emf(paste("Coca-Cola CDF WV (S&P 500 PBook=", sp500pbook, ", Risk Premium=", riskPremium, ").emf", sep=""))
plot(ecdf(wv), panel.first=grid(), verticals=TRUE, do.points=FALSE, xlab="Relative Value of Share Buyback", ylab="F(w/v)", main=paste("Coca-Cola W/V (S&P 500 P/Book=", sp500pbook, ", Risk Premium=", riskPremium*100, "%)", sep=""))
abline(v=1, lty=2, lw=2)
#dev.off()

################################################
# (Coke) Value with Share Buyback.
# Discount rate is DJVC compounded returns.
# Used in the paper 'The Value of Share Buybacks'.

# Value to eternal shareholders without share buyback.
# Use pv, pv2 or pv3 calculated above.
v2 = pv2 * startEquity

# Value with share buyback.
w2 = (v2-buyback) / (1-buyback/marketcap)

# Relative value of share buyback.
wv2 = (1-buyback/v2) / (1-buyback/marketcap)

# Standard deviation.
sd(v2)

# Weak equilibrium.
mean(v2)

# Relative equilibrium.
harmean(v2)

# Strong equilibrium.
min(v2)

# Probability of marketcap being less than value without share buyback.
# Pr[MarketCap<V]
ecdf(v2)(marketcap)

# Histogram of value without share buyback.
#emf("Coca-Cola Histogram V (DJVC Compounded).emf")
hist(v2[v2<1000], nclass=100, probability=TRUE, xlab="Value without Share Buyback (USD billion)", main="Coca-Cola V (DJVC Compounded)")
abline(v=marketcap, lty=2, lw=2)
fit = fitdistr(v2, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# CDF of value without share buyback.
#emf("Coca-Cola CDF V (DJVC Compounded).emf")
plot(ecdf(v2), xlim=range(0,1000), panel.first=grid(), verticals=TRUE, do.points=FALSE, xlab="Value without Share Buyback (USD billion)", ylab="F(v)", main="Coca-Cola V (DJVC Compounded)")
abline(v=marketcap, lty=2, lw=2)
#dev.off()

# Histogram of relative value of share buyback.
#emf("Coca-Cola Histogram WV (DJVC Compounded).emf")
hist(wv2, nclass=100, probability=TRUE, xlab="Relative Value of Share Buyback", main="Coca-Cola W/V (DJVC Compounded)")
abline(v=1, lty=2, lw=2)
#dev.off()

# CDF of relative value of share buyback.
#emf("Coca-Cola CDF WV (DJVC Compounded).emf")
plot(ecdf(wv2), panel.first=grid(), verticals=TRUE, do.points=FALSE, xlab="Relative Value of Share Buyback", ylab="F(w/v)", main="Coca-Cola W/V (DJVC Compounded)")
abline(v=1, lty=2, lw=2)
#dev.off()

################################################
################################################
# (DJVC) Various data plots.

# Plot prices.
#emf("DJVC Price (1991-2010).emf")
plot(djvc$dates, djvc$prices, type="l", xlab="Date", ylab="Index Level", main="Dow Jones Venture Capital Index (DJVC)")
#dev.off()

# Plot price-changes on a timeline.
#emf("DJVC Returns (1991-2010).emf")
plot(djvc$datesMonthly, djvc$priceChangesMonthly, type="p", pch=4, xlab="Date", ylab="Monthly Return", main="Dow Jones Venture Capital Index (DJVC)")
#dev.off()

# Histogram of price-changes.
#emf("DJVC Returns Histogram (1991-2010).emf")
hist(djvc$priceChangesMonthly, xlab="Monthly Return", main="Dow Jones Venture Capital Index (DJVC)", nclass=30)
#dev.off()

# Autocorrelation of price-changes.
#emf("DJVC Returns ACF (1991-2010).emf")
acf(djvc$priceChangesMonthly, lag.max=length(djvc$priceChangesMonthly), xlab="Lag/Months", ylab="Autocorrelation", main="Dow Jones Venture Capital Index (DJVC)")
#dev.off()

################################################
# (DJVC) Difference between DJVC and USA Gov. Bonds, monthly.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=100*usaBonds$yieldsMonthlized)
df2 = data.frame(date=djvc$datesMonthly, change=100*djvc$priceChangesMonthly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
idx = !is.na(m$change.x) & !is.na(m$change.y)
x = m$change.x[idx]
y = m$change.y[idx]

# Plot difference.
#emf("Return Difference (DJVC - USA Gov Bond, Monthly).emf")
plot(m$date[idx], y-x, type="p", pch=4, xlab="Date", ylab="Risk Premium (Monthly) / %", main="Risk Premium (Monthly) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (DJVC Return - USA Gov Bond Yield, Monthly).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield (Monthly) / %", ylab="DJVC Total Return (Monthly) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

# Cross-correlation.
#emf("Cross-correlation (DJVC Return - USA Gov Bond Yield, Monthly).emf")
ccf(x, y, lag.max=length(x), xlab="Lag/Months", ylab="Cross-correlation", main="DJVC Return vs. USA Gov. Bond Yield (Monthly)")
#dev.off()

################################################
# (DJVC) Difference between DJVC and USA Gov. Bonds, Yearly.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=usaBonds$yieldsMonthly)
df2 = data.frame(date=djvc$datesYearly, change=100*djvc$priceChangesYearly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
idx = !is.na(m$change.x) & !is.na(m$change.y)
x = m$change.x[idx]
y = m$change.y[idx]

# Plot difference.
#emf("Return Difference (DJVC - USA Gov Bond, Yearly).emf")
plot(m$date[idx], y-x, type="p", pch=4, xlab="Date", ylab="Risk Premium (Yearly) / %", main="Risk Premium (Yearly) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (DJVC Return - USA Gov Bond Yield, Yearly).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab="DJVC Total Return (Yearly) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

################################################
# (DJVC) Difference between DJVC and USA Gov. Bonds, Decade.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=usaBonds$yieldsMonthly)
df2 = data.frame(date=djvc$datesDecade, change=100*djvc$priceChangesDecadeAnnualized)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
idx = !is.na(m$change.x) & !is.na(m$change.y)
x = m$change.x[idx]
y = m$change.y[idx]

# Plot difference.
#emf("Return Difference (DJVC - USA Gov Bond, Decade).emf")
plot(m$date[idx], y-x, type="p", pch=4, xlab="Date", ylab="Risk Premium Annualized (Decade) / %", main="Risk Premium Annualized (Decade) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (DJVC Return - USA Gov Bond Yield, Decade).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab="DJVC Total Return Annualized (Decade) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

################################################
# (DJVC) Difference between DJVC and S&P 500

# Merge time series.
df1 = data.frame(date=djvc$datesMonthly, change=djvc$priceChangesMonthly)
df2 = data.frame(date=sp500$datesMonthly[1:(length(sp500$datesMonthly)-1)], change=sp500$priceChangesMonthly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
x = m$change.x[!is.na(m$change.x) & !is.na(m$change.y)]
y = m$change.y[!is.na(m$change.x) & !is.na(m$change.y)]

# Plot difference.
#emf("Return Difference (DJVC - S&P 500).emf")
plot(m$date, x-y, type="p", pch=4, xlab="Date", ylab="Return Difference", main="Monthly Return Difference, DJVC - S&P 500")
#dev.off()

# Plot histogram of differences.
#emf("Return Difference Histogram (DJVC - S&P 500).emf")
hist(x-y, nclass=30, xlab="Return Difference", main="Monthly Return Difference, DJVC - S&P 500")
#dev.off()

# Scatter-plot. Note that x and y is interchanged.
#emf("Scatter (DJVC vs S&P 500 Monthly Returns).emf")
plot(y, x, type="p", pch=4, xlab="S&P 500 Monthly Return / %", ylab="DJVC Monthly Total Return / %")
fit = lm(x~y)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared
summary(fit)

# QQ-plot residuals of linear fit.
#emf("QQ-Plot Linear Fit Residuals (DJVC vs S&P 500 Monthly Returns).emf")
qqnorm(scale(fit$residuals), main="Residuals of Linear Fit (DJVC vs. S&P 500 Monthly Returns)")
qqline(scale(fit$residuals), col=2, lwd=2, lty=2)
#dev.off()

# Cross-correlation.
#emf("Cross-correlation (DJVC Monthly Return - S&P 500 Monthly Return).emf")
ccf(x, y, lag.max=length(x), xlab="Lag/Months", ylab="Cross-correlation", main="DJVC vs. S&P 500 Monthly Returns (1991-2010)")
#dev.off()

# QQ-plot of DJVC vs. S&P 500 monthly returns.
#emf("QQ-Plot (DJVC vs S&P 500 Monthly Returns).emf")
qqplot(y, x, main="DJVC vs. S&P 500 Monthly Returns (1991-2010)", xlab="S&P 500 Monthly Return / %", ylab="DJVC Monthly Total Return / %")
#dev.off()

# Find starting price for DJVC for this period.
idx = which(djvc$dates == m$date[1], arr.ind=T)
startPriceDJVC = djvc$prices[idx]

# Simulate DJVC from historical monthly returns of S&P 500.
for (i in 1:9)
{
	# Model DJVC monthly returns from S&P 500 monthly returns.
	simPrice = djvc$sp500LinearModel(m$change.y)

	#emf(paste("Linear Model", i, "(DJVC from S&P 500, Monthly Returns).emf"))
	plot(m$date, startPriceDJVC * simPrice$djvcCompounded, main="DJVC Simulated from Monthly Returns of S&P 500", xlab="Year", ylab="Simulated DJVC Index", type="l")
	#dev.off()
}

################################################
# (DJVC) Simulate compounded returns.

# Settings.
sims = 1e3
years = 100
months = years*12

# Start P/Book for S&P 500
sp500startPBook = 2.3

# Simulate compounded returns.
simReturns = djvc$simulateCompoundedReturnsMonthly(sp500startPBook, sims, years)
sampledReturns = djvc$sampleCompoundedReturnsMonthly(sims, months)

# Plot compounded returns.
for (i in 1:9)
{
	#emf(paste("Simulated Compounded Returns", i, "(DJVC).emf"))
	plot(1:months/12, simReturns$djvcCompounded[,i], type="l", xlab="Year", ylab="", main="Simulated Compounded Return (DJVC)", log="y")
	#dev.off()

	#emf(paste("Sampled Compounded Returns", i, "(DJVC).emf"))
	plot(1:months/12, sampledReturns[,i], type="l", xlab="Year", ylab="", main="Sampled Compounded Return (DJVC)", log="y")
	#dev.off()
}

# QQ log-normal plots.
someYears = c(1, 5, 10, 15, 20, 30, 50, 75, 100)
for (year in someYears)
{
	month = year*12

	#emf(paste("QQ-Plot Compounded Return Year", year, "(DJVC).emf"))
	qqnorm(log(sampledReturns[month,]), main=paste("Year", year))
	qqline(log(sampledReturns[month,]), col = 2, lwd=2, lty=2)
	#dev.off()
}

################################################
# (DJVC) Curve-fit meanlogs and sdlogs.

fits = apply(sampledReturns, 1, function(x) fitdistr(x,"lognormal"))
meanlogs = as.numeric(lapply(fits, function(x) (x$estimate["meanlog"])))
sdlogs = as.numeric(lapply(fits, function(x) (x$estimate["sdlog"])))

# Curve fit meanlogs.
dat = data.frame(x=1:months, y=meanlogs)
fit = lm(y~x, data=dat)
someYears = floor(seq(1, years, length.out=50))	# Plot for these years
#emf("Compounded Return Mu (DJVC).emf")
plot(someYears, meanlogs[someYears*12], xlab="Year", ylab=expression(paste("Compounded Return  ", plain(mu))), main=expression(paste("Compounded Return ", plain(mu), " (DJVC)")))
lines(someYears, predict(fit)[someYears*12])
#dev.off()

# Curve fit sdlogs.
dat = data.frame(x=1:months, y=sdlogs)
fit = lm(y~sqrt(x), data=dat)
someYears = floor(seq(1, years, length.out=50))	# Plot for these years
#emf("Compounded Return Sigma (DJVC).emf")
plot(someYears, sdlogs[someYears*12], xlab="Year", ylab=expression(paste("PayoutSum  ", plain(sigma))), main=expression(paste("Compounded Return ", plain(sigma), " (DJVC)")))
lines(someYears, predict(fit)[someYears*12])
#dev.off()

################################################
################################################
# (S&P 500) Various data plots.

# Scatter-plot of Retain/Earnings vs. ROE
#emf("Scatter ROE_t, RetainOverEarnings_t (S&P 500).emf")
plot(sp500$retainOverEarnings, sp500$ROE, pch=4, cex=2, xlab=bquote((Retain/Earnings)[t]), ylab=bquote(ROE[t]), main="Retain/Earnings vs. ROE (S&P 500, 1984-2011)")
#dev.off()

# Scatter-plot of Retain/Earnings vs. ROE
#emf("Scatter ROE_t, RetainOverEarnings_(t-1) (S&P 500).emf")
plot(sp500$retainOverEarnings[1:(length(sp500$retainOverEarnings)-1)], sp500$ROE[2:(length(sp500$ROE))], pch=4, cex=2, xlab=bquote((Retain/Earnings)[~t-1]), ylab=bquote(ROE[t]), main="Retain/Earnings vs. ROE (S&P 500, 1984-2011)")
#dev.off()

# Scatter-plot of Retain/Earnings vs. ROE
#emf("Scatter ROE_t, RetainOverEarnings_(t+1) (S&P 500).emf")
plot(sp500$retainOverEarnings[2:length(sp500$retainOverEarnings)], sp500$ROE[1:(length(sp500$ROE)-1)], pch=4, cex=2, xlab=bquote((Retain/Earnings)[~t+1]), ylab=bquote(ROE[t]), main="Retain/Earnings vs. ROE (S&P 500, 1984-2011)")
#dev.off()

# S&P 500 equity/assets over time.
#emf("Equity-to-Assets (S&P 500).emf")
plot(sp500$years, sp500$equityOverAssets, type="l", xlab="Year", ylab="Equity/Assets", main="Equity/Assets (S&P 500)")
#dev.off()

# S&P 500 (Retain/Earnings)_t vs. (Retain/Earnings)_(t+1).
#emf("Scatter RetainOverEarnings_t, RetainOverEarnings_(t+1) (S&P 500).emf")
plot(sp500$retainOverEarnings[1:(length(sp500$retainOverEarnings)-1)], sp500$retainOverEarnings[2:(length(sp500$retainOverEarnings))], pch=4, cex=2, xlab=bquote((Retain/Earnings)[t]), ylab=bquote((Retain/Earnings)[~t+1]), main="Retain/Earnings (S&P 500)")
#dev.off()

# S&P 500 ROE_t vs. ROE_(t+1).
#emf("Scatter ROE_t, ROE_(t+1) (S&P 500).emf")
plot(sp500$ROE[1:(length(sp500$ROE)-1)], sp500$ROE[2:(length(sp500$ROE))], pch=4, cex=2, xlab=bquote(ROE[t]), ylab=bquote(ROE[~t+1]), main="ROE (S&P 500)")
fit=lm(sp500$ROE[2:(length(sp500$ROE))]~sp500$ROE[1:(length(sp500$ROE)-1)])
abline(fit)
summary(fit)$r.squared
#dev.off()

# S&P 500 price changes, histogram, daily.
#emf("Price Return Histogram (S&P 500, Daily, 1984-2011).emf")
hist(sp500$priceChangesDaily, probability=T, nclass=200, xlab="Daily Return", main="Daily Returns 1984-2011 (S&P 500)")
fit = fitdistr(sp500$priceChangesDaily, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# S&P 500 price changes, qq-plot, daily.
#emf("Price Return QQ-Plot (S&P 500, Daily, 1984-2011).emf")
qqnorm(log(sp500$priceChangesDaily), main="Daily Returns 1984-2011 (S&P 500)")
#dev.off()

# S&P 500 price changes, histogram, yearly.
#emf("Price Return Histogram (S&P 500, Yearly, 1984-2011).emf")
hist(sp500$priceChangesYearly2, probability=T, nclass=100, xlab="Yearly Return", main="Yearly Returns 1984-2011 (S&P 500)")
fit = fitdistr(sp500$priceChangesYearly2, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# S&P 500 price changes, qq-plot, yearly.
#emf("Price Return QQ-Plot (S&P 500, Yearly, 1984-2011).emf")
qqnorm(log(sp500$priceChangesYearly2), main="Yearly Returns 1984-2011 (S&P 500)")
#dev.off()

# S&P 500 ROE autocorrelation.
#emf("Autocorrelation ROE (S&P 500).emf")
acf(sp500$ROE, main="ROE (S&P 500)", ylab="Autocorrelation")
#dev.off()

# S&P 500 retain/earnings autocorrelation.
#emf("Autocorrelation RetainOverEarnings (S&P 500).emf")
acf(sp500$retainOverEarnings, main="Retain/Earnings (S&P 500)", ylab="Autocorrelation")
#dev.off()

# S&P 500 P/Book
#emf("PBook (S&P 500 Daily 1984-2011).emf")
plot(sp500$pbookdates, sp500$pbookdata[[5]], type="l", main="P/Book 1984-2011 (S&P 500)", xlab="Year", ylab="P/Book")
#dev.off()

# S&P 500 book-values
#emf("Book-Values (S&P 500 Daily 1984-2011).emf")
plot(sp500$pbookdates, sp500$bookvalues, type="l", main="Book-Value Per Share 1984-2011 (S&P 500)", xlab="Year", ylab="Book-Value Per Share")
points(sp500$pbookdates, sp500$pbookdata[[3]])
#dev.off()

# S&P 500 P/Book Histogram
#emf("Histogram PBook (S&P 500 Daily 1984-2011).emf")
fit = fitdistr(sp500$pbooks, "lognormal")
hist(sp500$pbooks, probability=T, nclass=100, xlab="P/Book", main="P/Book 1984-2011 (S&P 500)")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# S&P 500 P/Book CDF
#emf("CDF PBook (S&P 500 Daily 1984-2011).emf")
plot(ecdf(sp500$pbooks), verticals=TRUE, main="P/Book CDF 1984-2011 (S&P 500)", xlab="P/Book", ylab="F(x)", panel.first=grid())
#dev.off()

# S&P 500 P/Book QQ-plot
#emf("QQ-Plot PBook (S&P 500 Daily 1984-2011).emf")
qqnorm(log(sp500$pbooks), main="P/Book 1984-2011 (S&P 500)")
#dev.off()

# S&P 500 P/Book Autocorrelation
#emf("Autocorrelation PBook (S&P 500 Daily 1984-2011).emf")
l=acf(sp500$pbooks, lag.max=length(sp500$pbooks), plot=FALSE)
idx = floor(seq(1, length(l[[1]]), length.out=200))
plot(l[idx], xlab="Lag/Days", ylab="Autocorrelation", main="P/Book Autocorrelation 1984-2011 (S&P 500)")
#dev.off()

# S&P 500 P/Book changes histogram, daily.
#emf("Histogram PBook Change (S&P 500 Daily 1984-2011).emf")
hist(sp500$pbookChangesDaily, probability=TRUE, nclass=100, main="P/Book Daily Change 1984-2011 (S&P 500)", xlab="Change")
fit = fitdistr(sp500$pbookChangesDaily, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# S&P 500 P/Book changes histogram, yearly.
#emf("Histogram PBook Change (S&P 500 Yearly 1984-2011).emf")
hist(sp500$pbookChangesYearly, probability=TRUE, nclass=100, main="P/Book Yearly Change 1984-2011 (S&P 500)", xlab="Change")
fit = fitdistr(sp500$pbookChangesYearly, "lognormal")
curve(dlnorm(x, meanlog=fit$estimate["meanlog"], sdlog=fit$estimate["sdlog"]), add=TRUE)
#dev.off()

# Scatter-plot S&P 500 P/Book vs. P/Book change, daily.
#emf("Scatter PBook, PBook Change (S&P 500 Daily 1984-2011).emf")
plot(sp500$pbooks[1:(length(sp500$pbooks)-1)], sp500$pbookChangesDaily, main="P/Book vs. P/Book Daily Change 1984-2011 (S&P 500)", xlab="P/Book", ylab="P/Book Daily Change")
#dev.off()

# Scatter-plot S&P 500 P/Book vs. P/Book change, yearly.
#emf("Scatter PBook, PBook Change (S&P 500 Yearly 1984-2011).emf")
plot(sp500$pbooks[1:length(sp500$pbookChangesYearly)], sp500$pbookChangesYearly, main="P/Book vs. P/Book Yearly Change 1984-2011 (S&P 500)", xlab="P/Book", ylab="P/Book Yearly Change")
#dev.off()

# S&P 500 Value Yield Mean.
#emf("Value Yield Mean (S&P 500 Daily 1984-2011).emf")
plot(sp500$pbookdates, 9.1/sp500$pbooksAll+4.4, type="l", ylim=c(1,14), xlab="Date", ylab="Value Yield / %", main="S&P 500 Mean Value Yield / %")
#dev.off()

################################################
################################################
# (USA Gov. Bonds) Various data plots.

# USA Gov. Bond Yields, 1798-2012.
#emf("Government Bond Yields (USA 1798-2012).emf")
plot(usaBondsHistory$years, usaBondsHistory$yields, type="l", ylim=c(1,16), xlab="Year", ylab="Yield / %", main="USA Gov. Bond Yield Long Maturity / %")
#dev.off()

# Histogram of USA Gov. Bond Yields, 1798-2012.
#emf("Histogram (USA Gov Bond Yields 1798-2012).emf")
hist(usaBondsHistory$yields, nclass=100, xlab="Yield / %", main="USA Gov. Bond Yields (1798-2012)")
#dev.off()

# Autocorrelation of USA Gov. Bond yields, 1798-2012.
#emf("Autocorrelation (USA Gov Bond Yield 1798-2012).emf")
acf(usaBondsHistory$yields, lag.max=length(usaBondsHistory$yields), xlab="Lag/Years", ylab="Autocorrelation", main="USA Gov. Bond Yield (1798-2012)")
#dev.off()

# USA Gov. Bond Yields, 1962-2013.
#emf("Government Bond Yields (USA 1962-2013).emf")
plot(usaBonds$dates, usaBonds$yieldsAll, type="l", ylim=c(1,16), xlab="Date", ylab="Yield / %", main="USA Gov. Bond Yield 10-Year Maturity / %")
#dev.off()

# USA Gov. Bond Yields, 1983-2013.
#emf("Government Bond Yields (USA 1983-2013).emf")
plot(usaBonds$dates, usaBonds$yieldsAll, type="l", xlim=c(sp500$pbookdates[1], sp500$pbookdates[length(sp500$pbookdates)]), ylim=c(1,14), xlab="Date", ylab="Yield / %", main="USA Gov. Bond Yield 10-Year Maturity / %")
#dev.off()

# USA Gov. Bond Yields, 1962-2013.
#emf("Government Bond Yields (USA 1962-2013).emf")
plot(usaBonds$dates, usaBonds$yieldsAll, type="l", xlim=c(sp500$pbookdates[1], sp500$pbookdates[length(sp500$pbookdates)]), ylim=c(1,14), xlab="Date", ylab="Yield / %", main="USA Gov. Bond Yield 10-Year Maturity / %")
#dev.off()

# Histogram of USA Gov. Bond Yields, 1962-2013.
#emf("Histogram (USA Gov Bond Yields 1962-2013).emf")
hist(usaBonds$yields, nclass=100, xlab="Yield / %", main="USA Gov. Bond Yields (1962-2013)")
#dev.off()

# Autocorrelation of USA Gov. Bond yields, 1962-2013.
l=acf(usaBonds$yields, lag.max=length(usaBonds$yields), plot=FALSE)
idx = floor(seq(1, length(l[[1]]), length.out=200))
#emf("Autocorrelation (USA Gov Bond Yield 1962-2013).emf")
plot(l[idx], xlab="Lag/Days", ylab="Autocorrelation", main="USA Gov. Bond Yield (1962-2013)")
#dev.off()

################################################
################################################
# Equity Risk Premium
# S&P 500 Value Yield vs. USA Gov. Bond Yield

# S&P 500 Value Yield minus USA Gov. Bond Yields.
df1 = data.frame(date=usaBonds$dates, yield=usaBonds$yieldsAll)
df2 = data.frame(date=sp500$pbookdates, yield=9.1/sp500$pbooksAll+4.4)
m = merge(x=df1, y=df2, by="date")

#emf("Equity Risk Premium (S&P 500 Value Yield - USA Gov Bond Yield).emf")
plot(m$date, m$yield.y-m$yield.x, type="l", xlab="Date", ylab="Equity Risk Premium / %", main="Equity Risk Premium / %")
#dev.off()

# Yields that are not N/A.
x = m$yield.x[!is.na(m$yield.x) & !is.na(m$yield.y)]
y = m$yield.y[!is.na(m$yield.x) & !is.na(m$yield.y)]

# Equity Risk Premium, not containing N/A.
ERP = y-x

# Means.
mean(ERP)
geomean(ERP+100)-100
harmean(ERP)

# Histogram for Equity Risk Premium, S&P 500 Value Yield minus USA Gov. Bond Yields.
#emf("Equity Risk Premium Histogram (S&P 500 Value Yield - USA Gov Bond Yield 1984-2011).emf")
hist(ERP, nclass=100, xlab="Equity Risk Premium / %", main="Equity Risk Premium (1984-2011)")
#dev.off()

# Scatter-plot S&P 500 Mean Value Yield vs. USA Gov. Bond Yield.
#emf("Scatter (S&P 500 Value Yield - USA Gov Bond Yield).emf")
plot(x, y, type="p", pch=4, cex=0.5, xlab="USA Gov. Bond Yields / %", ylab="S&P 500 Mean Value Yield / %")
#dev.off()

# Cross-correlation of S&P 500 Mean Value Yield vs. USA Gov. Bond Yield.
#emf("Cross-correlation (S&P 500 Value Yield - USA Gov Bond Yield).emf")
l=ccf(x, y, lag.max=length(x), plot=FALSE)
idx = floor(seq(-length(l[[1]]), length(l[[1]]), length.out=200))
plot(l[idx], xlab="Lag/Days", ylab="Cross-correlation", main="")
#dev.off()

################################################
# Equity Risk Premium.
# S&P 500 Return vs. USA Gov. Bond Yield, monthly.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=100*usaBonds$yieldsMonthlized)
df2 = data.frame(date=sp500$datesMonthly[1:(length(sp500$datesMonthly)-1)], change=100*sp500$priceChangesMonthly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
x = m$change.x[!is.na(m$change.x) & !is.na(m$change.y)]
y = m$change.y[!is.na(m$change.x) & !is.na(m$change.y)]

# Plot difference.
#emf("Equity Risk Premium (S&P 500 Return - USA Gov Bond Yield, Monthly).emf")
plot(m$date, y-x, type="p", pch=4, xlab="Date", ylab="Equity Risk Premium (Monthly) / %", main="Equity Risk Premium (Monthly) / %")
#dev.off()

# Plot histogram of differences.
#emf("Equity Risk Premium Histogram (S&P 500 Return - USA Gov Bond Yield, Monthly).emf")
hist(y-x, nclass=30, xlab="Equity Risk Premium (Monthly) / %", main="Equity Risk Premium (Monthly) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (S&P 500 Return - USA Gov Bond Yield, Monthly).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield (Monthly) / %", ylab="S&P 500 Return (Monthly) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

# Cross-correlation.
#emf("Cross-correlation (S&P 500 Return - USA Gov Bond Yield, Monthly).emf")
l=ccf(x, y, lag.max=length(x), plot=FALSE)
idx = floor(seq(-length(l[[1]]), length(l[[1]]), length.out=200))
plot(l[idx], xlab="Lag/Months", ylab="Cross-correlation", main="S&P 500 Return vs. USA Gov. Bond Yield (Monthly)")
#dev.off()

################################################
# Equity Risk Premium.
# S&P 500 Return vs. USA Gov. Bond Yield, Yearly.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=usaBonds$yieldsMonthly)
df2 = data.frame(date=sp500$datesYearly, change=100*sp500$priceChangesYearly)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
x = m$change.x[!is.na(m$change.x) & !is.na(m$change.y)]
y = m$change.y[!is.na(m$change.x) & !is.na(m$change.y)]

# Plot difference.
#emf("Equity Risk Premium (S&P 500 Return - USA Gov Bond Yield, Yearly).emf")
plot(m$date, y-x, type="p", pch=4, xlab="Date", ylab="Equity Risk Premium (Yearly) / %", main="Equity Risk Premium (Yearly) / %")
#dev.off()

# Plot histogram of differences.
#emf("Equity Risk Premium Histogram (S&P 500 Return - USA Gov Bond Yield, Yearly).emf")
hist(y-x, nclass=30, xlab="Equity Risk Premium (Yearly) / %", main="Equity Risk Premium (Yearly) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (S&P 500 Return - USA Gov Bond Yield, Yearly).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab="S&P 500 Return (Yearly) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

################################################
# Equity Risk Premium.
# S&P 500 Return vs. USA Gov. Bond Yield, decade.

# Merge time series.
df1 = data.frame(date=usaBonds$datesMonthly, change=usaBonds$yieldsMonthly)
df2 = data.frame(date=sp500$datesDecade, change=100*sp500$priceChangesDecadeAnnualized)
m = merge(x=df1, y=df2, by="date")

# Changes that are not N/A.
x = m$change.x[!is.na(m$change.x) & !is.na(m$change.y)]
y = m$change.y[!is.na(m$change.x) & !is.na(m$change.y)]

# Plot difference.
#emf("Equity Risk Premium (S&P 500 Return - USA Gov Bond Yield, Decade).emf")
plot(m$date, y-x, type="p", pch=4, xlab="Date", ylab="Equity Risk Premium (Decade) / %", main="Equity Risk Premium (Decade) / %")
#dev.off()

# Plot histogram of differences.
#emf("Equity Risk Premium Histogram (S&P 500 Return - USA Gov Bond Yield, Decade).emf")
hist(y-x, nclass=30, xlab="Equity Risk Premium (Decade) / %", main="Equity Risk Premium (Decade) / %")
#dev.off()

# Scatter-plot.
#emf("Scatter (S&P 500 Return - USA Gov Bond Yield, Decade).emf")
plot(x, y, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab="S&P 500 Annualized Return (Decade) / %")
fit = lm(y~x)
abline(fit)
#dev.off()

# Coefficient of determination R^2
summary(fit)$r.squared

################################################
################################################
# (Coke) Various data plots.

# Scatter-plot of Coca-Cola ROE vs. Retain/Earnings
#emf("Scatter (Coca-Cola ROE - RetainOverEarnings 1993-2012).emf")
plot(coke$ROE, coke$retainOverEarnings, type="p", pch=4, xlab="ROE", ylab="Retain/Earnings", main="ROE vs. Retain/Earnings 1993-2012 (Coca-Cola)")
#dev.off()

# Cross-correlation of Coca-Cola ROE vs. Retain/Earnings.
#emf("Cross-correlation (Coca-Cola ROE - RetainOverEarnings 1993-2012).emf")
ccf(coke$ROE, coke$retainOverEarnings, , xlab="Lag / Years", ylab="Cross-correlation", main="ROE vs. Retain/Earnings 1993-2012 (Coca-Cola)")
#dev.off()

################################################
################################################
