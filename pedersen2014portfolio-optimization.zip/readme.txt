Portfolio Optimization & Monte Carlo Simulation
Source-Code for R
Copyright (C) 2013-2014 Magnus Erik Hvass Pedersen
www.Hvass-Labs.org


Please ensure you have downloaded the latest version from:

www.hvass-labs.org/people/magnus/publications/pedersen2014portfolio-optimization.zip

This implements the Monte Carlo simulations described in
the paper of the same title and available for download:

www.hvass-labs.org/people/magnus/publications/pedersen2014portfolio-optimization.pdf


Installation:

1. Unpack the archive to a convenient location.
2. Edit the setwd command in the source-code
   to reflect the installation location.
3. Start the R console.
4. Copy and paste text from the source-code file
   to the R console to execute the source-code.


Requirements:

The source-code was developed in R version 2.15.2
i386 for MS Windows. The required packages are
listed at the top of the source-code file.


Data sources (detailed in the paper):
- S&P 500 ROA, ROE, Retain, Equity/Assets from Compustat:
  http://www.compustat.com/

- S&P 500 P/Book from Compustat and FRED:
  http://www.compustat.com/
  http://research.stlouisfed.org/fred2/series/SP500/

- Company share-price:
  http://www.google.com/finance

- Company financial data:
  Form 10-K filed with US SEC.
  http://www.sec.gov/edgar/searchedgar/companysearch.html

- USA Gov. Bond Yields from Federal Reserve:
  http://www.federalreserve.gov/releases/h15/data.htm

- USA Gov. Bond Yields from 1798:
  Homer & Sylla, A History of Interest Rates, 2005.
  Tables 38, 46, 48, 51, 87.
  2006-onwards data is from Federal Reserve (see above).


Update History:

Version 1.1 (2014, May 28):
- Added Kelly portfolio optimization.

Version 1.0 (2014, May 17):
- First release.
