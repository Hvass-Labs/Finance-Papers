################################################
################################################
# 
# Portfolio Optimization & Monte Carlo Simulation
# Source-code for R
# 
# Copyright (C) 2013-2014 Magnus Erik Hvass Pedersen
# www.hvass-labs.org
#
# See paper of same title for documentation.
# See license.txt for license details.
#
################################################
################################################
# Change this to your installation directory.
setwd("E:/Finance/Publications/Portfolio Optimization and Monte Carlo Simulation/Data and Source Code/")

# Break on warnings.
# options(warn=2)

# Required packages.

require(MASS)
require(lattice)
require(foreach)
require(spatial)
require(DEoptim)
require(devEMF)
require(ggplot2)
require(zoo)
require(combinat)
require(stringr)
require(fPortfolio)
require(scales)

#install.packages("foreach")
#install.packages("DEoptim")
# win.metafile() causes problems with MS Word's PDF export, and devEMF works.
#install.packages("devEMF")
#install.packages("combinat")
#install.packages("fPortfolio")

# Parallel execution of foreach loops doesn't seem to be faster.
#require(doParallel)
#registerDoParallel(cores=4)

################################################
# Geometric mean.
# Only for positive numbers.

geomean = function(x)
{
	# This overflows.
	# prod(x)^(1/length(x))

	exp(mean(log(x)))
}

################################################
# Harmonic mean.

harmean = function(x)
{
	1/mean(1/x)
}

################################################
# Interpolate input-data for known dates to all in-between dates.
#
# Parameters:
# dates		Array of known dates.
# input		Input-data for known dates.

interpolate = function(dates, input)
{
	# Number of input values.
	inputN = length(input)

	# Number of output values.
	outputN = as.numeric(dates[inputN]-dates[1])+1

	# Allocate output array.
	output = array(dim=outputN)

	# Initialie last element of output to equal last element of input.
	output[outputN] = input[inputN]

	j = 1
	for (i in 1:(inputN-1))
	{
		# Interpolate between these two dates where data is known.
		d1 = dates[i]
		d2 = dates[i+1]

		# Numeric difference between dates.
		f = as.numeric(d2-d1)

		# Data to interpolate.
		b1 = input[i]
		b2 = input[i+1]

		# For each day in the interval between the dates, do the following.
		for (d in d1:(d2-1))
		{
			# Numeric difference between current day d and start day.
			h = d-as.numeric(d1)

			# Interpolated data.
			output[j] = (b2-b1)*h/f + b1

			# Increment array-index.
			j=j+1
		}
	}

	output
}

################################################
# Merge and calculate Price/Value for two time series
# with price and value. Used to calculate P/Book and P/Earnings.

priceToValue = function(priceDates, price, valueDates, value)
{
	# Merge time series.
	df1 = data.frame(date=valueDates, value=value)
	df2 = data.frame(date=priceDates, price=price)
	m = merge(x=df1, y=df2, by="date")

	list(dates=m$date, pvalue=m$price/m$value)
}

################################################
# Calculate retain/earnings from dividend/earnings and netBuyback/earnings.
#
# Parameters:
# dividendOverEarnings		Historical dividend/earnings ratios.
# netBuybackOverEarnings	Historical netBuyback/earnings ratios.

retainOverEarnings = function(dividendOverEarnings, netBuybackOverEarnings)
{
	1 - dividendOverEarnings - netBuybackOverEarnings
}

################################################
# Mean growth rate and mean Payout*ROE.
#
# Parameters:
# ROE			Array of ROE.
# retainOverEarnings	Array of retain/earnings ratios.

# Mean growth rate.
meanGrowth = function(ROE, retainOverEarnings)
{
	mean(ROE*retainOverEarnings)
}

# Mean payout rate. Multiply this with equity to get mean payout.
meanPayoutROE = function(ROE, retainOverEarnings)
{
	mean(ROE*(1-retainOverEarnings))
}

################################################
# Load and prepare data.
#
# Parameters:
# filenameFinancial	Filename for financial data.
# filenameSimulation	Filename for simulation data.
# filenamePrices	Filename for share-prices.
#
# File format:
# DON'T USE COMMAS IN NUMBERS. E.g. use 715.23 instead of 715,23
# Date format is date-month-year, e.g. 31-12-2012 is December 31, year 2012.

loadData = function(filenameFinancial, filenameSimulation, filenamePrices)
{
	dat = list()

	# Load financial per-share data.
	temp = read.table(filenameFinancial, header=TRUE, sep="\t")
	dat$financialData = temp[complete.cases(temp),]
	dat$financialDates = as.Date(dat$financialData[[1]], "%d-%m-%Y")
	dat$netIncome = dat$financialData[[2]]	# Net income per share.
	dat$netIncomeN = length(dat$netIncome)
	dat$book = dat$financialData[[3]]	# Book-value or equity per share.
	dat$bookN = length(dat$book)

	# Load simulation data.
	temp = read.table(filenameSimulation, header=TRUE, sep="\t")
	dat$simYears = temp[[1]]
	dat$ROE = temp[[2]]
	dat$dividendOverEarnings = temp[[3]]
	dat$netBuybackOverEarnings = temp[[4]]

	# Calculations on simulation data.
	dat$retainOverEarnings = retainOverEarnings(dat$dividendOverEarnings, dat$netBuybackOverEarnings)
	dat$meanROE = mean(dat$ROE)
	dat$meanRetainOverEarnings = mean(dat$retainOverEarnings)
	dat$meanGrowth = meanGrowth(dat$ROE, dat$retainOverEarnings)
	dat$meanPayoutROE = meanPayoutROE(dat$ROE, dat$retainOverEarnings)

	# Load prices.
	temp = read.table(filenamePrices, header=TRUE, sep="\t")
	dat$priceData = temp[complete.cases(temp),]
	dat$priceDates = as.Date(dat$priceData[[1]], "%d-%m-%Y")
	dat$price = dat$priceData[[2]]
	dat$priceN = length(dat$price)

	# Interpolate book-values and netIncome for all in-between dates.
	dat$bookAll = interpolate(dat$financialDates, dat$book)
	dat$netIncomeAll = interpolate(dat$financialDates, dat$netIncome)

	# Set dates for all interpolated financial values.
	dateOrigin = "1970-01-01"
	dat$financialDatesAll = as.Date(dat$financialDates[1]:dat$financialDates[dat$bookN], origin=dateOrigin)

	# Calculate P/Book.
	foo = priceToValue(dat$priceDates, dat$price, dat$financialDatesAll, dat$bookAll)
	dat$pbookDates = foo$dates
	dat$pbook = foo$pvalue
	dat$pbookDF = data.frame(date=dat$pbookDates, pbook=dat$pbook)

	# Calculate P/Earnings.
	foo = priceToValue(dat$priceDates, dat$price, dat$financialDatesAll, dat$netIncomeAll)
	dat$peDates = foo$dates
	dat$pe = foo$pvalue

	# Calculate earnings-yield in percent.
	dat$earningsYield = 100/dat$pe

	dat
}

################################################
# Find the years that are in common for all companies.
# It is assumed that each array of years is consecutive
# without any years missing.
#
# Parameters:
# years		List of arrays of years.
#
# Example input:
# 1992 1993 1994 1995 1996
#      1993 1994 1995 1996 1997
#           1994 1995
# Common years for all 3 input arrays:
#           1994 1995

findCommonYears = function(years)
{
	# Ranges for years.
	ranges = sapply(years, range)

	# Minimum year that all arrays have in common.
	minCommonYear = max(ranges[1,])

	# Maximum year that all arrays have in common.
	maxCommonYear = min(ranges[2,])

	# The range that all arrays have in common.
	commonRange = c(minCommonYear, maxCommonYear)

	# Number of years all arrays have in common.
	# This is used as the maxIndex in sampleIndex().
	num = maxCommonYear-minCommonYear+1

	# Offset into arrays for minimum common year. Used in sampleFinancials().
	offset = sapply(years, function(x) which(x==minCommonYear)) - 1

	list(offset=offset, num=num,
		minCommonYear=minCommonYear, maxCommonYear=maxCommonYear,
		commonRange=commonRange)
}

################################################
# Create random index-values for use in sampling
# financial data in sampleFinancials().
# Using the same index for different companies
# takes statistical dependence into account.
#
# Parameters:
# sims		Number of simulations.
# years		Number of years.
# maxIndex	Samples will be between 1 and maxIndex.

sampleIndex = function(sims, years, maxIndex)
{
	sample(maxIndex, sims*years, replace=TRUE)
}

################################################
# Create random index-values for use in sampling
# date-synced P/Book ratios.
# Using the same index for different companies
# takes statistical dependence into account.
#
# Parameters:
# sims		Number of simulations.
# years		Number of years.

samplePBookIndex = function(sims, years=1)
{
	sampleIndex(sims, years, syncedPBookNum)
}

################################################
# Sample financial data from historical data
# and from the same year.
#
# Parameters:
# dat		Financial data returned from loadData().
# index		Index returned from sampleIndex().
# sims		Number of simulations.
# years		Number of years.

sampleFinancials = function(dat, index, sims, years)
{
	# Offset the index to account for different number of years
	# in the datasets for different companies.
	offsetIndex = index + dat$simYearsOffset

	# Sample ROE and retain according to index.
	sampledROE = dat$ROE[offsetIndex]
	sampledRetainOverEarnings = dat$retainOverEarnings[offsetIndex]
	sampledDividendOverEarnings = dat$dividendOverEarnings[offsetIndex]
	sampledNetBuybackOverEarnings = dat$netBuybackOverEarnings[offsetIndex]

	# Dimensionality of output matrices.
	dim = c(years, sims)

	# Turn sampled data into matrices.
	dim(sampledROE) = dim
	dim(sampledRetainOverEarnings) = dim
	dim(sampledDividendOverEarnings) = dim
	dim(sampledNetBuybackOverEarnings) = dim

	list(retainOverEarnings=sampledRetainOverEarnings, ROE=sampledROE,
             dividendOverEarnings=sampledDividendOverEarnings,
             netBuybackOverEarnings=sampledNetBuybackOverEarnings)
}

################################################
# Monte Carlo simulation of Equity Growth Model.
#
# Parameters:
# dat		Financial data returned from loadData().
# index		Index returned from sampleIndex().
# sims		Number of MC simulations to perform.
# years		Number of years for each MC simulation.
# scaleRetain	Scale applied to sampled Retain ratios.
# scaleROE	Scale applied to sampled ROE.

simulateEquity = function(dat, index, sims, years, scaleRetain=1, scaleROE=1)
{
	# Dimensionality of output arrays.
	dim = c(years, sims)
	dim1 = c(years+1, sims)

	# Allocate arrays.
	equity = array(dim=dim1)
	earnings = array(dim=dim)
	retain = array(dim=dim)
	payout = array(dim=dim)
	dividend = array(dim=dim)
	netBuyback = array(dim=dim)

	# Initialize first year's starting equity to one for all simulations.
	equity[1,] = 1

	# Sample financial data.
	s = sampleFinancials(dat, index, sims, years)

	# Calculate payout scale.
	# This must be calculated before s$retainOverEarnings is scaled.
	scalePayout = (1 - scaleRetain * s$retainOverEarnings) / (1 - s$retainOverEarnings)

	# Scale the sampled ROE and retain.
	s$ROE = s$ROE * scaleROE
	s$retainOverEarnings = s$retainOverEarnings * scaleRetain

	# Calculate earnings, payout and equity for each year.
	for (year in 1:years)
	{
		# Equity growth model.
		earnings[year,] = s$ROE[year,] * equity[year,]
		retain[year,] = earnings[year,] * s$retainOverEarnings[year,]
		payout[year,] = earnings[year,] * (1 - s$retainOverEarnings[year,]) # This is already scaled.
		dividend[year,] = earnings[year,] * s$dividendOverEarnings[year,] * scalePayout[year,]
		netBuyback[year,] = earnings[year,] * s$netBuybackOverEarnings[year,] * scalePayout[year,]
		equity[year+1,] = earnings[year,] * s$retainOverEarnings[year,] + equity[year,]
	}

	# Test ROE and retain scaling is correct.
	# Assert: earnings = retain + dividend + netBuyback
	# stopifnot(earnings-retain-dividend-netBuyback<1e-3)

	# Don't return the first year's equity which is normalized to 1.
	list(equity=equity[2:(years+1),], earnings=earnings, retain=retain,
             payout=payout, dividend=dividend, netBuyback=netBuyback)
}

################################################
# Discounted value.
#
# Parameters:
# d		Discount rate.
# value		Value to be discounted.
# years		Number of years from now.

discount = function(d, value, years)
{
	value/(1+d)^years
}

################################################
# Terminal value.
#
# Parameters:
# d		Discount rate.
# g		Growth rate.
# payout	Value to be discounted.
# years		Number of years from now.

# Payouts are assumed to be constant for eternity.
terminalValueConst = function(d, payout, years)
{
	discount(d, payout/d, years)
}

# Payouts are assumed to grow for eternity.
terminalValueGrowth = function(d, g, payout, years)
{
	discount(d, payout/(d-g), years)
}

################################################
# Present value of a series of payouts.
#
# Parameters:
# d		Discount rate.
# payout	Array of payouts to discount.
# n		Number of payouts to discount.

presentValue = function(d, payout, n=length(payout))
{
	sum((payout[1:n]) / ((1+d)^(1:n)))
}

################################################
# Simulate changes in number of shares from
# share buyback and issuance.
# Returns the normalized number of shares at the
# end of each simulation year.
# The starting number of shares is normalized to one
# but this is not included in the returned array.

# Parameters:
# equity		Simulated equity from simulateEquity()
# netBuyback		Simulated netBuyback from simulateEquity()
# pbooks		P/Book for future years.
# sims			Number of simulations.
# years			Number of years in each simulation.

simulateShareBuyback = function(equity, netBuyback, pbooks, sims, years)
{
	# Allocate array.
	shares = array(dim=c(years+1,sims))

	# Initialize first year's shares to one for all simulations.
	shares[1,] = 1

	# Calculate earnings, payout and equity for each year.
	for (year in 1:years)
	{
		shares[year+1,] = shares[year,] * (1 - netBuyback[year,]/(pbooks[year,] * equity[year,]))
	}

	# Don't return the first year's shares which are normalized to 1.
	shares[2:(years+1),]
}

################################################
# Find the value yield, that is, find the discount
# rate d which makes the present value equal to
# the P/Book ratio.
#
# Parameters:
# pbook		Current P/Book ratio.
# sims		Number of simulations.
# pv		Present value function.

# Find one value yield.
valueYieldOne = function(pbook, pv)
{
	# Finding the value yield is an optimization problem.
	# We are seeking the discount rate d which causes
	# the present value to equal the given P/Book ratio.
	# The difference between the present value and the
	# P/Book ratio is squared so as to create a continuous
	# function to optimize.

	# Max error.
	maxError = 1e-4

	# Try local optimization.
	res = optimize(function(d) abs(pbook-pv(d)), maximum=FALSE, lower=-0.5, upper=10, tol=1e-5)

	# If local optimization fails then try global optimization.
	# This is much slower and can be disabled by adding FALSE to
	# the if-condition.
	if (FALSE & res$objective>maxError)
	{
		# Use Differential Evolution (DE) as global optimizer.
		res2 = DEoptim(function(d) abs(pbook-pv(d)), lower=-0.5, upper=10, control=list(NP=15, CR=0.7, F=0.9, trace=F, itermax=3000, VTR=maxError))

		# If result of DE is better then use it.
		if (res$objective > res2$optim$bestval)
		{
			res = list(minimum = res2$optim$bestmem[[1]], objective=res2$optim$bestval)
		}
	}

	res
}

# Find multiple value yields.
valueYieldMany = function(pbook, sims, pv)
{
	vys = foreach(sim=1:sims) %do% valueYieldOne(pbook, function (d) pv(d,sim))

	list(yields = as.numeric(lapply(vys, function(x) (x$minimum))),
	errors = as.numeric(lapply(vys, function(x) (x$objective))))
}

# Find value yields when the terminal values are constant payouts for
# eternity, calculated as the mean ROE multiplied by the last equity.
valueYieldConst = function(pbook, payout, equity, meanROE, sims, years)
{
	valueYieldMany(pbook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ terminalValueConst(d, equity[years,sim]*meanROE, years)))
}

# Find value yields when the payouts grow for eternity.
valueYieldGrowth = function(pbook, payout, equity, meanPayoutROE, meanGrowth, sims, years)
{
	valueYieldMany(pbook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ terminalValueGrowth(d, meanGrowth, equity[years,sim]*meanPayoutROE, years)))
}

# Find value yields when the terminal value is the price, calculated
# as the final equity multiplied by a P/Book ratio at that time.
valueYieldPBook = function(startPBook, pbooks, payout, equity, sims, years)
{
	valueYieldMany(startPBook, sims,
		function(d,sim) (presentValue(d, payout[,sim], years)
		+ discount(d, pbooks[years,sim]*equity[years,sim], years)))
}

# Remove value yield outliers which are likely caused by optimization error.
valueYieldRemoveOutliers = function(vys, sdFactor=3)
{
	m = mean(vys$yields)
	s = sd(vys$yields)

	idx = which(abs(vys$yields-m)<sdFactor*s)

	list(yields=vys$yields[idx], yieldsAll=vys$yields,
	     errors=vys$errors[idx], errorsAll=vys$errors, idx=idx)
}

################################################
# Calculate per-share values for equity, earnings,
# dividend, and share-price.
#
# Parameters:
# dat		Financial data returned from loadData(), must also contain
#		dat$simEquity returned from simulateEquity(), and
#		dat$pbookSample which is date-synced P/Book sample.
# sims		Number of simulations.
# years		Number of years.

perShare = function(dat, sims, years)
{
	# Simulate share buyback
	shares = simulateShareBuyback(dat$simEquity$equity, dat$simEquity$netBuyback, dat$pbookSample, sims, years)

	# Calculate per-share numbers.
	equity = dat$simEquity$equity / shares
	earnings = dat$simEquity$earnings / shares
	dividend = dat$simEquity$dividend / shares
	price = equity * dat$pbookSample

	list(equity=equity, earnings=earnings, dividend=dividend, price=price)
}

################################################
# Plot with a grid when x-axis contains dates. The grid is
# incorrect when using the normal panel.first=grid() method.

# Helper-function to be called in panel.first
doPlotGrid = function(x, y, xlim, ylim)
{
	xRange = extendrange(if (is.null(xlim)) x else xlim)
	yRange = extendrange(if (is.null(ylim)) y else ylim)

	abline(v = pretty(xRange), 
	       h = pretty(yRange),
	       col = 'lightgrey', lty = "dotted")
}

# Use this function instead of plot when x-axis contains dates.
plotGrid = function(x, y, xlab, ylab, main, xlim=NULL, ylim=NULL)
{
	plot(x, y, type="l", xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, panel.first=doPlotGrid(x, y, xlim, ylim))
}

################################################
# Select a subset of dates within the given range.
#
# Parameters:
# dateRange	Output is limited between min and max of this range.
# dates		Dates to limit.
#
# Return value is index into the dates-array.

dateLimit = function(dateRange, dates)
{
	which(min(dateRange) < dates & dates < max(dateRange))
}

################################################
# Plots for a company's financial data.
#
# Parameters:
# dat		Financial data returned from loadData().

plotFinancials = function(dat)
{
	# Get string for min-max years from dates to use in plot-titles.
	yearStr = yearRange(dat$pbookDates)$strPar

	# Label strings.
	mainStr = paste(dat$name, yearStr)

	# Plot share price, limit dates to match P/Book plot.
	# (This could be done with xlim but with some differences in plot.)
	emf(paste(dat$name, "Share Price.emf"))
	idx = dateLimit(dat$pbookDates, dat$priceDates)
	plotGrid(dat$priceDates[idx], dat$price[idx], xlab="", ylab="Share Price / USD", main=dat$name)
	dev.off()

	# Plot historical P/Book.
	emf(paste(dat$name, "PBook.emf"))
	plotGrid(dat$pbookDates, dat$pbook, xlab="", ylab="P/Book", main=mainStr)
	dev.off()

	# Plot Histogram for P/Book.
	emf(paste(dat$name, "PBook Histogram.emf"))
	hist(dat$pbook, xlab="P/Book", main=mainStr, prob=T, nclass=50)
	dev.off()

	# Plot ECDF for P/Book.
	emf(paste(dat$name, "PBook ECDF.emf"))
	plot(ecdf(dat$pbook), verticals=TRUE, xlab="P/Book", ylab="F(x)", main=mainStr, panel.first=grid())
	dev.off()

	# Plot historical P/E.
	emf(paste(dat$name, "PE.emf"))
	plotGrid(dat$peDates, dat$pe, xlab="", ylab="P/E", main=mainStr)
	dev.off()

	# Plot Histogram for P/Earnings.
	emf(paste(dat$name, "PE Histogram.emf"))
	hist(dat$pe, xlab="P/E", main=mainStr, prob=T, nclass=50)
	dev.off()

	# Plot ECDF for P/Earnings.
	emf(paste(dat$name, "PE ECDF.emf"))
	plot(ecdf(dat$pe), verticals=TRUE, xlab="P/E", ylab="F(x)", main=mainStr, panel.first=grid())
	dev.off()

	# Scatter-plot of P/Book and P/E.
	emf(paste(dat$name, "PBook-PE Scatter-Plot.emf"))
	plot(dat$pbook, dat$pe, type="p", pch=4, xlab="P/Book", ylab="P/E", main=mainStr)
	dev.off()

	# QQ-plot of P/Book and P/E.
	#qqplot(dat$pbook, dat$pe, xlab="P/Book", ylab="P/E")

	# Print correlation of P/Book and P/E.
	print(paste(dat$name, "correlation of P/Book and P/E:", cor(dat$pbook, dat$pe)))

	# Plot historical Earnings Yield.
	emf(paste(dat$name, "Earnings Yield.emf"))
	plotGrid(dat$peDates, dat$earningsYield, xlab="", ylab="Earnings Yield / %", main=mainStr)
	dev.off()

	# Plot Histogram for Earnings Yield.
	emf(paste(dat$name, "Earnings Yield Histogram.emf"))
	hist(dat$earningsYield, xlab="Earnings Yield / %", main=mainStr, prob=T, nclass=50)
	dev.off()

	# Plot ECDF for Earnings Yield.
	emf(paste(dat$name, "Earnings Yield ECDF.emf"))
	plot(ecdf(dat$earningsYield), verticals=TRUE, xlab="Earnings Yield / %", ylab="F(x)", main=mainStr, panel.first=grid())
	dev.off()
}

################################################
# Get date-synced P/Book ratios for a company.
#
# Parameters:
# dat		Financial data returned from loadData().

syncedPBook = function(dat)
{
	# Merge with the synced dates to get the ones that are in common.
	m = merge(x=syncedPBookDatesDF, y=dat$pbookDF, by="date")

	m$pbook
}

################################################
# Sample historical P/Book.
#
# Parameters:
# dat		Financial data returned from loadData().
# sims		Number of simulations.
# years		Number of years for each simulation.

samplePBookHistorical = function(dat, sims, years)
{
	# Sample.
	s = sample(dat$pbook, sims*years, replace=T)

	# Change dimensions.
	dim(s) = c(years, sims)

	s
}

################################################
# Get date-synced P/Book ratios using an index.
#
# Parameters:
# dat		Financial data returned from loadData().
# index		Index from samplePBookIndex().
# sims		Number of simulations.
# years		Number of years per simulation.

# Get date-synced P/Book matrix.
getPBookSynced = function(dat, index, sims, years)
{
	# Lookup P/Book using the supplied index.
	pbook = dat$pbookSynced[index]

	# Change dimensions.
	dim(pbook) = c(years, sims)

	pbook
}

################################################
# Plot curves for value yield mean and sd.
# The terminal value is the price resulting
# from sampling historical P/Book distribution
# and Monte Carlo simulation of equity.

plotValueYieldCurves = function(dat, sims, years)
{
	# Holding periods in years.
	someYears = 1:30
	years = max(someYears)

	# Preallocate arrays.
	dim = length(years)
	vyPayoutMeans = array(dim=dim)
	vyPayoutSDs = array(dim=dim)
	vyDividendPerShareMeans = array(dim=dim)
	vyDividendPerShareSDs = array(dim=dim)
	vyDifMeans = array(dim=dim)
	vyDifSDs = array(dim=dim)

	# Index used in sampleFinancials(). Sampled from
	# data-years that all companies have in common.
	index = sampleIndex(sims, years, commonSimYears$num)

	# Monte Carlo simulations of equity, earnings, payout.
	dat$simEquity = simulateEquity(dat, index, sims, years)

	# Sample date-synced P/Book ratios.
	pbookIndex = samplePBookIndex(sims, years)

	# P/Book sample.
	dat$pbookSample = getPBookSynced(dat, pbookIndex, sims, years)

	# Per-share numbers.
	dat$perShare = perShare(dat, sims, years)

	# This may take 15 minutes to execute on a PC from 2011 using a single core.
	system.time(
	for (i in 1:length(someYears))
	{
		year = someYears[i]

		# Value yield, payout.
		vyPayout = valueYieldPBook(dat$startPBook, dat$pbookSample, dat$simEquity$payout, dat$simEquity$equity, sims, year)

		# Value yield, dividend per share.
		vyDividendPerShare = valueYieldPBook(dat$startPBook, dat$pbookSample, dat$perShare$dividend, dat$perShare$equity, sims, year)

		# Value Yield difference.
		vyDif = vyPayout$yields - vyDividendPerShare$yields

		# Value yield, mean and SD, payout.
		vyPayoutMeans[i] = mean(vyPayout$yields)
		vyPayoutSDs[i] = sd(vyPayout$yields)

		# Value yield, mean and SD, dividend per share.
		vyDividendPerShareMeans[i] = mean(vyDividendPerShare$yields)
		vyDividendPerShareSDs[i] = sd(vyDividendPerShare$yields)

		# Value yield difference, mean and SD.
		vyDifMeans[i] = mean(vyDif)
		vyDifSDs[i] = sd(vyDif)
	})

	emf(paste(dat$name, "Value Yield Curve (Without Share Buyback).emf"))
	matplot(someYears, cbind(vyPayoutMeans, vyPayoutMeans-vyPayoutSDs, vyPayoutMeans+vyPayoutSDs), type="l", lty=c(1,3,3), col="#000000", xlab="Holding Period / Years", ylab="Value Yield", main=paste(dat$name, "Value Yield (WITHOUT Share Buyback)"))
	dev.off()

	emf(paste(dat$name, "Value Yield Curve (With Share Buyback).emf"))
	matplot(someYears, cbind(vyDividendPerShareMeans, vyDividendPerShareMeans-vyDividendPerShareSDs, vyDividendPerShareMeans+vyDividendPerShareSDs), type="l", lty=c(1,3,3), col="#000000", xlab="Holding Period / Years", ylab="Value Yield", main=paste(dat$name, "Value Yield (WITH Share Buyback)"))
	dev.off()
}

################################################
# Show statistics for a company's financial data.
#
# Parameters:
# dat		Financial data returned from loadData().

# Helper function.
doStats = function(header, x)
{
	# Show statistics, P/Book
	print(header)
	print(summary(x))
	print(geomean(x))
	print(harmean(x))
	print(sd(x))
}

# Call this.
stats = function(dat)
{
	doStats("P/Book", dat$pbook)
	doStats("P/E", dat$pe)
	doStats("Earnings Yield", dat$earningsYield)
}

################################################
# Construct string with min and max years from date-array.
#
# Parameters:
# dates		Array of dates.

yearRange = function(dates)
{
	minYear = as.POSIXlt(min(dates))$year+1900
	maxYear = as.POSIXlt(max(dates))$year+1900
	str = paste(minYear, "-", maxYear, sep="")
	strPar = paste("(", str, ")", sep="")

	list(minYear=minYear, maxYear=maxYear, str=str, strPar=strPar)
}

################################################
# Plot comparisons of a company's financial data to USA gov. bonds.
#
# Parameters
# dat		Financial data returned from loadData().

compareToGovBonds = function(dat)
{
	# Merge time series.
	df1 = data.frame(date=usaBonds$dates, bondYield=usaBonds$yields)
	df2 = data.frame(date=dat$peDates, earningsYield=dat$earningsYield, pbook=dat$pbook)
	m = merge(x=df1, y=df2, by="date")

	# Get string for min-max years from dates to use in plot-titles.
	yearStr = yearRange(m$date)$strPar

	# String used in filenames.
	filenameStr = paste(dat$name, "vs USA Gov Bond", yearStr)

	# Label strings.
	labStr = paste(dat$name, "Earnings Yield - USA Gov. Bond Yield / %")
	mainStr = paste(dat$name, "vs. USA Gov. Bonds", yearStr)

	# Scatter-plot bond-yield vs. earnings-yield.
	emf(paste(filenameStr, "Scatter-Plot Earnings Yield.emf"))
	plot(m$bondYield, m$earningsYield, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab=paste(dat$name, "Earnings Yield / %"), main=mainStr)
	dev.off()

	# Scatter-plot bond-yield vs. P/Book.
	emf(paste(filenameStr, "Scatter-Plot PBook.emf"))
	plot(m$bondYield, m$pbook, type="p", pch=4, xlab="USA Gov. Bond Yield / %", ylab=paste(dat$name, "P/Book"), main=mainStr)
	dev.off()

	# Print correlations.
	print(paste(dat$name, "correlation of Earnings Yield and US Gov. Bond Yield:", cor(m$bondYield, m$earningsYield)))
	print(paste(dat$name, "correlation of P/Book and US Gov. Bond Yield:", cor(m$bondYield, m$pbook)))

	# Calculate difference between earnings yield and bond yield.
	dif = m$earningsYield-m$bondYield

	# Plot yield difference.
	emf(paste(filenameStr, "Difference.emf"))
	plotGrid(m$date, dif, xlab="", ylab=labStr, main=mainStr)
	dev.off()

	# Histogram yield difference.
	emf(paste(filenameStr, "Difference Histogram.emf"))
	hist(dif, prob=T, nclass=50, xlab=labStr, main=mainStr)
	dev.off()

	# Show statistics.
	print(summary(dif))
	print(sd(dif))
}

################################################
# Plot comparisons of a company's financial data to S&P 500
#
# Parameters:
# dat		Financial data returned from loadData().

compareToSP500 = function(dat)
{
	# Merge time series.
	df1 = data.frame(date=sp500$peDates, sp500earningsYield=sp500$earningsYield, sp500pbook=sp500$pbook, sp500pe=sp500$pe)
	df2 = data.frame(date=dat$peDates, earningsYield=dat$earningsYield, pbook=dat$pbook, pe=dat$pe)
	m = merge(x=df1, y=df2, by="date")

	# Get string for min-max years from dates to use in plot-titles.
	yearStr = yearRange(m$date)$strPar

	# String used in filenames.
	filenameStr = paste(dat$name, "vs S&P 500", yearStr)

	# Label strings.
	labStr = paste(dat$name, "- S&P 500 Earnings Yield / %")
	mainStr = paste(dat$name, "vs. S&P 500", yearStr)

	# Scatter-plot of Earnings Yield.
	emf(paste(filenameStr, "Scatter-Plot Earnings Yield.emf"))
	plot(m$sp500earningsYield, m$earningsYield, type="p", pch=4, xlab="S&P 500 Earnings Yield / %", ylab=paste(dat$name, "Earnings Yield / %"), main=mainStr)
	dev.off()

	# Scatter-Plot of P/Book.
	emf(paste(filenameStr, "Scatter-Plot PBook.emf"))
	plot(m$sp500pbook, m$pbook, type="p", pch=4, xlab="S&P 500 P/Book", ylab=paste(dat$name, "P/Book"), main=mainStr)
	dev.off()

	# Scatter-Plot of P/E.
	emf(paste(filenameStr, "Scatter-Plot PE.emf"))
	plot(m$sp500pe, m$pe, type="p", pch=4, xlab="S&P 500 P/E", ylab=paste(dat$name, "P/E"), main=mainStr)
	dev.off()

	# Show correlations.
	print(paste("Earnings Yield correlation:", cor(m$sp500earningsYield, m$earningsYield)))
	print(paste("P/Book correlation:", cor(m$sp500pbook, m$pbook)))
	print(paste("P/E correlation:", cor(m$sp500pe, m$pe)))

	# Calculate difference.
	dif = m$earningsYield-m$sp500earningsYield
	summary(dif)

	# Plot yield difference.
	emf(paste(filenameStr, "Difference.emf"))
	plotGrid(m$date, dif, xlab="", ylab=labStr, main=mainStr)
	dev.off()

	# Histogram yield difference.
	emf(paste(filenameStr, "Difference Histogram.emf"))
	hist(dif, prob=T, nclass=50, xlab=labStr, main=mainStr)
	dev.off()

	# Show statistics.
	print(summary(dif))
	print(sd(dif))
}

################################################
################################################
# (Companies) Load and prepare data.

# Load data.
ko = loadData("Coca-Cola Financial Per-Share Data.txt", "Coca-Cola Financial Simulation Data.txt", "Coca-Cola Share-Price.txt")
wmt = loadData("Wal-Mart Financial Per-Share Data.txt", "Wal-Mart Financial Simulation Data.txt", "Wal-Mart Share-Price.txt")
mcd = loadData("McDonald's Financial Per-Share Data.txt", "McDonald's Financial Simulation Data.txt", "McDonald's Share-Price.txt")
sp500 = loadData("S&P 500 Financial Per-Share Data.txt", "S&P 500 Financial Simulation Data.txt", "S&P 500 Share-Price.txt")

# Set names used in filenames and plots.
ko$name = "Coca-Cola"
wmt$name = "Wal-Mart"
mcd$name = "McDonald's"
sp500$name = "S&P 500"

# Starting P/Book ratios, i.e. MarketCap / Equity.
ko$startPBook = 5.5	# April 24, 2014: MarketCap = USD 179b, Equity = USD 33b
wmt$startPBook = 3.3	# April 24, 2014: MarketCap = USD 253b, Equity = USD 76b
mcd$startPBook = 6.2	# April 24, 2014: MarketCap = USD  99b, Equity = USD 16b
sp500$startPBook = 2.6  # April 24, 2014: Share-Price = USD 1880, Equity = USD 729

# Show probability of P/Book being lower than starting P/Book.
ecdf(ko$pbook)(ko$startPBook)
ecdf(wmt$pbook)(wmt$startPBook)
ecdf(mcd$pbook)(mcd$startPBook)
ecdf(sp500$pbook)(sp500$startPBook)

# Common years for the financial data of all companies.
commonSimYears = findCommonYears(list(ko$simYears, wmt$simYears, mcd$simYears, sp500$simYears))

# Set the index-offset for use in sampleFinancials().
# Note the index i for offset[i] must match the ordering in findCommonYears().
ko$simYearsOffset = commonSimYears$offset[1]
wmt$simYearsOffset = commonSimYears$offset[2]
mcd$simYearsOffset = commonSimYears$offset[3]
sp500$simYearsOffset = commonSimYears$offset[4]

# Synced P/Book dates for all companies.
l = list(ko$pbookDate, wmt$pbookDate, mcd$pbookDate, sp500$pbookDate)
syncedPBookDates = as.Date(Reduce(intersect, l))
syncedPBookDatesDF = data.frame(date=syncedPBookDates)
syncedPBookNum = length(syncedPBookDates)

# Synced P/Book ratios.
ko$pbookSynced = syncedPBook(ko)
wmt$pbookSynced = syncedPBook(wmt)
mcd$pbookSynced = syncedPBook(mcd)
sp500$pbookSynced = syncedPBook(sp500)

################################################
# (Gov. Bonds) Load and prepare data.

# Load USA government bond yields for the period 1962-2013, daily averages.
usaBonds = list()
temp = read.table("USA Government Bond Yields 10-Year Maturity (Daily).txt", header=TRUE, sep="\t")
usaBonds$data = temp[complete.cases(temp),]
usaBonds$dates = as.Date(usaBonds$data[[1]], "%d-%m-%Y")
usaBonds$yields = usaBonds$data[[2]]

# Load USA government bond yields for the period 1798-2013, annual averages.
usaBondsHistory = list()
temp = read.table("USA Government Bond Yields Long Maturity (1798-2013).txt", header=TRUE, sep="\t")
usaBondsHistory$data = temp[complete.cases(temp),]
usaBondsHistory$years = usaBondsHistory$data[[1]]
usaBondsHistory$yields = usaBondsHistory$data[[2]]

################################################
################################################
# Simulate equity for all companies.
#
# The results are assigned to global variables.
#
# This should be implemented with a list of all
# company data-objects (ko, wmt, mcd) and a for-loop
# but I cannot get it working with R's assignment
# operators and scope rules.
#
# Parameters:
# sims		Number of simulations.
# years		Number of years.

simulateCompanies = function(sims, years)
{
	# Monte Carlo simulations.
	simIndex = sampleIndex(sims, years, commonSimYears$num)
	ko$simEquity <<- simulateEquity(ko, simIndex, sims, years)
	wmt$simEquity <<- simulateEquity(wmt, simIndex, sims, years)
	mcd$simEquity <<- simulateEquity(mcd, simIndex, sims, years)
	sp500$simEquity <<- simulateEquity(sp500, simIndex, sims, years)

	# Sample date-synced P/Book ratios.
	pbookIndex = samplePBookIndex(sims, years)
	ko$pbookSample <<- getPBookSynced(ko, pbookIndex, sims, years)
	wmt$pbookSample <<- getPBookSynced(wmt, pbookIndex, sims, years)
	mcd$pbookSample <<- getPBookSynced(mcd, pbookIndex, sims, years)
	sp500$pbookSample <<- getPBookSynced(sp500, pbookIndex, sims, years)

	# Per-share numbers.
	ko$perShare <<- perShare(ko, sims, years)
	wmt$perShare <<- perShare(wmt, sims, years)
	mcd$perShare <<- perShare(mcd, sims, years)
	sp500$perShare <<- perShare(sp500, sims, years)
}

################################################
# Value yield for all companies when the
# terminal value is estimated growth for eternity.
#
# The results are assigned to global variables.
#
# Parameters:
# sims		Number of simulations.
# years		Number of years.

valueYieldEternalGrowth = function(sims, years)
{
	# Value yield using payout (WITHOUT share buyback).
	ko$vysPayout <<- valueYieldGrowth(ko$startPBook, ko$simEquity$payout, ko$simEquity$equity, ko$meanPayoutROE, wmt$meanGrowth, sims, years)
	wmt$vysPayout <<- valueYieldGrowth(wmt$startPBook, wmt$simEquity$payout, wmt$simEquity$equity, wmt$meanPayoutROE, wmt$meanGrowth, sims, years)
	mcd$vysPayout <<- valueYieldGrowth(mcd$startPBook, mcd$simEquity$payout, mcd$simEquity$equity, mcd$meanPayoutROE, mcd$meanGrowth, sims, years)
	sp500$vysPayout <<- valueYieldGrowth(sp500$startPBook, sp500$simEquity$payout, sp500$simEquity$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, years)

	# Value Yield using dividend-per-share (WITH share buyback).
	# Terminal value uses growth-estimates that are not per-share
	# but the difference should be negligible.
	ko$vysDividendPerShare <<- valueYieldGrowth(ko$startPBook, ko$perShare$dividend, ko$perShare$equity, ko$meanPayoutROE, ko$meanGrowth, sims, years)
	wmt$vysDividendPerShare <<- valueYieldGrowth(wmt$startPBook, wmt$perShare$dividend, wmt$perShare$equity, wmt$meanPayoutROE, wmt$meanGrowth, sims, years)
	mcd$vysDividendPerShare <<- valueYieldGrowth(mcd$startPBook, mcd$perShare$dividend, mcd$perShare$equity, mcd$meanPayoutROE, mcd$meanGrowth, sims, years)
	sp500$vysDividendPerShare <<- valueYieldGrowth(sp500$startPBook, sp500$perShare$dividend, sp500$perShare$equity, sp500$meanPayoutROE, sp500$meanGrowth, sims, years)
}

################################################
# Value yield for all companies when the
# terminal value is price calculated from last
# simulated equity and sampled P/Book.
#
# The results are assigned to global variables.
#
# Parameters:
# sims		Number of simulations.
# years		Number of years.

valueYieldTerminalPrice = function(sims, years)
{
	# Value yield using payout (WITHOUT share buyback).
	ko$vysPayout <<- valueYieldPBook(ko$startPBook, ko$pbookSample, ko$simEquity$payout, ko$simEquity$equity, sims, years)
	wmt$vysPayout <<- valueYieldPBook(wmt$startPBook, wmt$pbookSample, wmt$simEquity$payout, wmt$simEquity$equity, sims, years)
	mcd$vysPayout <<- valueYieldPBook(mcd$startPBook, mcd$pbookSample, mcd$simEquity$payout, mcd$simEquity$equity, sims, years)
	sp500$vysPayout <<- valueYieldPBook(sp500$startPBook, sp500$pbookSample, sp500$simEquity$payout, sp500$simEquity$equity, sims, years)

	# Value Yield using dividend-per-share (WITH share buyback).
	ko$vysDividendPerShare <<- valueYieldPBook(ko$startPBook, ko$pbookSample, ko$perShare$dividend, ko$perShare$equity, sims, years)
	wmt$vysDividendPerShare <<- valueYieldPBook(wmt$startPBook, wmt$pbookSample, wmt$perShare$dividend, wmt$perShare$equity, sims, years)
	mcd$vysDividendPerShare <<- valueYieldPBook(mcd$startPBook, mcd$pbookSample, mcd$perShare$dividend, mcd$perShare$equity, sims, years)
	sp500$vysDividendPerShare <<- valueYieldPBook(sp500$startPBook, sp500$pbookSample, sp500$perShare$dividend, sp500$perShare$equity, sims, years)
}

################################################
# Dividend-per-share growth calculation.
#
# Parameters:
# dat		Financial data returned from loadData().
# years		Number of years.

dividendPerShareGrowth = function(dat, years)
{
	apply(dat$perShare$dividend, 2, function(x) (x[years]/x[1])^(1/years))-1
}

################################################
# Create filename for plots.
#
# Paramters:
# name		Main part of filename e.g. "My plot". Whitespace is trimmed.
# ext		Extension of filename e.g. "emf", without dot.

plotFilename = function(name, ext)
{
	paste(str_trim(name), ".", ext, sep="")
}

################################################
# Value yield plot, helper functions.
#
# Parameters:
# vys		Value yield array.
# name		Name of company, e.g. "Coca-Cola".
# buyback	Boolean T/F whether WITH (T) or wIthout (F) share buyback.
# holding	Text for holding duration e.g. "Eternal Holding" or "10-Year Holding".
# allCompanies	List of all company objects, e.g. list(sp500, ko, wmt, mcd)

# Wrap string in parentheses.
doWrapStr = function(s)
{
	paste("(", s, ")", sep="")
}

# String to add to plot-title.
doAddStr = function(buyback, holding)
{
	# Text for buyback.
	buybackStr = if (buyback) "WITH Share Buyback" else "WITHOUT Share Buyback"

	# Combine strings.
	doWrapStr(paste(buybackStr, ", ", holding, sep=""))
}

# Histograms.
doHistVYS = function(vys, name, buyback, holding)
{
	# Labels.
	addStr = doAddStr(buyback, holding)
	xlab = paste(name, "Value Yield")
	main = paste(xlab, "\n", addStr)

	# Histogram with fitted normal distribution.
	emf(plotFilename(paste(name, "Value Yield Histogram", addStr), "emf"))
	hist(vys, prob=T, nclass=50, xlab=xlab, main=main)
	fit = fitdistr(vys, "normal")
	curve(dnorm(x, mean=fit$estimate["mean"], sd=fit$estimate["sd"]), add=TRUE)
	abline(v=mean(vys), lty=2, lw=2)
	dev.off()
}

# Histogram of value yield difference vysY-vyxX.
doHistVYS2 = function(vysX, vysY, nameX, nameY, buyback, holding)
{
	# Labels.
	addStr = doAddStr(buyback, holding)
	xlab = paste(nameY, "-", nameX, "Value Yield")
	main = paste(xlab, "\n", addStr)

	# Value yield difference.
	vysDif = vysY-vysX

	# Plot with fit.
	emf(plotFilename(paste(nameY, "minus", nameX, "Value Yield", addStr), "emf"))
	hist(vysDif, prob=T, nclass=50, xlab=xlab, main=main)
	fit = fitdistr(vysDif, "normal")
	curve(dnorm(x, mean=fit$estimate["mean"], sd=fit$estimate["sd"]), add=TRUE)
	abline(v=mean(vysDif), lty=2, lw=2)
	dev.off()

	# Probability of value yield difference being negative.
	p = ecdf(vysDif)(0)
	print(paste("Pr[VY", nameY, "< VY", nameX,"] =", p, addStr))
	print(summary(vysDif))
}

# Scatter-plot comparing value yield for one company WITH and WITHOUT share buyback.
doScatterplotVYS = function(vysWithoutBuyback, vysWithBuyback, name, holding)
{
	holding = doWrapStr(holding)

	emf(plotFilename(paste(name, "Value Yield Scatter-Plot", holding), "emf"))
	plot(vysWithoutBuyback, vysWithBuyback, type="p", pch=4, xlab="WITHOUT Share Buyback", ylab="WITH Share Buyback", main=paste(name, "Value Yield", holding))
	dev.off()
}

# Scatter-plot comparing value yield for two companies.
doScatterplotVYS2 = function(vysX, vysY, nameX, nameY, buyback, holding)
{
	# String to add to title.
	addStr = doAddStr(buyback, holding)

	# Title.
	main = paste("Value Yield", addStr)

	# Plot with fit.
	emf(plotFilename(paste(nameX, "vs", nameY, "Value Yield", addStr), "emf"))
	plot(vysX, vysY, type="p", pch=4, xlab=paste(nameX, "Value Yield"), ylab=paste(nameY, "Value Yield"), main=main)
	fit = lm(vysY~vysX)
	abline(fit)
	dev.off()
}

# Make all value yield plots for the supplied companies.
plotVYS = function(allCompanies, holding, govBondYield)
{
	for (dat in allCompanies)
	{
		# Histograms.
		doHistVYS(dat$vysPayout$yields, dat$name, F, holding)
		doHistVYS(dat$vysDividendPerShare$yields, dat$name, T, holding)

		# Scatter-plot.
		doScatterplotVYS(dat$vysPayout$yields, dat$vysDividendPerShare$yields, dat$name, holding)

		# Print dividend-per-share growth.
		dividendGrowth = dividendPerShareGrowth(dat, years)
		print(paste(dat$name, "dividend-per-share growth:"))
		print(summary(dividendGrowth))

		# Print probability of value yield being negative.
		p = ecdf(dat$vysDividendPerShare$yields)(0)
		print(paste("Pr[VY", dat$name, "< 0] =", p, "(WITH Share Buyback)"))

		# Print prob. of value yield less than USA Gov. Bond yield.
		p = ecdf(dat$vysDividendPerShare$yields)(govBondYield)
		print(paste("Pr[VY", dat$name, "<", govBondYield,"] =", p, "(WITH Share Buyback)"))
	}

	# Combinations of indices for the allCompanies-list.
	combIdx = combn(1:length(allCompanies), 2)

	# Plot combinations.
	for (i in 1:(dim(combIdx)[2]))
	{
		# Get index combination.
		idx1 = combIdx[1,i]
		idx2 = combIdx[2,i]

		# Get data-objects from list.
		dat1 = allCompanies[[idx1]]
		dat2 = allCompanies[[idx2]]

		# Scatter-plots.
		doScatterplotVYS2(dat1$vysPayout$yields, dat2$vysPayout$yields, dat1$name, dat2$name, F, holding)
		doScatterplotVYS2(dat1$vysDividendPerShare$yields, dat2$vysDividendPerShare$yields, dat1$name, dat2$name, T, holding)

		# Histogram with value yield difference.
		doHistVYS2(dat1$vysPayout$yields, dat2$vysPayout$yields, dat1$name, dat2$name, F, holding)
		doHistVYS2(dat1$vysDividendPerShare$yields, dat2$vysDividendPerShare$yields, dat1$name, dat2$name, T, holding)
	}
}

################################################
# Combine value yields (vectors) for companies
# into a matrix.
#
# Parameters:
# allCompanies	List of all company objects, e.g. list(sp500, ko, wmt, mcd)

vysCombine = function(allCompanies)
{
	# Create value yield matrix.
	yields = sapply(allCompanies, function(dat) dat$vysDividendPerShare$yields)
	names = sapply(allCompanies, function(dat) dat$name)
	colnames(yields) = names

	# Number of companies.
	numCompanies = length(allCompanies)

	# Statistics.
	means = colMeans(yields)
	sds = apply(yields, 2, sd)
	covmat = cov(yields)
	cormat = cor(yields)

	list(yields = yields, names = names, numCompanies = numCompanies,
		means = means, sds = sds, covmat = covmat, cormat = cormat)
}

################################################
# Find the minimum-variance portfolio.
#
# Parameters:
# vys		Value yield matrix.
# longOnly	Long-only (T) or Long-and-short portfolios (F).

minVarPortfolio = function(vys, longOnly)
{
	# Convert value yields to time-series data-format.
	ts = as.timeSeries(vys$yields)

	# Specification data used by the portfolio optimizer.
	spec = portfolioSpec()

	# Select constraints and solver-method.
	if (longOnly)
	{
		# Long-only portfolios.
		constraints = "LongOnly"
		setSolver(spec) = "solveRquadprog"
	}
	else
	{
		# Shot & long portfolios.
		constraints = "Short"
		setSolver(spec) = "solveRshortExact"
	}

	# Set constraints.
	portfolioConstraints(ts, spec, constraints)

	# Find the minimum-variance portfolio.
	res = minvariancePortfolio(ts, spec, constraints)
	weights = res@portfolio@portfolio$weights

	list(weights = weights)
}

################################################
# Plot mean-variance efficient frontier.
#
# Parameters:
# allCompanies	List of all company objects, e.g. list(sp500, ko, wmt, mcd)
# longOnly	Long-only (T) or Long-and-short portfolios (F).
# holding	Text for holding duration e.g. "Eternal Holding" or "10-Year Holding".
# xlim		xlim for plot.

plotMeanVarFrontier = function(allCompanies, longOnly=T, holding, xlim=NULL)
{
	# Main label for plot.
	longStr = if (longOnly) "Long Only" else "Long & Short"
	main = paste("Efficient Frontier (", longStr, ", ", holding, ")", sep="")

	# Combine value yields for the companies into a matrix.
	vys = vysCombine(allCompanies)

	# Print statistics.
	print(vys$means)
	print(vys$sds)
	print(vys$cormat)

	# Convert value yields to time-series data-format.
	ts = as.timeSeries(vys$yields)

	# Specification data used by the portfolio optimizer.
	spec = portfolioSpec()

	# Number of points calculated for the efficient frontier.
	setNFrontierPoints(spec) = 20

	# Select constraints and solver-method.
	if (longOnly)
	{
		# Long-only portfolios.
		constraints = "LongOnly"
		setSolver(spec) = "solveRquadprog"
	}
	else
	{
		# Shot & long portfolios.
		constraints = "Short"
		setSolver(spec) = "solveRshortExact"
	}

	# Set constraints.
	portfolioConstraints(ts, spec, constraints)

	# Calculate efficient frontier.
	frontier = portfolioFrontier(ts, spec, constraints)

	# Print efficient frontier.
	print(frontier@portfolio)

	# plot efficient frontier
	emf(paste(main, ".emf", sep=""))
	frontierPlot(object = frontier, title=F, type="l", pch=16, xlim=xlim)
	frontierPlot(object = frontier, title=F, pch=16, add=T)
	grid()
	title(main=main, xlab="Value Yield Stdev", ylab="Value Yield Mean")
	
	# Plot squares for the individual assets.
	singleAssetPoints(frontier, pch=15, col="black")

	# Plot text-names for the individual assets.
	for (i in 1:vys$numCompanies) 
	{
		text(x=vys$sds[i], y=vys$means[i], vys$names[i], pos=4)
	}

	# Close plot.
	dev.off()
}

################################################
################################################
# Expand portfolio weights to a vector if it is a scaler.
#
# Parameters:
# weights	Scalar or vector of portfolio weights.
# n		Output vector length.

expandWeights = function(weights, n)
{
	if (length(weights) == 1)
	{
		weights = rep(weights, n)
	}

	weights
}

################################################
# Split portfolio weights into asset-weights and
# gov.bond-weights.
#
# Parameters:
# weights	Portfolio weights to be split.

splitWeights = function(weights)
{
	numWeights = length(weights)
	assetWeights = weights[1:(numWeights-1)]
	govBondWeight = weights[numWeights]

	list(assetWeights = assetWeights, govBondWeight = govBondWeight)
}

################################################
# Convert NaN to -Inf, otherwise just return the input number.

convertNaN = function(x)
{
	if (is.nan(x))
	{
		x = -Inf
	}

	x
}

################################################
# Weighted sum of vys-matrix and weights-vector.
# weights are multiplied with each row of vys
# and the rows are then summed.
#
# Parameters:
# vys		Value yield matrix.
# weights	Portfolio weights for each asset.
# govBondYield	Yield on gov.bonds.

# Portfolio only has assets, no gov.bonds.
weightedSum = function(vys, weights)
{
	rowSums(t(t(vys) * weights))
}

# Portfolio has both assets and gov.bonds.
weightedSumGovBond = function(vys, govBondYield, weights)
{
	# Split portfolio weights into asset- and gov.bond-weights.
	w = splitWeights(weights)

	weightedSum(vys, w$assetWeights) + w$govBondWeight * govBondYield
}

################################################
# Portfolio weight constraints. Ensures the sum
# is at most one. Doesn't enforce weight-boundaries.
# It may not work properly if weight-sum is negative.
#
# Parameters:
# weights	Portfolio weights to be constrained.

constraints = function(weights)
{
	s = sum(weights)

	# Normalize weights to one if their sum is greater than one.
	if (s>1)
	{
		weights = weights / s
	}

	# Doesn't work when shorting is allowed,
	# the weights may become extremely large.
	#if (s>0)

	weights
}

################################################
################################################
# Kelly performance criterion for portfolio
# containing either a single asset or cash which
# doesn't earn any interest:
# portfolio = weight * asset + (1-weight) * cash
#
# The optimization objective is to select the
# asset weights that maximize this number.
#
# Parameters:
# vys		Value yield for the asset (vector).
# weight	Asset weight (scalar).

kellyOneAsset = function(vys, weight)
{
	mean(log(1 + weight * vys))
}

################################################
# Kelly performance criterion for portfolio
# containing either one asset or gov.bond:
# portfolio = weight * asset + (1-weight) * gov.bond
#
# The optimization objective is to select the
# asset weights that maximize this number.
#
# Parameters:
# vys		Value yield for the asset (vector).
# weight	Asset weight (scalar).
# govBondYield	Yield on gov.bond.

kellyOneAssetGovBond = function(vys, weight, govBondYield)
{
	mean(log(1 + weight * vys + (1-weight) * govBondYield))
}

################################################
# Kelly performance criterion for portfolio
# containing multiple assets.
#
# The optimization objective is to select the
# asset weights that maximize this number.
#
# Parameters:
# vys		Value yield for the assets (matrix).
# weight	Asset weights (vector).

kellyPortfolio = function(vys, weights)
{
	# Enforce constraints on portfolio weights.
	weights = constraints(weights)

	# Weighted sum of value yield and portfolio weights.
	s = weightedSum(vys, weights)

	# Kelly performance criterion.
	g = mean(log(1+s))

	# Ensure output is a number (not NaN)
	# otherwise the optimizer stops.
	convertNaN(g)
}

################################################
# Kelly performance criterion for portfolio
# containing multiple assets.
#
# The optimization objective is to select the
# asset weights that maximize this number.
#
# Parameters:
# vys		Value yield for the assets (matrix).
# weight	Asset weight (scalar).
# govBondYield	Yield on gov.bond.

# Portfolio of multiple assets and gov.bond.
kellyPortfolioGovBond = function(vys, govBondYield, weights)
{
	# Enforce constraints on portfolio weights.
	weights = constraints(weights)

	# Weighted sum of value yield and portfolio weights.
	s = weightedSumGovBond(vys, govBondYield, weights)

	# Kelly performance criterion.
	g = mean(log(1 + s))

	# Ensure output is a number (not NaN)
	# otherwise the optimizer stops.
	convertNaN(g)
}

################################################
# Kelly optimization when portfolio consists of
# either a single asset or cash.
#
# Parameters:
# vys		Value yields for the asset (vector).
# minWeights	Min asset weight (scalar).
# maxWeights	Max asset weight (scalar).

optimizeKellyOneAsset = function(vys, minWeights, maxWeights)
{
	# Perform optimization.
	res = optimize(function(weight) kellyOneAsset(vys, weight), maximum=T, lower=minWeights, upper=maxWeights, tol=1e-5)

	# Return best found asset weight.
	list(weight = res$maximum)
}

################################################
# Kelly optimization when portfolio consists of
# one asset or gov.bond.
#
# Parameters:
# vys		Value yields for the asset (vector).
# govBondYield	Yield on gov.bond.
# minWeights	Min asset weight (scalar).
# maxWeights	Max asset weight (scalar).

optimizeKellyOneAssetGovBond = function(vys, govBondYield, minWeights, maxWeights)
{
	# Perform optimization.
	res = optimize(function(weight) kellyOneAssetGovBond(vys, weight, govBondYield), maximum=T, lower=minWeights, upper=maxWeights, tol=1e-5)

	# Return best found asset weight.
	list(weight = res$maximum)
}

################################################
# Control parameters for DE optimizer.
# Ignore the warnings DEoptim() gives about the parameters.
#
# These are suitable for low number of portfolio assets e.g. 2-10.
# A paper has DE control parameters for higher number of assets:
# Good Parameters for Differential Evolution
# Pedersen, M.E.H., Hvass Laboratories Technical Report HL1002, 2010

controlDE = list(NP=15, CR=0.7, F=0.9, trace=F, itermax=1000)

################################################
# Kelly optimization when the portfolio consists
# of multiple assets.
#
# Parameters:
# vys		Value yields for the assets (matrix).
# minWeights	Min asset weight (vector).
# maxWeights	Max asset weight (vector).

optimizeKellyPortfolio = function(vys, minWeights, maxWeights)
{
	# Perform optimization using DE.
	# DE assumes a minimization problem so the fitness value is negated.
	res = DEoptim(function(weights) -kellyPortfolio(vys, weights), lower=minWeights, upper=maxWeights, control=controlDE)

	# Best found portfolio weights.
	# Ensure they are constrained and named.
	# Does not enforce boundary constraints.
	weights = constraints(res$optim$bestmem)
	names(weights) = colnames(vys)

	# Return best found weights.
	list(weights = weights)
}

################################################
# Kelly optimization when the portfolio consists
# of multiple assets or gov.bonds.
#
# Parameters:
# vys		Value yields for the assets (matrix).
# govBondYield	Yield on gov.bond.
# minWeights	Min asset weight (vector).
# maxWeights	Max asset weight (vector).

optimizeKellyPortfolioGovBond = function(vys, govBondYield, minAssetWeights, maxAssetWeights, minGovBondWeight, maxGovBondWeight)
{
	# Combine weights for assets and gov.bond.
	minWeights = c(minAssetWeights, minGovBondWeight)
	maxWeights = c(maxAssetWeights, maxGovBondWeight)

	# Perform optimization using DE.
	# DE assumes a minimization problem so the fitness value is negated.
	res = DEoptim(function(weights) -kellyPortfolioGovBond(vys, govBondYield, weights), lower=minWeights, upper=maxWeights, control=controlDE)

	# Best found portfolio weights.
	# Ensure they are constrained and named.
	# Does not enforce boundary constraints.
	weights = constraints(res$optim$bestmem)
	names(weights) = c(colnames(vys), "Gov.Bond")

	# Return best found weights.
	list(weights = weights)
}

################################################
# Print Kelly optimal portfolio weights and statistics
# for different portfolio weight boundaries.
#
# Parameters:
# allCompanies	List of all company objects, e.g. list(sp500, ko, wmt, mcd)
# govBondYield	Yield on gov.bond.
# longOnly	Long-only (T) or Long-and-short portfolios (F).

printKellyPortfolios = function(allCompanies, govBondYield, longOnly)
{
	# Combine value yields for the companies into a matrix.
	vys = vysCombine(allCompanies)

	# Portfolio weights for min-variance portfolio.
	minVarWeights = minVarPortfolio(vys, longOnly)$weights

	# Value yields for min-variance portfolio.
	vysMinVar = weightedSum(vys$yields, minVarWeights)

	# Print min-variance portfolio weights and statistics.
	print("Min-variance portfolio:")
	print(minVarWeights)
	print(summary(vysMinVar))
	print(paste("sd: ", sd(vysMinVar)))
	print("############")

	# Find Kelly portfolios for different asset weight boundaries.
	n = 10
	for (i in 1:n)
	{
		# Max asset weight boundary.
		maxWeight = i*1.0/n

		# Min asset weight boundary.
		if (longOnly)
		{
			minWeight = 0
		}
		else # Long and short portfolios.
		{
			minWeight = -maxWeight
		}

		# Expand weight boundaries to vectors.
		minAssetWeights = expandWeights(minWeight, vys$numCompanies)
		maxAssetWeights = expandWeights(maxWeight, vys$numCompanies)

		# Gov.bond weight boundaries.
		minGovBondWeight = 0
		maxGovBondWeight = 5	# In case several assets have negative weights.

		# Kelly portfolio optimization.
		portfolio = optimizeKellyPortfolioGovBond(vys$yields, govBondYield, minAssetWeights, maxAssetWeights, minGovBondWeight, maxGovBondWeight)

		# Print max asset weight.
		print(paste("Max asset weight: ", maxWeight))

		# Print Kelly portfolio weights.
		print(round(portfolio$weights, digits=3))

		# Print Kelly value.
		print(paste("Kelly value: ", kellyPortfolioGovBond(vys$yields, govBondYield, portfolio$weights)))

		# Value yields for Kelly portfolio.
		vysPortfolio = weightedSumGovBond(vys$yields, govBondYield, portfolio$weights)

		# Print value yield statistics.
		print("Portfolio value yield:")
		print(summary(vysPortfolio))
		print(paste("sd:", sd(vysPortfolio)))

		# Value yield difference between Kelly and Min-Variance portfolios.
		vysDif = vysMinVar-vysPortfolio

		# Probability that Kelly portfolio return > min-var portfolio return.
		# Probability of value yield difference being negative.
		p = ecdf(vysDif)(0)
		print(paste("Pr[Kelly Return > Min-Variance Return] =", p))

		# Print separation line for readability.
		print("#############")
	}
}

################################################
################################################
# Value Yield, Eternal Holding.

# Number of Monte Carlo simulations to perform.
sims = 2000

# Number of years in each Monte Carlo simulation.
years = 300

# Text to display in plots for holding duration.
holding = "Eternal Holding"

# Monte Carlo simulation for all companies.
# Updates the global data-objects: ko, wmt, mcd, sp500, ...
simulateCompanies(sims, years)

# Value yield with eternal growth.
# Updates the global data-objects: ko, wmt, mcd, sp500, ...
valueYieldEternalGrowth(sims, years)

# List of all company dat-objects.
# The list must be created at this point otherwise it
# doesn't contain the correct data.
# sp500 must be first in list to plot comparisons correctly.
allCompanies = list(sp500, ko, wmt, mcd)

# Yield on USA gov. bonds with 30-year maturity was about 3.5% in April 2014.
govBondYield = 0.035

# Plot value yield.
plotVYS(allCompanies, holding, govBondYield)

# Plot mean-variance efficient portfolio.
xlimit = c(0.003, 0.014)
plotMeanVarFrontier(allCompanies, longOnly=F, holding=holding, xlim=xlimit)
plotMeanVarFrontier(allCompanies, longOnly=T, holding=holding, xlim=xlimit)

# Print Kelly optimal portfolios for different asset weight constraints.
printKellyPortfolios(allCompanies, govBondYield, longOnly=F)
printKellyPortfolios(allCompanies, govBondYield, longOnly=T)

################################################
# Value Yield, 10-Year Holding.

# Number of Monte Carlo simulations to perform.
sims = 2000

# Number of years in each Monte Carlo simulation.
years = 10

# Text to display in plots for holding duration.
holding = "10-Year Holding"

# Monte Carlo simulation for all companies.
# Updates the global data-objects: ko, wmt, mcd, sp500, ...
simulateCompanies(sims, years)

# Value yield with terminal price calculated from P/Book sample.
# Updates the global data-objects: ko, wmt, mcd, sp500, ...
valueYieldTerminalPrice(sims, years)

# List of all company dat-objects.
# The list must be created at this point otherwise it
# doesn't contain the correct data.
# sp500 must be first in list to plot comparisons correctly.
allCompanies = list(sp500, ko, wmt, mcd)

# Yield on USA gov. bonds with 10-year maturity was about 2.7% in April 2014.
govBondYield = 0.027

# Plot value yield.
plotVYS(allCompanies, holding, govBondYield)

# Plot mean-variance efficient portfolio.
xlimit = c(0.02,0.08)
plotMeanVarFrontier(allCompanies, longOnly=F, holding=holding, xlim=xlimit)
plotMeanVarFrontier(allCompanies, longOnly=T, holding=holding, xlim=xlimit)

# Print Kelly optimal portfolios for different asset weight constraints.
printKellyPortfolios(allCompanies, govBondYield, longOnly=F)
printKellyPortfolios(allCompanies, govBondYield, longOnly=T)

################################################
################################################
# Combine vectors for asset returns to a matrix.
#
# Parameters:
# assetA	Returns for asset A.
# assetB	Returns for asset B.

combineTwoAssets = function(assetA, assetB)
{
	vys = matrix(c(assetA, assetB), ncol=2)
	colnames(vys) = c("Asset A", "Asset B")

	vys
}

################################################
# Perform Kelly portfolio optimization of two assets.
# Used in the small examples below.
#
# Parameters:
# vysA		Returns on asset A.
# vysB		Returns on asset B.

optimizeKellyTwoAssets = function(vysA, vysB)
{
	# Initialize weight boundaries.
	# No short-selling or leverage.
	minWeights = expandWeights(0, 2)
	maxWeights = expandWeights(1, 2)

	# Combine vectors for asset returns to a matrix.
	vys = combineTwoAssets(vysA, vysB)

	# Optimize portfolio weights using the Kelly measure.
	portfolio = optimizeKellyPortfolio(vys, minWeights, maxWeights)

	list(weights = portfolio$weights, kellyValue = kellyPortfolio(vys, portfolio$weights))
}

################################################
# Convert vector of numbers to string.
# Example: c(0.05, 0.10) becomes "(5%, 10%)"

vysToString = function(vys)
{
	a = paste(percent(vys), collapse=", ")
	
	paste("(", a, ")", sep="")
}

################################################
# Plot curve of Kelly values for two asset portfolios.
#
# Parameters:
# assetA	Returns on asset A.
# assetB	Returns on asset B.

plotKellyCurve = function(assetA, assetB)
{
	# Number of points to calculate.
	n = 30

	# Weights for asset A.
	w = seq(0, 1, length.out=n)

	# Value yield matrix.
	vys = combineTwoAssets(assetA, assetB)

	# Calculate Kelly values for different weights.
	kelly = sapply(w, function(w) kellyPortfolio(vys, c(w, 1-w)))

	# Title of plot.
	assetAStr = paste("Asset A", vysToString(assetA))
	assetBStr = paste("Asset B", vysToString(assetB))
	main = paste("Kelly Value\n", assetAStr, ", ", assetBStr, sep="")

	# Plot.
	emf(paste("Kelly Curve ", assetAStr, " ", assetBStr, ".emf", sep=""))
	plot(w, kelly, type="l", xlab="Asset A Portfolio Weight", ylab="Kelly Value (Maximize)", main=main)
	dev.off()
}

################################################
# Kelly portfolio optimization.
# Example with two simple return distributions
# which cannot be handled by mean-variance
# portfolio optimization but Kelly solves.

# Returns for asset B.
assetB = c(0.05, 0.1, 0.15)

# Plot Kelly curve and optimal portfolio.
assetA = c(-0.04, -0.05, -0.06)
plotKellyCurve(assetA, assetB)
optimizeKellyTwoAssets(assetA, assetB)

# Plot Kelly curve and optimal portfolio.
assetA = c(0.03, 0.02, 0.01)
plotKellyCurve(assetA, assetB)
optimizeKellyTwoAssets(assetA, assetB)

# Plot Kelly curve and optimal portfolio.
assetA = c(0.06, 0.05, 0.04)
plotKellyCurve(assetA, assetB)
optimizeKellyTwoAssets(assetA, assetB)

################################################
# Kelly portfolio optimization.
# Example of compounded returns for Kelly
# portfolio and single assets.

# Return distributions.
assetA = c(0.12, 0.09, 0.09)
assetB = c(0.05, 0.1, 0.15)

# Statistics for returns.
sd(assetB)
cor(assetA, assetB)

# Plot Kelly curve and portfolio weights.
plotKellyCurve(assetA, assetB)
portfolio = optimizeKellyTwoAssets(assetA, assetB)
portfolio

# Combine asset returns into matrix.
vys = combineTwoAssets(assetA, assetB)

# Returns of Kelly optimal portfolio.
portfolioReturns = weightedSum(vys, portfolio$weights)
portfolioReturns
sd(portfolioReturns)

# Show Kelly values for assets and portfolio.
kellyOneAsset(assetA, 1)
kellyOneAsset(assetB, 1)
kellyOneAsset(portfolioReturns, 1)

# Sample asset and portfolio returns.
n = 1000
idx = sample(1:3, n, rep=T)
samplePortfolio = portfolioReturns[idx]
sampleAssetA = assetA[idx]
sampleAssetB = assetB[idx]

# Compound the sampled returns to simulate
# repeated investment.
cumPortfolio = cumprod(1+samplePortfolio)
cumAssetA = cumprod(1+sampleAssetA)
cumAssetB = cumprod(1+sampleAssetB)

# Plot ratios of portfolio and asset returns.
emf("Kelly Simulation.emf")
matplot(1:n, cbind(cumPortfolio/cumAssetA, cumPortfolio/cumAssetB), type="l", lty=c(1,2), col="#000000", xlab="Iteration", ylab="Portfolio Return / Asset Return", main="Kelly Portfolio Return / Asset Return")
dev.off()

################################################
################################################
# (Companies) Plot value yield curves.

# Number of simulations.
sims = 2000

# Years per simulation.
years = 30

# Perform simulations and make plots.
# This may take a few minutes.
plotValueYieldCurves(ko, sims, years)
plotValueYieldCurves(wmt, sims, years)
plotValueYieldCurves(mcd, sims, years)
plotValueYieldCurves(sp500, sims, years)

################################################
################################################
# (Companies) Various data plots.

# Plot data.
plotFinancials(sp500)
plotFinancials(wmt)
plotFinancials(ko)
plotFinancials(mcd)

# Show statistics.
stats(sp500)
stats(wmt)
stats(ko)
stats(mcd)

# Plot comparisons to Gov. Bonds.
compareToGovBonds(sp500)
compareToGovBonds(wmt)
compareToGovBonds(ko)
compareToGovBonds(mcd)

# Plot comparisons to S&P 500.
compareToSP500(wmt)
compareToSP500(ko)
compareToSP500(mcd)

################################################
################################################
# (USA Gov. Bonds) Various data plots.

# USA Gov. Bond Yields, 1798-2013.
#emf("USA Gov Bond Yield (1798-2013).emf")
plotGrid(usaBondsHistory$years, usaBondsHistory$yields, ylim=c(1,16), xlab="Year", ylab="Yield / %", main="USA Gov. Bond Yield / % (Long Maturity)")
#dev.off()

# Histogram of USA Gov. Bond Yields, 1798-2013.
#emf("USA Gov Bond Yield (1798-2013) Histogram.emf")
hist(usaBondsHistory$yields, nclass=50, prob=T, xlab="Yield / %", main="USA Gov. Bond Yield (1798-2013)")
#dev.off()

# Plot ECDF for USA Gov. Bond Yields, 1798-2013.
#emf("USA Gov Bond Yield (1798-2013) ECDF.emf")
plot(ecdf(usaBondsHistory$yields), pch="", verticals=TRUE, xlab="Yield / %", ylab="F(x)", main="USA Gov. Bond Yield (1798-2013)", panel.first=grid())
#dev.off()

# USA Gov. Bond Yields, 1962-2013.
#emf("USA Gov Bond Yield (1962-2013).emf")
plotGrid(usaBonds$dates, usaBonds$yields, ylim=c(1,16), xlab="", ylab="Yield / %", main="USA Gov. Bond Yield / % (10-Year Maturity)")
#dev.off()

# Histogram of USA Gov. Bond Yields, 1962-2013.
#emf("USA Gov Bond Yield (1962-2013) Histogram.emf")
hist(usaBonds$yields, nclass=100, prob=T, xlab="Yield / %", main="USA Gov. Bond Yield 10-Year Maturity (1962-2013)")
#dev.off()

# Plot ECDF for USA Gov. Bond Yields, 1962-2013.
#emf("USA Gov Bond Yield (1962-2013) ECDF.emf")
plot(ecdf(usaBonds$yields), pch="", verticals=TRUE, xlab="Yield / %", ylab="F(x)", main="USA Gov. Bond Yield (1962-2013)", panel.first=grid())
#dev.off()

# Statistics.
summary(usaBondsHistory$yields)
geomean(usaBondsHistory$yields)
harmean(usaBondsHistory$yields)
sd(usaBondsHistory$yields)

# Statistics.
summary(usaBonds$yields)
geomean(usaBonds$yields)
harmean(usaBonds$yields)
sd(usaBonds$yields)

################################################
################################################
